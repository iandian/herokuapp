package org.flow.searcher.crawler;


import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import org.apache.commons.io.FilenameUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.flow.searcher.settings.Server;
import org.flow.searcher.settings.TheSearcherSettings;

import java.io.InputStream;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Vector;
import java.util.stream.Collectors;

public class FileAbstractorSSH extends FileAbstractor<ChannelSftp.LsEntry> {
    private final Logger logger = LogManager.getLogger(FileAbstractorSSH.class);

    private ChannelSftp sftp;

    public FileAbstractorSSH(TheSearcherSettings theSearcherSettings) {
        super(theSearcherSettings);
    }

    @Override
    public FileAbstractModel toFileAbstractModel(String path, ChannelSftp.LsEntry file) {
        return new FileAbstractModel(
                file.getFilename(),
                !file.getAttrs().isDir(),
                // We are using here the local TimeZone as a reference. If the remote system is under another TZ, this might cause issues
                LocalDateTime.ofInstant(Instant.ofEpochMilli(file.getAttrs().getMTime()*1000L), ZoneId.systemDefault()),
                // We don't have the creation date
                null,
                // We are using here the local TimeZone as a reference. If the remote system is under another TZ, this might cause issues
                LocalDateTime.ofInstant(Instant.ofEpochMilli(file.getAttrs().getATime()*1000L), ZoneId.systemDefault()),
                FilenameUtils.getExtension(file.getFilename()),
                path,
                path.concat("/").concat(file.getFilename()),
                file.getAttrs().getSize(),
                Integer.toString(file.getAttrs().getUId()),
                Integer.toString(file.getAttrs().getGId()),
                file.getAttrs().getPermissions());
    }

    @Override
    public InputStream getInputStream(FileAbstractModel file) throws Exception {
        return sftp.get(file.getFullpath());
    }

    @SuppressWarnings("unchecked")
    @Override
    public Collection<FileAbstractModel> getFiles(String dir) throws Exception {
        logger.debug("Listing local files from {}", dir);
        Vector<ChannelSftp.LsEntry> ls;

        ls = sftp.ls(dir);
        if (ls == null) return null;

        Collection<FileAbstractModel> result = new ArrayList<>(ls.size());
        // Iterate other files
        // We ignore here all files like . and ..
        result.addAll(ls.stream().filter(file -> !".".equals(file.getFilename()) &&
                !"..".equals(file.getFilename()))
                .map(file -> toFileAbstractModel(dir, file))
                .collect(Collectors.toList()));

        logger.debug("{} local files found", result.size());
        return result;
    }

    @Override
    public boolean exists(String dir) {
        try {
            sftp.ls(dir);
        } catch (Exception e) {
            return false;
        }
        return true;
    }

    @Override
    public void open() throws Exception {
        sftp = openSSHConnection(theSearcherSettings.getServer());
    }

    @Override
    public void close() throws Exception {
        sftp.getSession().disconnect();
        sftp.disconnect();
    }

    private ChannelSftp openSSHConnection(Server server) throws Exception {
        logger.debug("Opening SSH connection to {}@{}", server.getUsername(), server.getHostname());

        JSch jsch = new JSch();
        Session session = jsch.getSession(server.getUsername(), server.getHostname(), server.getPort());
        java.util.Properties config = new java.util.Properties();
        config.put("StrictHostKeyChecking", "no");
        if (server.getPemPath() != null) {
            jsch.addIdentity(server.getPemPath());
        }
        session.setConfig(config);
        if (server.getPassword() != null) {
            session.setPassword(server.getPassword());
        }
        session.connect();

        //Open a new session for SFTP.
        Channel channel = session.openChannel("sftp");
        channel.connect();

        //checking SSH client connection.
        if (!channel.isConnected()) {
            logger.warn("Cannot connect with SSH to {}@{}", server.getUsername(),
                    server.getHostname());
            throw new RuntimeException("Can not connect to " + server.getUsername() + "@" + server.getHostname());
        }
        logger.debug("SSH connection successful");
        return (ChannelSftp) channel;
    }
}
