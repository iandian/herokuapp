# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
import logging


logger = logging.getLogger(__name__)


class AD_Position(models.Model):
    name = models.CharField(max_length=60)
    width = models.SmallIntegerField()
    height = models.SmallIntegerField()
    desc = models.CharField(max_length=255)


    class Meta:
        verbose_name = "AD_Position"
        verbose_name_plural = "AD_Position"

    def __unicode__(self):
        return '%s %s' % (self.name, self.desc)