FactoryGirl.define do

  factory :run_record do
    build
    sequence(:name){|n|"run_record_#{n}"}
  end
end