class User < ApplicationRecord

  rolify

  include DeviseTokenAuth::Concerns::User
  
  # Include default devise modules. Others available are:
  # :confirmable, :lockable, :timeoutable and :omniauthable
  devise :ldap_authenticatable, :registerable,
         :recoverable, :rememberable, :trackable, :validatable

  ## Validations
  validates :nickname, presence: true, uniqueness: true

  # before_validation :get_ldap_email
  # def get_ldap_email
  #   self.email = Devise::LDAP::Adapter.get_ldap_param(self.nickname,"mail").first
  # end

  def active_for_authentication?
    true
  end

  # use ldap uid as primary key
  # before_validation :get_ldap_id
  # def get_ldap_id
  #   self.id = Devise::LDAP::Adapter.get_ldap_param(self.nickname,"sAMAccountName").first
  # end  
  
  ## Callbacks
  before_save do
    self.email = email.downcase if email_changed?
  end
  
  def ldap_before_save
    self.email = Devise::LDAP::Adapter.get_ldap_param(self.nickname,"mail").first
  end

end
