# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from django.contrib.auth.models import User
import logging


logger = logging.getLogger(__name__)

#TODO
class Feedback(models.Model):
    msg_id = models.AutoField(primary_key=True)
    parent_id = models.IntegerField()
    user_id = models.IntegerField()
    user_name = models.CharField(max_length=60)
    user_email = models.CharField(max_length=60)
    msg_title = models.CharField(max_length=200)
    msg_type = models.IntegerField()
    msg_status = models.IntegerField()
    msg_content = models.TextField()
    msg_time = models.IntegerField()
    message_img = models.CharField(max_length=255)
    order_id = models.IntegerField()
    msg_area = models.IntegerField()

    class Meta:
        verbose_name = "Address"
        verbose_name_plural = "Address"

    def __unicode__(self):
        return '%s %s' % (self.name, self.address)