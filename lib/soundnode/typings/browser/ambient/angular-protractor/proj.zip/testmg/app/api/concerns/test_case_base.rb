module TestCaseBase
  extend ActiveSupport::Concern

  included do

    helpers do
      def get_test_case(id)
        @test_case = TestCase.find(id)

        unless @test_case
          raise ApiException.new(
            http_status: RESPONSE_CODE[:not_found], 
            code: RESPONSE_CODE[:not_found], 
            message: I18n.t('errors.test_case.not_found')
          )
        end
      end
	  
      def create_test_case(params)
        @test_case = TestCase.new(params)

        unless @test_case.save
          raise ApiException.new(
            http_status: RESPONSE_CODE[:not_found], 
            code: RESPONSE_CODE[:not_found], 
            message: I18n.t('errors.test_case.not_found')
          )
        end
      end

    end
  end
end