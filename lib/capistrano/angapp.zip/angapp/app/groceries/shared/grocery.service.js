"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var http_1 = require("@angular/common/http");
var BehaviorSubject_1 = require("rxjs/BehaviorSubject");
var operators_1 = require("rxjs/operators");
var ErrorObservable_1 = require("rxjs/observable/ErrorObservable");
var shared_1 = require("../../shared");
var grocery_model_1 = require("./grocery.model");
var GroceryService = /** @class */ (function () {
    function GroceryService(http, zone) {
        this.http = http;
        this.zone = zone;
        this.items = new BehaviorSubject_1.BehaviorSubject([]);
        this.allItems = [];
        this.baseUrl = shared_1.BackendService.baseUrl + "appdata/" + shared_1.BackendService.appKey + "/Groceries";
    }
    GroceryService.prototype.load = function () {
        var _this = this;
        var params = new http_1.HttpParams();
        params.append("sort", "{\"_kmd.lmt\": -1}");
        return this.http.get(this.baseUrl, {
            headers: this.getCommonHeaders(),
            params: params,
        })
            .pipe(operators_1.map(function (data) {
            data.forEach(function (grocery) {
                _this.allItems.push(new grocery_model_1.Grocery(grocery._id, grocery.Name, grocery.Done || false, grocery.Deleted || false));
                _this.publishUpdates();
            });
        }), operators_1.catchError(this.handleErrors));
    };
    GroceryService.prototype.add = function (name) {
        var _this = this;
        return this.http.post(this.baseUrl, JSON.stringify({ Name: name }), { headers: this.getCommonHeaders() })
            .pipe(operators_1.map(function (data) {
            _this.allItems.unshift(new grocery_model_1.Grocery(data._id, name, false, false));
            _this.publishUpdates();
        }), operators_1.catchError(this.handleErrors));
    };
    GroceryService.prototype.setDeleteFlag = function (item) {
        var _this = this;
        item.deleted = true;
        return this.put(item)
            .pipe(operators_1.map(function (data) {
            item.done = false;
            _this.publishUpdates();
        }));
    };
    GroceryService.prototype.unsetDeleteFlag = function (item) {
        var _this = this;
        item.deleted = false;
        return this.put(item)
            .pipe(operators_1.map(function (data) {
            item.done = false;
            _this.publishUpdates();
        }));
    };
    GroceryService.prototype.toggleDoneFlag = function (item) {
        item.done = !item.done;
        this.publishUpdates();
        return this.put(item);
    };
    GroceryService.prototype.permanentlyDelete = function (item) {
        var _this = this;
        return this.http
            .delete(this.baseUrl + "/" + item.id, { headers: this.getCommonHeaders() })
            .pipe(operators_1.map(function (data) {
            var index = _this.allItems.indexOf(item);
            _this.allItems.splice(index, 1);
            _this.publishUpdates();
        }), operators_1.catchError(this.handleErrors));
    };
    GroceryService.prototype.put = function (grocery) {
        return this.http.put(this.baseUrl + "/" + grocery.id, JSON.stringify({
            Name: grocery.name,
            Done: grocery.done,
            Deleted: grocery.deleted
        }), { headers: this.getCommonHeaders() })
            .pipe(operators_1.catchError(this.handleErrors));
    };
    GroceryService.prototype.publishUpdates = function () {
        var _this = this;
        // Make sure all updates are published inside NgZone so that change detection is triggered if needed
        this.zone.run(function () {
            // must emit a *new* value (immutability!)
            _this.items.next(_this.allItems.slice());
        });
    };
    GroceryService.prototype.getCommonHeaders = function () {
        return new http_1.HttpHeaders({
            "Content-Type": "application/json",
            "Authorization": "Kinvey " + shared_1.BackendService.token,
        });
    };
    GroceryService.prototype.handleErrors = function (error) {
        console.log(error);
        return ErrorObservable_1.ErrorObservable.create(error);
    };
    GroceryService = __decorate([
        core_1.Injectable(),
        __metadata("design:paramtypes", [http_1.HttpClient, core_1.NgZone])
    ], GroceryService);
    return GroceryService;
}());
exports.GroceryService = GroceryService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3JvY2VyeS5zZXJ2aWNlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiZ3JvY2VyeS5zZXJ2aWNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEsc0NBQW1EO0FBQ25ELDZDQUs4QjtBQUM5Qix3REFBdUQ7QUFJdkQsNENBQWlEO0FBQ2pELG1FQUFrRTtBQUVsRSx1Q0FBOEM7QUFDOUMsaURBQTBDO0FBRzFDO0lBS0Usd0JBQW9CLElBQWdCLEVBQVUsSUFBWTtRQUF0QyxTQUFJLEdBQUosSUFBSSxDQUFZO1FBQVUsU0FBSSxHQUFKLElBQUksQ0FBUTtRQUoxRCxVQUFLLEdBQW9DLElBQUksaUNBQWUsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUN6RCxhQUFRLEdBQW1CLEVBQUUsQ0FBQztRQUN0QyxZQUFPLEdBQUcsdUJBQWMsQ0FBQyxPQUFPLEdBQUcsVUFBVSxHQUFHLHVCQUFjLENBQUMsTUFBTSxHQUFHLFlBQVksQ0FBQztJQUV2QixDQUFDO0lBRS9ELDZCQUFJLEdBQUo7UUFBQSxpQkF3QkM7UUF2QkMsSUFBTSxNQUFNLEdBQUcsSUFBSSxpQkFBVSxFQUFFLENBQUM7UUFDaEMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsb0JBQW9CLENBQUMsQ0FBQztRQUU1QyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRTtZQUNqQyxPQUFPLEVBQUUsSUFBSSxDQUFDLGdCQUFnQixFQUFFO1lBQ2hDLE1BQU0sUUFBQTtTQUNQLENBQUM7YUFDRCxJQUFJLENBQ0gsZUFBRyxDQUFDLFVBQUMsSUFBVztZQUNkLElBQUksQ0FBQyxPQUFPLENBQUMsVUFBQyxPQUFPO2dCQUNuQixLQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FDaEIsSUFBSSx1QkFBTyxDQUNULE9BQU8sQ0FBQyxHQUFHLEVBQ1gsT0FBTyxDQUFDLElBQUksRUFDWixPQUFPLENBQUMsSUFBSSxJQUFJLEtBQUssRUFDckIsT0FBTyxDQUFDLE9BQU8sSUFBSSxLQUFLLENBQ3pCLENBQ0YsQ0FBQztnQkFDRixLQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7WUFDeEIsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsRUFDRixzQkFBVSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FDOUIsQ0FBQztJQUNKLENBQUM7SUFFRCw0QkFBRyxHQUFILFVBQUksSUFBWTtRQUFoQixpQkFhQztRQVpDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FDbkIsSUFBSSxDQUFDLE9BQU8sRUFDWixJQUFJLENBQUMsU0FBUyxDQUFDLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxDQUFDLEVBQzlCLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxFQUFFLENBQ3JDO2FBQ0EsSUFBSSxDQUNILGVBQUcsQ0FBQyxVQUFDLElBQVM7WUFDWixLQUFJLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxJQUFJLHVCQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUM7WUFDakUsS0FBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO1FBQ3hCLENBQUMsQ0FBQyxFQUNGLHNCQUFVLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUM5QixDQUFDO0lBQ0osQ0FBQztJQUVELHNDQUFhLEdBQWIsVUFBYyxJQUFhO1FBQTNCLGlCQVNDO1FBUkMsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUM7UUFDcEIsTUFBTSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDO2FBQ2xCLElBQUksQ0FDSCxlQUFHLENBQUMsVUFBQSxJQUFJO1lBQ04sSUFBSSxDQUFDLElBQUksR0FBRyxLQUFLLENBQUM7WUFDbEIsS0FBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO1FBQ3hCLENBQUMsQ0FBQyxDQUNILENBQUM7SUFDTixDQUFDO0lBRUQsd0NBQWUsR0FBZixVQUFnQixJQUFhO1FBQTdCLGlCQVNDO1FBUkMsSUFBSSxDQUFDLE9BQU8sR0FBRyxLQUFLLENBQUM7UUFDckIsTUFBTSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDO2FBQ2xCLElBQUksQ0FDSCxlQUFHLENBQUMsVUFBQSxJQUFJO1lBQ04sSUFBSSxDQUFDLElBQUksR0FBRyxLQUFLLENBQUM7WUFDbEIsS0FBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO1FBQ3hCLENBQUMsQ0FBQyxDQUNILENBQUM7SUFDTixDQUFDO0lBR0QsdUNBQWMsR0FBZCxVQUFlLElBQWE7UUFDMUIsSUFBSSxDQUFDLElBQUksR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7UUFDdkIsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO1FBQ3RCLE1BQU0sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQ3hCLENBQUM7SUFFRCwwQ0FBaUIsR0FBakIsVUFBa0IsSUFBYTtRQUEvQixpQkFjQztRQWJDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSTthQUNiLE1BQU0sQ0FDTCxJQUFJLENBQUMsT0FBTyxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsRUFBRSxFQUM1QixFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsRUFBRSxDQUNyQzthQUNBLElBQUksQ0FDSCxlQUFHLENBQUMsVUFBQSxJQUFJO1lBQ04sSUFBSSxLQUFLLEdBQUcsS0FBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDeEMsS0FBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQyxDQUFDO1lBQy9CLEtBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUN4QixDQUFDLENBQUMsRUFDRixzQkFBVSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FDOUIsQ0FBQztJQUNOLENBQUM7SUFFTyw0QkFBRyxHQUFYLFVBQVksT0FBZ0I7UUFDMUIsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUNsQixJQUFJLENBQUMsT0FBTyxHQUFHLEdBQUcsR0FBRyxPQUFPLENBQUMsRUFBRSxFQUMvQixJQUFJLENBQUMsU0FBUyxDQUFDO1lBQ2IsSUFBSSxFQUFFLE9BQU8sQ0FBQyxJQUFJO1lBQ2xCLElBQUksRUFBRSxPQUFPLENBQUMsSUFBSTtZQUNsQixPQUFPLEVBQUUsT0FBTyxDQUFDLE9BQU87U0FDekIsQ0FBQyxFQUNGLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxFQUFFLENBQ3JDO2FBQ0EsSUFBSSxDQUFDLHNCQUFVLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUM7SUFDdkMsQ0FBQztJQUVPLHVDQUFjLEdBQXRCO1FBQUEsaUJBTUM7UUFMQyxvR0FBb0c7UUFDcEcsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7WUFDWiwwQ0FBMEM7WUFDMUMsS0FBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUssS0FBSSxDQUFDLFFBQVEsU0FBRSxDQUFDO1FBQ3RDLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVPLHlDQUFnQixHQUF4QjtRQUNFLE1BQU0sQ0FBQyxJQUFJLGtCQUFXLENBQUM7WUFDckIsY0FBYyxFQUFFLGtCQUFrQjtZQUNsQyxlQUFlLEVBQUUsU0FBUyxHQUFHLHVCQUFjLENBQUMsS0FBSztTQUNsRCxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRU8scUNBQVksR0FBcEIsVUFBcUIsS0FBd0I7UUFDM0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUNuQixNQUFNLENBQUMsaUNBQWUsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDdkMsQ0FBQztJQTVIVSxjQUFjO1FBRDFCLGlCQUFVLEVBQUU7eUNBTWUsaUJBQVUsRUFBZ0IsYUFBTTtPQUwvQyxjQUFjLENBNkgxQjtJQUFELHFCQUFDO0NBQUEsQUE3SEQsSUE2SEM7QUE3SFksd0NBQWMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlLCBOZ1pvbmUgfSBmcm9tIFwiQGFuZ3VsYXIvY29yZVwiO1xuaW1wb3J0IHtcbiAgSHR0cENsaWVudCxcbiAgSHR0cEhlYWRlcnMsXG4gIEh0dHBFcnJvclJlc3BvbnNlLFxuICBIdHRwUGFyYW1zLFxufSBmcm9tIFwiQGFuZ3VsYXIvY29tbW9uL2h0dHBcIjtcbmltcG9ydCB7IEJlaGF2aW9yU3ViamVjdCB9IGZyb20gXCJyeGpzL0JlaGF2aW9yU3ViamVjdFwiO1xuaW1wb3J0IHsgT2JzZXJ2YWJsZSB9IGZyb20gJ3J4anMvT2JzZXJ2YWJsZSc7XG5cblxuaW1wb3J0IHsgbWFwLCBjYXRjaEVycm9yIH0gZnJvbSBcInJ4anMvb3BlcmF0b3JzXCI7XG5pbXBvcnQgeyBFcnJvck9ic2VydmFibGUgfSBmcm9tIFwicnhqcy9vYnNlcnZhYmxlL0Vycm9yT2JzZXJ2YWJsZVwiO1xuXG5pbXBvcnQgeyBCYWNrZW5kU2VydmljZSB9IGZyb20gXCIuLi8uLi9zaGFyZWRcIjtcbmltcG9ydCB7IEdyb2NlcnkgfSBmcm9tIFwiLi9ncm9jZXJ5Lm1vZGVsXCI7XG5cbkBJbmplY3RhYmxlKClcbmV4cG9ydCBjbGFzcyBHcm9jZXJ5U2VydmljZSB7XG4gIGl0ZW1zOiBCZWhhdmlvclN1YmplY3Q8QXJyYXk8R3JvY2VyeT4+ID0gbmV3IEJlaGF2aW9yU3ViamVjdChbXSk7XG4gIHByaXZhdGUgYWxsSXRlbXM6IEFycmF5PEdyb2Nlcnk+ID0gW107XG4gIGJhc2VVcmwgPSBCYWNrZW5kU2VydmljZS5iYXNlVXJsICsgXCJhcHBkYXRhL1wiICsgQmFja2VuZFNlcnZpY2UuYXBwS2V5ICsgXCIvR3JvY2VyaWVzXCI7XG5cbiAgY29uc3RydWN0b3IocHJpdmF0ZSBodHRwOiBIdHRwQ2xpZW50LCBwcml2YXRlIHpvbmU6IE5nWm9uZSkgeyB9XG5cbiAgbG9hZCgpIHtcbiAgICBjb25zdCBwYXJhbXMgPSBuZXcgSHR0cFBhcmFtcygpO1xuICAgIHBhcmFtcy5hcHBlbmQoXCJzb3J0XCIsIFwie1xcXCJfa21kLmxtdFxcXCI6IC0xfVwiKTtcblxuICAgIHJldHVybiB0aGlzLmh0dHAuZ2V0KHRoaXMuYmFzZVVybCwge1xuICAgICAgaGVhZGVyczogdGhpcy5nZXRDb21tb25IZWFkZXJzKCksXG4gICAgICBwYXJhbXMsXG4gICAgfSlcbiAgICAucGlwZShcbiAgICAgIG1hcCgoZGF0YTogYW55W10pID0+IHtcbiAgICAgICAgZGF0YS5mb3JFYWNoKChncm9jZXJ5KSA9PiB7XG4gICAgICAgICAgdGhpcy5hbGxJdGVtcy5wdXNoKFxuICAgICAgICAgICAgbmV3IEdyb2NlcnkoXG4gICAgICAgICAgICAgIGdyb2NlcnkuX2lkLFxuICAgICAgICAgICAgICBncm9jZXJ5Lk5hbWUsXG4gICAgICAgICAgICAgIGdyb2NlcnkuRG9uZSB8fCBmYWxzZSxcbiAgICAgICAgICAgICAgZ3JvY2VyeS5EZWxldGVkIHx8IGZhbHNlXG4gICAgICAgICAgICApXG4gICAgICAgICAgKTtcbiAgICAgICAgICB0aGlzLnB1Ymxpc2hVcGRhdGVzKCk7XG4gICAgICAgIH0pO1xuICAgICAgfSksXG4gICAgICBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3JzKVxuICAgICk7XG4gIH1cblxuICBhZGQobmFtZTogc3RyaW5nKSB7XG4gICAgcmV0dXJuIHRoaXMuaHR0cC5wb3N0KFxuICAgICAgdGhpcy5iYXNlVXJsLFxuICAgICAgSlNPTi5zdHJpbmdpZnkoeyBOYW1lOiBuYW1lIH0pLFxuICAgICAgeyBoZWFkZXJzOiB0aGlzLmdldENvbW1vbkhlYWRlcnMoKSB9XG4gICAgKVxuICAgIC5waXBlKFxuICAgICAgbWFwKChkYXRhOiBhbnkpID0+IHtcbiAgICAgICAgdGhpcy5hbGxJdGVtcy51bnNoaWZ0KG5ldyBHcm9jZXJ5KGRhdGEuX2lkLCBuYW1lLCBmYWxzZSwgZmFsc2UpKTtcbiAgICAgICAgdGhpcy5wdWJsaXNoVXBkYXRlcygpO1xuICAgICAgfSksXG4gICAgICBjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3JzKVxuICAgICk7XG4gIH1cblxuICBzZXREZWxldGVGbGFnKGl0ZW06IEdyb2NlcnkpIHtcbiAgICBpdGVtLmRlbGV0ZWQgPSB0cnVlO1xuICAgIHJldHVybiB0aGlzLnB1dChpdGVtKVxuICAgICAgLnBpcGUoXG4gICAgICAgIG1hcChkYXRhID0+IHtcbiAgICAgICAgICBpdGVtLmRvbmUgPSBmYWxzZTtcbiAgICAgICAgICB0aGlzLnB1Ymxpc2hVcGRhdGVzKCk7XG4gICAgICAgIH0pXG4gICAgICApO1xuICB9XG5cbiAgdW5zZXREZWxldGVGbGFnKGl0ZW06IEdyb2NlcnkpIHtcbiAgICBpdGVtLmRlbGV0ZWQgPSBmYWxzZTtcbiAgICByZXR1cm4gdGhpcy5wdXQoaXRlbSlcbiAgICAgIC5waXBlKFxuICAgICAgICBtYXAoZGF0YSA9PiB7XG4gICAgICAgICAgaXRlbS5kb25lID0gZmFsc2U7XG4gICAgICAgICAgdGhpcy5wdWJsaXNoVXBkYXRlcygpO1xuICAgICAgICB9KVxuICAgICAgKTtcbiAgfVxuXG5cbiAgdG9nZ2xlRG9uZUZsYWcoaXRlbTogR3JvY2VyeSkge1xuICAgIGl0ZW0uZG9uZSA9ICFpdGVtLmRvbmU7XG4gICAgdGhpcy5wdWJsaXNoVXBkYXRlcygpO1xuICAgIHJldHVybiB0aGlzLnB1dChpdGVtKTtcbiAgfVxuXG4gIHBlcm1hbmVudGx5RGVsZXRlKGl0ZW06IEdyb2NlcnkpIHtcbiAgICByZXR1cm4gdGhpcy5odHRwXG4gICAgICAuZGVsZXRlKFxuICAgICAgICB0aGlzLmJhc2VVcmwgKyBcIi9cIiArIGl0ZW0uaWQsXG4gICAgICAgIHsgaGVhZGVyczogdGhpcy5nZXRDb21tb25IZWFkZXJzKCkgfVxuICAgICAgKVxuICAgICAgLnBpcGUoXG4gICAgICAgIG1hcChkYXRhID0+IHtcbiAgICAgICAgICBsZXQgaW5kZXggPSB0aGlzLmFsbEl0ZW1zLmluZGV4T2YoaXRlbSk7XG4gICAgICAgICAgdGhpcy5hbGxJdGVtcy5zcGxpY2UoaW5kZXgsIDEpO1xuICAgICAgICAgIHRoaXMucHVibGlzaFVwZGF0ZXMoKTtcbiAgICAgICAgfSksXG4gICAgICAgIGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcnMpXG4gICAgICApO1xuICB9XG5cbiAgcHJpdmF0ZSBwdXQoZ3JvY2VyeTogR3JvY2VyeSkge1xuICAgIHJldHVybiB0aGlzLmh0dHAucHV0KFxuICAgICAgdGhpcy5iYXNlVXJsICsgXCIvXCIgKyBncm9jZXJ5LmlkLFxuICAgICAgSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICBOYW1lOiBncm9jZXJ5Lm5hbWUsXG4gICAgICAgIERvbmU6IGdyb2NlcnkuZG9uZSxcbiAgICAgICAgRGVsZXRlZDogZ3JvY2VyeS5kZWxldGVkXG4gICAgICB9KSxcbiAgICAgIHsgaGVhZGVyczogdGhpcy5nZXRDb21tb25IZWFkZXJzKCkgfVxuICAgIClcbiAgICAucGlwZShjYXRjaEVycm9yKHRoaXMuaGFuZGxlRXJyb3JzKSk7XG4gIH1cblxuICBwcml2YXRlIHB1Ymxpc2hVcGRhdGVzKCkge1xuICAgIC8vIE1ha2Ugc3VyZSBhbGwgdXBkYXRlcyBhcmUgcHVibGlzaGVkIGluc2lkZSBOZ1pvbmUgc28gdGhhdCBjaGFuZ2UgZGV0ZWN0aW9uIGlzIHRyaWdnZXJlZCBpZiBuZWVkZWRcbiAgICB0aGlzLnpvbmUucnVuKCgpID0+IHtcbiAgICAgIC8vIG11c3QgZW1pdCBhICpuZXcqIHZhbHVlIChpbW11dGFiaWxpdHkhKVxuICAgICAgdGhpcy5pdGVtcy5uZXh0KFsuLi50aGlzLmFsbEl0ZW1zXSk7XG4gICAgfSk7XG4gIH1cblxuICBwcml2YXRlIGdldENvbW1vbkhlYWRlcnMoKSB7XG4gICAgcmV0dXJuIG5ldyBIdHRwSGVhZGVycyh7XG4gICAgICBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIixcbiAgICAgIFwiQXV0aG9yaXphdGlvblwiOiBcIktpbnZleSBcIiArIEJhY2tlbmRTZXJ2aWNlLnRva2VuLFxuICAgIH0pO1xuICB9XG5cbiAgcHJpdmF0ZSBoYW5kbGVFcnJvcnMoZXJyb3I6IEh0dHBFcnJvclJlc3BvbnNlKSB7XG4gICAgY29uc29sZS5sb2coZXJyb3IpO1xuICAgIHJldHVybiBFcnJvck9ic2VydmFibGUuY3JlYXRlKGVycm9yKTtcbiAgfVxufVxuIl19