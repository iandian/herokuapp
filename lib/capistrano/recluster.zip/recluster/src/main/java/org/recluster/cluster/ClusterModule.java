/* 
 * The MIT License
 *
 * Copyright 2017 apex-yu.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package org.recluster.cluster;

//import org.recluster.cluster.action.index.MappingUpdatedAction;
//import org.recluster.cluster.action.index.NodeMappingRefreshAction;
////import org.recluster.cluster.action.shard.ShardStateAction;
//import org.recluster.cluster.metadata.IndexGraveyard;
//import org.recluster.cluster.metadata.IndexNameExpressionResolver;
import org.recluster.cluster.metadata.MetaData;
//import org.recluster.cluster.metadata.MetaDataCreateIndexService;
//import org.recluster.cluster.metadata.MetaDataDeleteIndexService;
//import org.recluster.cluster.metadata.MetaDataIndexAliasesService;
//import org.recluster.cluster.metadata.MetaDataIndexStateService;
//import org.recluster.cluster.metadata.MetaDataIndexTemplateService;
import org.recluster.cluster.metadata.MetaDataMappingService;
import org.recluster.cluster.metadata.MetaDataUpdateSettingsService;
import org.recluster.cluster.metadata.RepositoriesMetaData;
import org.recluster.cluster.routing.DelayedAllocationService;
import org.recluster.cluster.routing.RoutingService;
import org.recluster.cluster.routing.allocation.AllocationService;
//import org.recluster.cluster.routing.allocation.allocator.BalancedShardsAllocator;
//import org.recluster.cluster.routing.allocation.allocator.ShardsAllocator;
import org.recluster.cluster.routing.allocation.decider.AllocationDecider;
import org.recluster.cluster.routing.allocation.decider.AllocationDeciders;
import org.recluster.cluster.routing.allocation.decider.AwarenessAllocationDecider;
import org.recluster.cluster.routing.allocation.decider.ClusterRebalanceAllocationDecider;
import org.recluster.cluster.routing.allocation.decider.ConcurrentRebalanceAllocationDecider;
import org.recluster.cluster.routing.allocation.decider.DiskThresholdDecider;
import org.recluster.cluster.routing.allocation.decider.EnableAllocationDecider;
import org.recluster.cluster.routing.allocation.decider.FilterAllocationDecider;
import org.recluster.cluster.routing.allocation.decider.MaxRetryAllocationDecider;
import org.recluster.cluster.routing.allocation.decider.NodeVersionAllocationDecider;
import org.recluster.cluster.routing.allocation.decider.RebalanceOnlyWhenActiveAllocationDecider;
import org.recluster.cluster.routing.allocation.decider.ReplicaAfterPrimaryActiveAllocationDecider;
import org.recluster.cluster.routing.allocation.decider.ResizeAllocationDecider;
//import org.recluster.cluster.routing.allocation.decider.SameShardAllocationDecider;
//import org.recluster.cluster.routing.allocation.decider.ShardsLimitAllocationDecider;
//import org.recluster.cluster.routing.allocation.decider.SnapshotInProgressAllocationDecider;
import org.recluster.cluster.routing.allocation.decider.ThrottlingAllocationDecider;
import org.recluster.cluster.service.ClusterService;
import org.recluster.common.ParseField;
import org.recluster.common.inject.AbstractModule;
import org.recluster.common.io.stream.NamedWriteable;
import org.recluster.common.io.stream.NamedWriteableRegistry.Entry;
import org.recluster.common.io.stream.Writeable.Reader;
import org.recluster.common.settings.ClusterSettings;
import org.recluster.common.settings.Setting;
import org.recluster.common.settings.Setting.Property;
import org.recluster.common.settings.Settings;
import org.recluster.common.xcontent.NamedXContentRegistry;
import org.recluster.gateway.GatewayAllocator;
//import org.recluster.ingest.IngestMetadata;
//import org.recluster.plugins.ClusterPlugin;
//import org.recluster.script.ScriptMetaData;
//import org.recluster.tasks.TaskResultsService;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.function.Supplier;

/**
 * Configures classes and services that affect the entire cluster.
 */
public class ClusterModule extends AbstractModule {

    public static final String BALANCED_ALLOCATOR = "balanced"; // default
    public static final Setting<String> SHARDS_ALLOCATOR_TYPE_SETTING =
        new Setting<>("cluster.routing.allocation.type", BALANCED_ALLOCATOR, Function.identity(), Property.NodeScope);

    private final ClusterService clusterService;
//    private final IndexNameExpressionResolver indexNameExpressionResolver;
    private final AllocationDeciders allocationDeciders;
    private final AllocationService allocationService;
    // pkg private for tests
    final Collection<AllocationDecider> deciderList;
//    final ShardsAllocator shardsAllocator;

    public ClusterModule(Settings settings, ClusterService clusterService,
                         ClusterInfoService clusterInfoService) {
        this.deciderList = createAllocationDeciders(settings, clusterService.getClusterSettings());
        this.allocationDeciders = new AllocationDeciders(settings, deciderList);
//        this.shardsAllocator = createShardsAllocator(settings, clusterService.getClusterSettings(), clusterPlugins);
        this.clusterService = clusterService;
//        this.indexNameExpressionResolver = new IndexNameExpressionResolver(settings);
        this.allocationService = new AllocationService(settings, allocationDeciders, clusterInfoService);
    }

    public static Map<String, Supplier<ClusterState.Custom>> getClusterStateCustomSuppliers(List<String> clusterPlugins) {
        final Map<String, Supplier<ClusterState.Custom>> customSupplier = new HashMap<>();
//        for (ClusterPlugin plugin : clusterPlugins) {
//            Map<String, Supplier<ClusterState.Custom>> initialCustomSupplier = plugin.getInitialClusterStateCustomSupplier();
//            for (String key : initialCustomSupplier.keySet()) {
//                if (customSupplier.containsKey(key)) {
//                    throw new IllegalStateException("custom supplier key [" + key + "] is registered more than once");
//                }
//            }
//            customSupplier.putAll(initialCustomSupplier);
//        }
        return Collections.unmodifiableMap(customSupplier);
    }

    public static List<Entry> getNamedWriteables() {
        List<Entry> entries = new ArrayList<>();
        // Metadata
        registerMetaDataCustom(entries, RepositoriesMetaData.TYPE, RepositoriesMetaData::new, RepositoriesMetaData::readDiffFrom);
//        registerMetaDataCustom(entries, IndexGraveyard.TYPE, IndexGraveyard::new, IndexGraveyard::readDiffFrom);
        return entries;
    }

    public static List<NamedXContentRegistry.Entry> getNamedXWriteables() {
        List<NamedXContentRegistry.Entry> entries = new ArrayList<>();
        // Metadata
        entries.add(new NamedXContentRegistry.Entry(MetaData.Custom.class, new ParseField(RepositoriesMetaData.TYPE),
            RepositoriesMetaData::fromXContent));
//        entries.add(new NamedXContentRegistry.Entry(MetaData.Custom.class, new ParseField(IngestMetadata.TYPE),
//            IngestMetadata::fromXContent));
//        entries.add(new NamedXContentRegistry.Entry(MetaData.Custom.class, new ParseField(ScriptMetaData.TYPE),
//            ScriptMetaData::fromXContent));
//        entries.add(new NamedXContentRegistry.Entry(MetaData.Custom.class, new ParseField(IndexGraveyard.TYPE),
//            IndexGraveyard::fromXContent));
        return entries;
    }

    private static <T extends ClusterState.Custom> void registerClusterCustom(List<Entry> entries, String name, Reader<? extends T> reader,
                                                                       Reader<NamedDiff> diffReader) {
        registerCustom(entries, ClusterState.Custom.class, name, reader, diffReader);
    }

    private static <T extends MetaData.Custom> void registerMetaDataCustom(List<Entry> entries, String name, Reader<? extends T> reader,
                                                                       Reader<NamedDiff> diffReader) {
        registerCustom(entries, MetaData.Custom.class, name, reader, diffReader);
    }

    private static <T extends NamedWriteable> void registerCustom(List<Entry> entries, Class<T> category, String name,
                                                                  Reader<? extends T> reader, Reader<NamedDiff> diffReader) {
        entries.add(new Entry(category, name, reader));
        entries.add(new Entry(NamedDiff.class, name, diffReader));
    }

    // TODO: this is public so allocation benchmark can access the default deciders...can we do that in another way?
    /** Return a new {@link AllocationDecider} instance with builtin deciders as well as those from plugins. */
    public static Collection<AllocationDecider> createAllocationDeciders(Settings settings, ClusterSettings clusterSettings) {
        // collect deciders by class so that we can detect duplicates
        Map<Class, AllocationDecider> deciders = new LinkedHashMap<>();
        addAllocationDecider(deciders, new MaxRetryAllocationDecider(settings));
        addAllocationDecider(deciders, new ResizeAllocationDecider(settings));
        addAllocationDecider(deciders, new ReplicaAfterPrimaryActiveAllocationDecider(settings));
        addAllocationDecider(deciders, new RebalanceOnlyWhenActiveAllocationDecider(settings));
        addAllocationDecider(deciders, new ClusterRebalanceAllocationDecider(settings, clusterSettings));
        addAllocationDecider(deciders, new ConcurrentRebalanceAllocationDecider(settings, clusterSettings));
        addAllocationDecider(deciders, new EnableAllocationDecider(settings, clusterSettings));
        addAllocationDecider(deciders, new NodeVersionAllocationDecider(settings));
//        addAllocationDecider(deciders, new SnapshotInProgressAllocationDecider(settings));
        addAllocationDecider(deciders, new FilterAllocationDecider(settings, clusterSettings));
//        addAllocationDecider(deciders, new SameShardAllocationDecider(settings, clusterSettings));
        addAllocationDecider(deciders, new DiskThresholdDecider(settings, clusterSettings));
        addAllocationDecider(deciders, new ThrottlingAllocationDecider(settings, clusterSettings));
//        addAllocationDecider(deciders, new ShardsLimitAllocationDecider(settings, clusterSettings));
        addAllocationDecider(deciders, new AwarenessAllocationDecider(settings, clusterSettings));

//        clusterPlugins.stream()
//            .flatMap(p -> p.createAllocationDeciders(settings, clusterSettings).stream())
//            .forEach(d -> addAllocationDecider(deciders, d));

        return deciders.values();
    }

    /** Add the given allocation decider to the given deciders collection, erroring if the class name is already used. */
    private static void addAllocationDecider(Map<Class, AllocationDecider> deciders, AllocationDecider decider) {
        if (deciders.put(decider.getClass(), decider) != null) {
            throw new IllegalArgumentException("Cannot specify allocation decider [" + decider.getClass().getName() + "] twice");
        }
    }

    public AllocationService getAllocationService() {
        return allocationService;
    }

    @Override
    protected void configure() {
        bind(GatewayAllocator.class).asEagerSingleton();
        bind(AllocationService.class).toInstance(allocationService);
        bind(ClusterService.class).toInstance(clusterService);
        bind(NodeConnectionsService.class).asEagerSingleton();
//        bind(MetaDataCreateIndexService.class).asEagerSingleton();
//        bind(MetaDataDeleteIndexService.class).asEagerSingleton();
//        bind(MetaDataIndexStateService.class).asEagerSingleton();
        bind(MetaDataMappingService.class).asEagerSingleton();
//        bind(MetaDataIndexAliasesService.class).asEagerSingleton();
        bind(MetaDataUpdateSettingsService.class).asEagerSingleton();
//        bind(MetaDataIndexTemplateService.class).asEagerSingleton();
//        bind(IndexNameExpressionResolver.class).toInstance(indexNameExpressionResolver);
        bind(RoutingService.class).asEagerSingleton();
        bind(DelayedAllocationService.class).asEagerSingleton();
//        bind(ShardStateAction.class).asEagerSingleton();
//        bind(NodeMappingRefreshAction.class).asEagerSingleton();
//        bind(MappingUpdatedAction.class).asEagerSingleton();
//        bind(TaskResultsService.class).asEagerSingleton();
        bind(AllocationDeciders.class).toInstance(allocationDeciders);
//        bind(ShardsAllocator.class).toInstance(shardsAllocator);
    }
}
