module V1
  class Results < Grape::API
    include V1Base
	include ResultBase

    VALID_PARAMS = %w(value build_id)

    helpers do
      def result_params
        params.select{|key,value| VALID_PARAMS.include?(key.to_s)}
      end
	  
	  
    end
	
    resource :results do

      desc 'Create new result', http_codes: [
        { code: 200, message: 'success' },
        { code: RESPONSE_CODE[:unprocessable_entity], message: 'Detail error messages' }
      ]
      params do
        optional :name, type: String, desc: 'result name'
      end
      post :rabl => "result/show.rabl" do
        create_result(result_params)
      end


      desc 'Get result', headers: HEADERS_DOCS, http_codes: [
        { code: 200, message: 'success' },
        { code: RESPONSE_CODE[:not_found], message: I18n.t('errors.not_found') }
      ]
      params do
        requires :id, type: String, desc: 'result id'
      end
      get ':id', :rabl => "result/show.rabl" do
	    logger.info "start to get result with id #{params[:id]}"
        get_result(params[:id])
      end

	  
    end
	
  end
end