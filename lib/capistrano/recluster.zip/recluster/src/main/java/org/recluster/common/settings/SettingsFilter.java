/* 
 * The MIT License
 *
 * Copyright 2017 apex-yu.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package org.recluster.common.settings;

import org.recluster.common.Strings;
import org.recluster.common.component.AbstractComponent;
import org.recluster.common.regex.Regex;
import org.recluster.common.xcontent.ToXContent.Params;
import org.recluster.rest.RestRequest;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

/**
 * A class that allows to filter settings objects by simple regular expression patterns or full settings keys.
 * It's used for response filtering on the rest layer to for instance filter out sensitive information like access keys.
 */
public final class SettingsFilter extends AbstractComponent {
    /**
     * Can be used to specify settings filter that will be used to filter out matching settings in toXContent method
     */
    public static String SETTINGS_FILTER_PARAM = "settings_filter";

    private final Set<String> patterns;
    private final String patternString;

    public SettingsFilter(Settings settings, Collection<String> patterns) {
        super(settings);
        for (String pattern : patterns) {
            if (isValidPattern(pattern) == false) {
                throw new IllegalArgumentException("invalid pattern: " + pattern);
            }
        }
        this.patterns = Collections.unmodifiableSet(new HashSet<>(patterns));
        patternString = Strings.collectionToDelimitedString(patterns, ",");
    }

    /**
     * Returns a set of patterns
     */
    public Set<String> getPatterns() {
        return patterns;
    }

    /**
     * Returns <code>true</code> iff the given string is either a valid settings key pattern or a simple regular expression
     * @see Regex
     * @see AbstractScopedSettings#isValidKey(String)
     */
    public static boolean isValidPattern(String pattern) {
        return AbstractScopedSettings.isValidKey(pattern) || Regex.isSimpleMatchPattern(pattern);
    }

    public void addFilterSettingParams(RestRequest request) {
        if (patterns.isEmpty() == false) {
            request.params().put(SETTINGS_FILTER_PARAM, patternString);
        }
    }

    public static Settings filterSettings(Params params, Settings settings) {
        String patterns = params.param(SETTINGS_FILTER_PARAM);
        final Settings filteredSettings;
        if (patterns != null && patterns.isEmpty() == false) {
            filteredSettings = filterSettings(Strings.commaDelimitedListToSet(patterns), settings);
        } else {
            filteredSettings = settings;
        }
        return filteredSettings;
    }

    public Settings filter(Settings settings) {
        return filterSettings(patterns, settings);
    }

    private static Settings filterSettings(Iterable<String> patterns, Settings settings) {
        Settings.Builder builder = Settings.builder().put(settings);
        List<String> simpleMatchPatternList = new ArrayList<>();
        for (String pattern : patterns) {
            if (Regex.isSimpleMatchPattern(pattern)) {
                simpleMatchPatternList.add(pattern);
            } else {
                builder.remove(pattern);
            }
        }
        if (!simpleMatchPatternList.isEmpty()) {
            String[] simpleMatchPatterns = simpleMatchPatternList.toArray(new String[simpleMatchPatternList.size()]);
            Iterator<String> iterator = builder.keys().iterator();
            while (iterator.hasNext()) {
                String key = iterator.next();
                if (Regex.simpleMatch(simpleMatchPatterns, key)) {
                    iterator.remove();
                }
            }
        }
        return builder.build();
    }
}
