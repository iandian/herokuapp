# encoding: utf-8
require "rails_helper"

describe "Run Record APIs"  do
  before(:each) {
    @run_record_attributes = FactoryGirl.attributes_for :run_record
  }

  describe "POST #create" do

    context "when is successfully created" do
      after do
        expect(json_response[:meta][:code]).to eql RESPONSE_CODE[:success]
      end

      it "render created run record" do
        post "/api/run_records", params: @run_record_attributes.to_json, headers: request_headers

        json_data = json_response[:data][:run_record]

        expect(json_data[:name]).to eql @run_record_attributes[:name]
      end
    end

    context "when has error" do
      it "render unprocessable_entity error when name value is missing" do
        @run_record_attributes[:name] = ""
        post "/api/run_records", params: @run_record_attributes.to_json, headers: request_headers

        json_data = json_response[:data]

        expect(json_data.blank?).to eql true

        expect(json_response[:meta][:code]).to eql RESPONSE_CODE[:unprocessable_entity]
        expect(json_response[:meta][:message].downcase).to include "name"
      end
    end
  end
end