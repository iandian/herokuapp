
package com.emc.esindexer.crawler.beans;

/**
 * Represents additional file attributes.
 */
public class Attributes {

    /**
     * Generated json field names
     */
    static public final class FIELD_NAMES {
        public static final String OWNER = "owner";
        public static final String GROUP = "group";
    }

    private String owner;
    private String group;

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public String getGroup() {
        return group;
    }

    public void setGroup(String group) {
        this.group = group;
    }
}
