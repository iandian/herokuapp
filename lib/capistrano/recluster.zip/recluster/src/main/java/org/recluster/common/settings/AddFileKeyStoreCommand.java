///* 
// * The MIT License
// *
// * Copyright 2017 apex-yu.
// *
// * Permission is hereby granted, free of charge, to any person obtaining a copy
// * of this software and associated documentation files (the "Software"), to deal
// * in the Software without restriction, including without limitation the rights
// * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// * copies of the Software, and to permit persons to whom the Software is
// * furnished to do so, subject to the following conditions:
// *
// * The above copyright notice and this permission notice shall be included in
// * all copies or substantial portions of the Software.
// *
// * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// * THE SOFTWARE.
// */
//package org.recluster.common.settings;
//
//import java.io.BufferedReader;
//import java.io.File;
//import java.io.InputStream;
//import java.io.InputStreamReader;
//import java.nio.charset.StandardCharsets;
//import java.nio.file.Files;
//import java.nio.file.Path;
//import java.nio.file.Paths;
//import java.util.Arrays;
//import java.util.List;
//
//import org.recluster.common.SuppressForbidden;
//import org.recluster.common.io.PathUtils;
//import org.recluster.env.Environment;
//
///**
// * A subcommand for the keystore cli which adds a file setting.
// */
//class AddFileKeyStoreCommand extends EnvironmentAwareCommand {
//
//    private final OptionSpec<Void> forceOption;
//    private final OptionSpec<String> arguments;
//
//    AddFileKeyStoreCommand() {
//        super("Add a file setting to the keystore");
//        this.forceOption = parser.acceptsAll(Arrays.asList("f", "force"), "Overwrite existing setting without prompting");
//        // jopt simple has issue with multiple non options, so we just get one set of them here
//        // and convert to File when necessary
//        // see https://github.com/jopt-simple/jopt-simple/issues/103
//        this.arguments = parser.nonOptions("setting [filepath]");
//    }
//
//    @Override
//    protected void execute(Terminal terminal, OptionSet options, Environment env) throws Exception {
//        KeyStoreWrapper keystore = KeyStoreWrapper.load(env.configFile());
//        if (keystore == null) {
//            if (options.has(forceOption) == false &&
//                terminal.promptYesNo("The recluster keystore does not exist. Do you want to create it?", false) == false) {
//                terminal.println("Exiting without creating keystore.");
//                return;
//            }
//            keystore = KeyStoreWrapper.create(new char[0] /* always use empty passphrase for auto created keystore */);
//            keystore.save(env.configFile());
//            terminal.println("Created recluster keystore in " + env.configFile());
//        } else {
//            keystore.decrypt(new char[0] /* TODO: prompt for password when they are supported */);
//        }
//
//        List<String> argumentValues = arguments.values(options);
//        if (argumentValues.size() == 0) {
//            throw new UserException(ExitCodes.USAGE, "Missing setting name");
//        }
//        String setting = argumentValues.get(0);
//        if (keystore.getSettingNames().contains(setting) && options.has(forceOption) == false) {
//            if (terminal.promptYesNo("Setting " + setting + " already exists. Overwrite?", false) == false) {
//                terminal.println("Exiting without modifying keystore.");
//                return;
//            }
//        }
//
//        if (argumentValues.size() == 1) {
//            throw new UserException(ExitCodes.USAGE, "Missing file name");
//        }
//        Path file = getPath(argumentValues.get(1));
//        if (Files.exists(file) == false) {
//            throw new UserException(ExitCodes.IO_ERROR, "File [" + file.toString() + "] does not exist");
//        }
//        if (argumentValues.size() > 2) {
//            throw new UserException(ExitCodes.USAGE, "Unrecognized extra arguments [" +
//                String.join(", ", argumentValues.subList(2, argumentValues.size())) + "] after filepath");
//        }
//        keystore.setFile(setting, Files.readAllBytes(file));
//        keystore.save(env.configFile());
//    }
//
//    @SuppressForbidden(reason="file arg for cli")
//    private Path getPath(String file) {
//        return PathUtils.get(file);
//    }
//}
