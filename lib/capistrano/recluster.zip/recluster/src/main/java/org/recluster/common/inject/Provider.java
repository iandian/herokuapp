/* 
 * The MIT License
 *
 * Copyright 2017 apex-yu.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package org.recluster.common.inject;

/**
 * An object capable of providing instances of type {@code T}. Providers are used in numerous ways
 * by Guice:
 * <ul>
 * <li>When the default means for obtaining instances (an injectable or parameterless constructor)
 * is insufficient for a particular binding, the module can specify a custom {@code Provider}
 * instead, to control exactly how Guice creates or obtains instances for the binding.
 * <li>An implementation class may always choose to have a {@code Provider<T>} instance injected,
 * rather than having a {@code T} injected directly.  This may give you access to multiple
 * instances, instances you wish to safely mutate and discard, instances which are out of scope
 * (e.g. using a {@code @RequestScoped} object from within a {@code @SessionScoped} object), or
 * instances that will be initialized lazily.
 * <li>A custom {@link Scope} is implemented as a decorator of {@code Provider<T>}, which decides
 * when to delegate to the backing provider and when to provide the instance some other way.
 * <li>The {@link Injector} offers access to the {@code Provider<T>} it uses to fulfill requests
 * for a given key, via the {@link Injector#getProvider} methods.
 * </ul>
 *
 * @param <T> the type of object this provides
 * @author crazybob@google.com (Bob Lee)
 */
public interface Provider<T> {

    /**
     * Provides an instance of {@code T}. Must never return {@code null}.
     *
     * @throws OutOfScopeException when an attempt is made to access a scoped object while the scope
     *                             in question is not currently active
     * @throws ProvisionException  if an instance cannot be provided. Such exceptions include messages
     *                             and throwables to describe why provision failed.
     */
    T get();
}
