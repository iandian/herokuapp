# encoding: utf-8
require "rails_helper"

describe "Test Scene APIs"  do
  before(:each) {
  }

  describe "GET #show" do

    context "when success" do
      before(:each) do
        @test_scene = create :test_scene
      end

      it "render test_scene json" do
        get "/api/test_scenes/#{@test_scene.id}", params: {}, headers: request_headers

        json_data = json_response[:data][:test_scene]

        expect(json_data[:id]).to eql @test_scene.id
        expect(json_data[:name]).to eql @test_scene.name
        expect(json_data[:filename]).to eql @test_scene.filename
      end
    end

    context "when error" do
      after do
        expect(json_response[:meta][:code]).not_to eql RESPONSE_CODE[:success]
      end

      it "returns the error when test scene id is not found" do
        @test_scene = create :test_scene


        get "/api/test_scenes/1111", params: {}, headers: request_headers

        json_data = json_response[:data]

        expect(json_data.blank?).to eql true
        expect(json_response[:meta][:code]).to eql RESPONSE_CODE[:not_found]
        expect(json_response[:meta][:message]).to eql I18n.t("errors.testscene.not_found")
      end
    end
  end
end

