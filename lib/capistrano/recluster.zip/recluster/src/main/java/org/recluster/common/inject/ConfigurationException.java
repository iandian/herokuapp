/* 
 * The MIT License
 *
 * Copyright 2017 apex-yu.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package org.recluster.common.inject;

import org.recluster.common.inject.internal.Errors;
import org.recluster.common.inject.spi.Message;

import java.util.Collection;
import java.util.Locale;
import java.util.Set;

import static java.util.Collections.unmodifiableSet;
import static org.recluster.common.util.set.Sets.newHashSet;

/**
 * Thrown when a programming error such as a misplaced annotation, illegal binding, or unsupported
 * scope is found. Clients should catch this exception, log it, and stop execution.
 *
 * @author jessewilson@google.com (Jesse Wilson)
 * @since 2.0
 */
public final class ConfigurationException extends RuntimeException {
    private final Set<Message> messages;
    private Object partialValue = null;

    /**
     * Creates a ConfigurationException containing {@code messages}.
     */
    public ConfigurationException(Iterable<Message> messages) {
        this.messages = unmodifiableSet(newHashSet(messages));
        initCause(Errors.getOnlyCause(this.messages));
    }

    /**
     * Returns a copy of this configuration exception with the specified partial value.
     */
    public ConfigurationException withPartialValue(Object partialValue) {
        if (this.partialValue != null) {
            String message = String.format(Locale.ROOT, "Can't clobber existing partial value %s with %s", this.partialValue, partialValue);
            throw new IllegalStateException(message);
        }
        ConfigurationException result = new ConfigurationException(messages);
        result.partialValue = partialValue;
        return result;
    }

    /**
     * Returns messages for the errors that caused this exception.
     */
    public Collection<Message> getErrorMessages() {
        return messages;
    }

    /**
     * Returns a value that was only partially computed due to this exception. The caller can use
     * this while collecting additional configuration problems.
     *
     * @return the partial value, or {@code null} if none was set. The type of the partial value is
     *         specified by the throwing method.
     */
    @SuppressWarnings("unchecked") // this is *extremely* unsafe. We trust the caller here.
    public <E> E getPartialValue() {
        return (E) partialValue;
    }

    @Override
    public String getMessage() {
        return Errors.format("Guice configuration errors", messages);
    }
}