class TestPlanPolicy < ApplicationPolicy

end
