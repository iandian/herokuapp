require "tmpdir"
require "socket"

class Listener


  def run_job(payload)
    @job_definition = JobDefinition.new(payload)
    @reply_exchange = @bunny.exchange(@job_definition.reply_exchange_name, :auto_delete => true)

    copy_source_tree(@job_definition.sync)

    if !@syncer.success? || !run_after_sync
      clean_up
      return
    end

    create_worker_manager

    clean_up
  end


  private

  def run_after_sync
    log "Running after_sync callback..."
    begin
      callback_handler.after_sync
    rescue Exception => e
      log_error "Exception raised when running after_sync callback_handler. Please, check your script in #{@job_definition.callbacks[:after_sync]}:"
      log_error e.message
      log_error "\n" + e.backtrace.join("\n")

      reply = {:type => :exception,
        :hostname => Socket.gethostname,
        :message => "after_sync callback failed. Please, check your script in #{@job_definition.callbacks[:after_sync]}. Message: #{e.message}",
        :backtrace => e.backtrace.join("\n")
      }
      @reply_exchange.publish(Yajl::Encoder.encode(reply))
      return false
    end
    true
  end

  def callback_handler
    @callback_handler ||= CallbackHandler.new(@job_definition.callbacks)
  end

  def copy_source_tree(sync_configuration)
    log "Downloading source tree to temp directory..."
    @syncer = SourceTreeSyncer.new sync_configuration
    @syncer.sync
    if @syncer.success?
      log "Command '#{@syncer.sys_command}' completed successfully."
    else
      send_crash_message @reply_exchange, @syncer.output, @syncer.errors
      log_error "Command '#{@syncer.sys_command}' failed!"
      log_error "Stdout:\n#{@syncer.output}"
      log_error "Stderr:\n#{@syncer.errors}"
    end
  end

  def clean_up
    @syncer.remove_temp_dir
  end

  ERROR_FOOTER_TEXT = "\n***** See #{WorkerManager::STDERR_FILE} and #{WorkerManager::STDOUT_FILE} at '#{Socket.gethostname}' for complete output *****\n"
  def create_worker_manager
    log "Creating Worker Manager..."
	
	@mutex = Mutex.new

    @thread = Thread.new { start_worker_manager }

    _, status = Process.waitpid2 pid
    log "Worker Manager #{pid} finished"

    if status.exitstatus != 0
      exitstatus = status.exitstatus
      log_error "Worker Manager #{pid} crashed with exit status #{exitstatus}!"

      msg = report_crash @reply_exchange, :out_file => WorkerManager::STDOUT_FILE,
      :err_file => WorkerManager::STDERR_FILE, :footer_text => ERROR_FOOTER_TEXT

      log_error "Process output:\n#{msg}"
    end
  end
  
    def start_worker_manager
        @mutex.synchronize do
          
        end
    end

end
