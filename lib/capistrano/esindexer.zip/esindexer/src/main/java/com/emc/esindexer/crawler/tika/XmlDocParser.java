package com.emc.esindexer.crawler.tika;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.io.InputStream;
import java.util.Map;

import static com.emc.esindexer.crawler.common.MetaParser.mapper;

/**
 * Parse a XML document and generate a FSCrawler Doc
 */
public class XmlDocParser {

    private final static Logger logger = LogManager.getLogger(XmlDocParser.class);
    private static final ObjectMapper xmlMapper;

    static {
        xmlMapper = new XmlMapper();
    }

    private static Map<String, Object> asMap(InputStream stream) {
        try {
            return xmlMapper.readValue(stream, new TypeReference<Map<String, Object>>(){});
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static String generate(InputStream inputStream) throws IOException {
        logger.trace("Converting XML document [{}]");
        // Extracting XML content
        // See #185: https://github.com/dadoonet/fscrawler/issues/185

        Map<String, Object> map = asMap(inputStream);

        // Serialize to JSON
        String json = mapper.writeValueAsString(map);

        logger.trace("Generated JSON: {}", json);
        return json;
    }

    /**
     * Extracting XML content. See #185: https://github.com/dadoonet/fscrawler/issues/185
     * @param inputStream The XML Stream
     * @return The XML Content as a map
     * @throws IOException
     */
    public static Map generateMap(InputStream inputStream) throws IOException {
        logger.trace("Converting XML document [{}]");
        Map<String, Object> map = asMap(inputStream);

        logger.trace("Generated JSON: {}", map);
        return map;
    }
}
