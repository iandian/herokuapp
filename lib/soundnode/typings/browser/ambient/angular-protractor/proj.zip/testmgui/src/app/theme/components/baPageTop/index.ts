export * from './baPageTop.component';
