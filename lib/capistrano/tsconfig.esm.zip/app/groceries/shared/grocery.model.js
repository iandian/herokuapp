"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Grocery = /** @class */ (function () {
    function Grocery(id, name, done, deleted) {
        this.id = id;
        this.name = name;
        this.done = done;
        this.deleted = deleted;
    }
    return Grocery;
}());
exports.Grocery = Grocery;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3JvY2VyeS5tb2RlbC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImdyb2NlcnkubW9kZWwudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQTtJQUNFLGlCQUNTLEVBQVUsRUFDVixJQUFZLEVBQ1osSUFBYSxFQUNiLE9BQWdCO1FBSGhCLE9BQUUsR0FBRixFQUFFLENBQVE7UUFDVixTQUFJLEdBQUosSUFBSSxDQUFRO1FBQ1osU0FBSSxHQUFKLElBQUksQ0FBUztRQUNiLFlBQU8sR0FBUCxPQUFPLENBQVM7SUFDdEIsQ0FBQztJQUNOLGNBQUM7QUFBRCxDQUFDLEFBUEQsSUFPQztBQVBZLDBCQUFPIiwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGNsYXNzIEdyb2Nlcnkge1xuICBjb25zdHJ1Y3RvcihcbiAgICBwdWJsaWMgaWQ6IHN0cmluZyxcbiAgICBwdWJsaWMgbmFtZTogc3RyaW5nLFxuICAgIHB1YmxpYyBkb25lOiBib29sZWFuLFxuICAgIHB1YmxpYyBkZWxldGVkOiBib29sZWFuXG4gICkge31cbn0iXX0=