module TestUnitBase
  extend ActiveSupport::Concern

  included do

    helpers do
      def get_test_unit(id)
        @test_unit = TestUnit.find(id)

        unless @test_unit
          raise ApiException.new(
            http_status: RESPONSE_CODE[:not_found], 
            code: RESPONSE_CODE[:not_found], 
            message: I18n.t('errors.test_unit.not_found')
          )
        end
      end
	  
      def create_test_unit(params)
        @test_unit = TestUnit.new(params)

        unless @test_unit.save
          raise ApiException.new(
            http_status: RESPONSE_CODE[:not_found], 
            code: RESPONSE_CODE[:not_found], 
            message: I18n.t('errors.test_unit.not_found')
          )
        end
      end

    end
  end
end