# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from django.contrib.auth.models import User
import logging


logger = logging.getLogger(__name__)

#TODO
class OrderGoods(models.Model):
    order_id = models.IntegerField()
    goods_id = models.IntegerField()
    goods_name = models.CharField(max_length=120)
    goods_sn = models.CharField(max_length=60)
    product_id = models.IntegerField()
    number = models.SmallIntegerField()
    market_price = models.DecimalField(max_digits=10, decimal_places=2)
    retail_price = models.DecimalField(max_digits=10, decimal_places=2)
    goods_specifition_name_value = models.TextField()
    is_real = models.IntegerField()
    goods_specifition_ids = models.CharField(max_length=255)
    list_pic_url = models.CharField(max_length=255)

    class Meta:
        verbose_name = "Address"
        verbose_name_plural = "Address"

    def __unicode__(self):
        return '%s %s' % (self.name, self.address)