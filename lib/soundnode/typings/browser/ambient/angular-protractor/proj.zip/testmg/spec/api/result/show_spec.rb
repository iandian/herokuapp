# encoding: utf-8
require "rails_helper"

describe "Result APIs"  do
  before(:each) {
	@user = create(:user)
	@user.add_role :admin
  }

  describe "GET #show" do

    context "when success" do
      before(:each) do
        @result = create :result
      end

      it "render result json" do
        auth_get @user, "/api/results/#{@result.id}", params: {}, headers: request_headers

        json_data = json_response[:data][:result]

        expect(json_data[:id]).to eql @result.id
        expect(json_data[:value]).to eql @result.value
      end
    end

    context "when error" do
      after do
        expect(json_response[:meta][:code]).not_to eql RESPONSE_CODE[:success]
      end

      it "returns the error when result id is not found" do
        @result = create :result


        auth_get @user, "/api/results/1111", params: {}, headers: request_headers

        json_data = json_response[:data]

        expect(json_data.blank?).to eql true
        expect(json_response[:meta][:code]).to eql RESPONSE_CODE[:not_found]
        expect(json_response[:meta][:message]).to eql I18n.t("errors.result.not_found")
      end
    end
  end
end

