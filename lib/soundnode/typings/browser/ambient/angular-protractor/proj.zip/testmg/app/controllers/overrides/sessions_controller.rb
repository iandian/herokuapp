module Overrides
  class SessionsController < DeviseTokenAuth::SessionsController
  
    prepend_before_filter :allow_params_authentication!, only: :create
  
    before_action :set_user_by_token, :only => [:destroy]
    after_action :reset_session, :only => [:destroy]

    def new
      render_new_error
    end
	
    def create
      # Check
      field = (resource_params.keys.map(&:to_sym) & resource_class.authentication_keys).first

      @resource = nil
      if field
        q_value = resource_params[field]

        if resource_class.case_insensitive_keys.include?(field)
          q_value.downcase!
        end
		
		@resource = resource_class.find_for_ldap_authentication(resource_params)
      end

      if @resource && valid_params?(field, q_value)
        if (@resource.respond_to?(:valid_ldap_authentication?) && (!@resource.valid_ldap_authentication?(resource_params[:password])))
          render_create_error_bad_credentials
          return
        end
        # create client id
        @client_id = SecureRandom.urlsafe_base64(nil, false)
        @token     = SecureRandom.urlsafe_base64(nil, false)

        @resource.tokens[@client_id] = {
          token: BCrypt::Password.create(@token),
          expiry: (Time.now + DeviseTokenAuth.token_lifespan).to_i
        }
        @resource.save

        sign_in(:user, @resource, store: false, bypass: false)

        yield @resource if block_given?

        render_create_success
      else
        render_create_error_bad_credentials
      end
    end
	
    def destroy
      # remove auth instance variables so that after_action does not run
      user = remove_instance_variable(:@resource) if @resource
      client_id = remove_instance_variable(:@client_id) if @client_id
      remove_instance_variable(:@token) if @token

      if user && client_id && user.tokens[client_id]
        user.tokens.delete(client_id)
        user.save!

        yield user if block_given?

        render_destroy_success
      else
        render_destroy_error
      end
    end	
	
  end
end