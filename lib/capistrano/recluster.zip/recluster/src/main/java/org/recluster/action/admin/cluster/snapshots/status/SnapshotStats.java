/* 
 * The MIT License
 *
 * Copyright 2017 apex-yu.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package org.recluster.action.admin.cluster.snapshots.status;

import org.recluster.common.io.stream.StreamInput;
import org.recluster.common.io.stream.StreamOutput;
import org.recluster.common.io.stream.Streamable;
import org.recluster.common.xcontent.ToXContent;
import org.recluster.common.xcontent.ToXContentFragment;
import org.recluster.common.xcontent.XContentBuilder;
import org.recluster.index.snapshots.IndexShardSnapshotStatus;

import java.io.IOException;

public class SnapshotStats implements Streamable, ToXContentFragment {
    private long startTime;

    private long time;

    private int numberOfFiles;

    private int processedFiles;

    private long totalSize;

    private long processedSize;

    SnapshotStats() {
    }

    SnapshotStats(IndexShardSnapshotStatus indexShardStatus) {
        startTime = indexShardStatus.startTime();
        time = indexShardStatus.time();
        numberOfFiles = indexShardStatus.numberOfFiles();
        processedFiles = indexShardStatus.processedFiles();
        totalSize = indexShardStatus.totalSize();
        processedSize = indexShardStatus.processedSize();
    }

    /**
     * Returns time when snapshot started
     */
    public long getStartTime() {
        return startTime;
    }

    /**
     * Returns snapshot running time
     */
    public long getTime() {
        return time;
    }

    /**
     * Returns number of files in the snapshot
     */
    public int getNumberOfFiles() {
        return numberOfFiles;
    }

    /**
     * Returns number of files in the snapshot that were processed so far
     */
    public int getProcessedFiles() {
        return processedFiles;
    }

    /**
     * Returns total size of files in the snapshot
     */
    public long getTotalSize() {
        return totalSize;
    }

    /**
     * Returns total size of files in the snapshot that were processed so far
     */
    public long getProcessedSize() {
        return processedSize;
    }


    public static SnapshotStats readSnapshotStats(StreamInput in) throws IOException {
        SnapshotStats stats = new SnapshotStats();
        stats.readFrom(in);
        return stats;
    }

    @Override
    public void writeTo(StreamOutput out) throws IOException {
        out.writeVLong(startTime);
        out.writeVLong(time);

        out.writeVInt(numberOfFiles);
        out.writeVInt(processedFiles);

        out.writeVLong(totalSize);
        out.writeVLong(processedSize);
    }

    @Override
    public void readFrom(StreamInput in) throws IOException {
        startTime = in.readVLong();
        time = in.readVLong();

        numberOfFiles = in.readVInt();
        processedFiles = in.readVInt();

        totalSize = in.readVLong();
        processedSize = in.readVLong();
    }

    static final class Fields {
        static final String STATS = "stats";
        static final String NUMBER_OF_FILES = "number_of_files";
        static final String PROCESSED_FILES = "processed_files";
        static final String TOTAL_SIZE_IN_BYTES = "total_size_in_bytes";
        static final String TOTAL_SIZE = "total_size";
        static final String PROCESSED_SIZE_IN_BYTES = "processed_size_in_bytes";
        static final String PROCESSED_SIZE = "processed_size";
        static final String START_TIME_IN_MILLIS = "start_time_in_millis";
        static final String TIME_IN_MILLIS = "time_in_millis";
        static final String TIME = "time";
    }

    @Override
    public XContentBuilder toXContent(XContentBuilder builder, ToXContent.Params params) throws IOException {
        builder.startObject(Fields.STATS);
        builder.field(Fields.NUMBER_OF_FILES, getNumberOfFiles());
        builder.field(Fields.PROCESSED_FILES, getProcessedFiles());
        builder.byteSizeField(Fields.TOTAL_SIZE_IN_BYTES, Fields.TOTAL_SIZE, getTotalSize());
        builder.byteSizeField(Fields.PROCESSED_SIZE_IN_BYTES, Fields.PROCESSED_SIZE, getProcessedSize());
        builder.field(Fields.START_TIME_IN_MILLIS, getStartTime());
        builder.timeValueField(Fields.TIME_IN_MILLIS, Fields.TIME, getTime());
        builder.endObject();
        return builder;
    }

    void add(SnapshotStats stats) {
        numberOfFiles += stats.numberOfFiles;
        processedFiles += stats.processedFiles;

        totalSize += stats.totalSize;
        processedSize += stats.processedSize;


        if (startTime == 0) {
            // First time here
            startTime = stats.startTime;
            time = stats.time;
        } else {
            // The time the last snapshot ends
            long endTime = Math.max(startTime + time, stats.startTime + stats.time);

            // The time the first snapshot starts
            startTime = Math.min(startTime, stats.startTime);

            // Update duration
            time = endTime - startTime;
        }
    }
}
