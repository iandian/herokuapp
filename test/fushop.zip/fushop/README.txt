sudo pip install -r requirements.txt


python manage.py makemigrations fusn
python manage.py migrate
python manage.py createsuperuser

sudo apt-get install sqlitebrowser

sudo pip install 'django-filter>1.0,<2.0'

self.client.get(url, {'app': '28'})

pip install django-background-tasks
pip install djangorestframework

python manage.py makemigrations background_task
python manage.py makemigrations choose
python manage.py migrate

https://stackoverflow.com/questions/3678869/pythonic-way-to-combine-two-lists-in-an-alternating-fashion

self.client.get(reverse('api:workload_running_work'))

python manage.py createsuperuser
python manage.py runserver
python manage.py process_tasks

change excel path in settings.py


pip install xlrd

create db before run methon in tasks.py

    from enum import Enum
ImportError: No module named enum

sudo pip install --upgrade pip enum34

config apache2
    first vim /etc/apache2/ports.conf
        Listen 8080
    second vim /etc/apache2/sites-available/miao.conf
        https://www.metaltoad.com/blog/hosting-django-sites-apache
        https://coderwall.com/p/ooerda/python-django-apache-ubuntu
        https://www.digitalocean.com/community/tutorials/how-to-serve-django-applications-with-apache-and-mod_wsgi-on-ubuntu-16-04
        https://uwsgi-docs.readthedocs.io/en/latest/tutorials/Django_and_nginx.html
        https://docs.djangoproject.com/en/1.11/howto/deployment/wsgi/
    

log file issue:

https://stackoverflow.com/questions/21797372/django-errno-13-permission-denied-var-www-media-animals-user-uploads

sudo groupadd varwwwusers
sudo adduser www-data varwwwusers
sudo chgrp -R varwwwusers /var/www/
sudo chmod -R 760 /var/www/


    cp miao.conf to there

Permission denied because search permissions are missing on a component 
https://superuser.com/questions/882594/permission-denied-because-search-permissions-are-missing-on-a-component-of-the-p
    find /var/www -type d -exec chmod 755 {} \;
    find /var/www -type f -exec chmod 644 {} \;

Django says "Unable to Open Database File" when using SQLite3
https://code.djangoproject.com/wiki/NewbieMistakes#DjangosaysUnabletoOpenDatabaseFilewhenusingSQLite3
    work around      chmod -R 777 miao

{"detail": "Authentication credentials were not provided."}
https://stackoverflow.com/questions/26906630/django-rest-framework-authentication-credentials-were-not-provided


<ModelTypeChoice.quanta: u'Quanta: Appliance'> is not JSON serializable
https://stackoverflow.com/questions/28945327/django-rest-framework-with-choicefield
http://anthonyfox.io/2017/02/choices-for-choices-in-django-charfields/

clear db data
python manage.py flush

    def format_model_type(self):
        display = self.get_model_type_display()
        return eval(display).value

$ sudo -u www-data ./manage.py <your-management-command>