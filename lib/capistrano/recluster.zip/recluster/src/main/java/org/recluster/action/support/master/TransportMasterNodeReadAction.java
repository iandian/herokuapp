/* 
 * The MIT License
 *
 * Copyright 2017 apex-yu.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package org.recluster.action.support.master;

import org.recluster.action.ActionResponse;
import org.recluster.action.support.ActionFilters;
import org.recluster.cluster.service.ClusterService;
import org.recluster.common.io.stream.Writeable;
import org.recluster.common.settings.Setting;
import org.recluster.common.settings.Setting.Property;
import org.recluster.common.settings.Settings;
import org.recluster.threadpool.ThreadPool;
import org.recluster.transport.TransportService;

import java.util.function.Supplier;

/**
 * A base class for read operations that needs to be performed on the master node.
 * Can also be executed on the local node if needed.
 */
public abstract class TransportMasterNodeReadAction<Request extends MasterNodeReadRequest<Request>, Response extends ActionResponse>
        extends TransportMasterNodeAction<Request, Response> {

    public static final Setting<Boolean> FORCE_LOCAL_SETTING =
        Setting.boolSetting("action.master.force_local", false, Property.NodeScope);

    private final boolean forceLocal;

    protected TransportMasterNodeReadAction(Settings settings, String actionName, TransportService transportService,
                                            ClusterService clusterService, ThreadPool threadPool, ActionFilters actionFilters,
                                            Supplier<Request> request) {
        this(settings, actionName, true, transportService, clusterService, threadPool, actionFilters,request);
    }



    protected TransportMasterNodeReadAction(Settings settings, String actionName, boolean checkSizeLimit, TransportService transportService,
                                            ClusterService clusterService, ThreadPool threadPool, ActionFilters actionFilters,
                                            Supplier<Request> request) {
        super(settings, actionName, checkSizeLimit, transportService, clusterService, threadPool, actionFilters, request);
        this.forceLocal = FORCE_LOCAL_SETTING.get(settings);
    }

    protected TransportMasterNodeReadAction(Settings settings, String actionName, boolean checkSizeLimit, TransportService transportService,
                                            ClusterService clusterService, ThreadPool threadPool, ActionFilters actionFilters,
                                            Writeable.Reader<Request> request) {
        super(settings, actionName, checkSizeLimit, transportService, clusterService, threadPool, actionFilters, request);
        this.forceLocal = FORCE_LOCAL_SETTING.get(settings);
    }

    @Override
    protected final boolean localExecute(Request request) {
        return forceLocal || request.local();
    }
}
