FactoryGirl.define do

  factory :build do
    product
    sequence(:version){|n|"v1.0.0.#{n}"}
  end
end