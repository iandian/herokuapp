
package com.emc.esindexer.crawler.common.settings;


import com.emc.esindexer.crawler.common.MetaFileHandler;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * Provides utility methods to read and write settings files
 */
public class SettingsFileHandler extends MetaFileHandler {

    @Deprecated
    public static final String LEGACY_EXTENSION = ".json";
    public static final String FILENAME = "_settings.json";

    public SettingsFileHandler(Path root) {
        super(root);
    }

    /**
     * We read settings in ~/.fscrawler/{job_name}/_settings.json
     * @param jobname is the job_name
     * @return Settings settings
     * @throws IOException in case of error while reading
     */
    public Settings read(String jobname) throws IOException {
        return SettingsParser.fromJson(readFile(jobname, FILENAME));
    }

    /**
     * We write settings to ~/.fscrawler/{job_name}/_settings.json
     * @param settings Settings to write (settings.getName() contains the job name)
     * @throws IOException in case of error while reading
     */
    public void write(Settings settings) throws IOException {
        writeFile(settings.getName(), FILENAME, SettingsParser.toJson(settings));
    }
}
