class TestCasePolicy < ApplicationPolicy

end
