from collections import OrderedDict

from django.urls import reverse_lazy
from django.utils.translation import gettext_lazy as _



FUSN_SLUG_ALLOW_UNICODE = False
FUSN_IMAGE_FOLDER = 'images/products/%Y/%m/'
FUSN_PROMOTION_FOLDER = 'images/promotions/'
FUSN_DEFAULT_CURRENCY = 'GBP'
