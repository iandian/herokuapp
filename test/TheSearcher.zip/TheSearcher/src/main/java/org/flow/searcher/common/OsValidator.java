package org.flow.searcher.common;


@SuppressWarnings("WeakerAccess")
public class OsValidator {
    public static final String OS;
    public static final boolean WINDOWS;
    public static final boolean MAC;
    public static final boolean UNIX;
    public static final boolean SOLARIS;

    static {
        OS = System.getProperty("os.name").toLowerCase();
        WINDOWS = (OS.contains("win"));
        MAC = (OS.contains("mac"));
        UNIX = (OS.contains("nix") || OS.contains("nux") || OS.indexOf("aix") >= 0 );
        SOLARIS = (OS.contains("sunos"));
    }
}