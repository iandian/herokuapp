package org.flow.searcher.settings;


import java.util.Objects;


public class TheSearcherSettings {

    public static final ServerUrl REST_DEFAULT = new ServerUrl("http://127.0.0.1:8080/crawler");
    private String name;
    private IndexSetting indexSetting;
    private Server server;
    private Elasticsearch elasticsearch;
    private ServerUrl rest;

    public TheSearcherSettings() {

    }

    private TheSearcherSettings(String name, IndexSetting indexSetting, Server server, Elasticsearch elasticsearch, ServerUrl rest) {
        this.name = name;
        this.indexSetting = indexSetting;
        this.server = server;
        this.elasticsearch = elasticsearch;
        this.rest = rest;
    }

    public static Builder builder(String name) {
        return new Builder().setName(name);
    }

    public static class Builder {
        private String name;
        private IndexSetting indexSetting = IndexSetting.DEFAULT;
        private Server server = null;
        private Elasticsearch elasticsearch = Elasticsearch.DEFAULT();
        private ServerUrl rest = REST_DEFAULT;

        private Builder setName(String name) {
            this.name = name;
            return this;
        }

        public Builder setIndexSetting(IndexSetting indexSetting) {
            this.indexSetting = indexSetting;
            return this;
        }

        public Builder setServer(Server server) {
            this.server = server;
            return this;
        }

        public Builder setElasticsearch(Elasticsearch elasticsearch) {
            this.elasticsearch = elasticsearch;
            return this;
        }

        public Builder setRest(ServerUrl rest) {
            this.rest = rest;
            return this;
        }

        public TheSearcherSettings build() {
            return new TheSearcherSettings(name, indexSetting, server, elasticsearch, rest);
        }
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public IndexSetting getIndexSetting() {
        return indexSetting;
    }

    public void setIndexSetting(IndexSetting indexSetting) {
        this.indexSetting = indexSetting;
    }

    public Server getServer() {
        return server;
    }

    public void setServer(Server server) {
        this.server = server;
    }

    public Elasticsearch getElasticsearch() {
        return elasticsearch;
    }

    public void setElasticsearch(Elasticsearch elasticsearch) {
        this.elasticsearch = elasticsearch;
    }

    public ServerUrl getRest() {
        return rest;
    }

    public void setRest(ServerUrl rest) {
        this.rest = rest;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        TheSearcherSettings that = (TheSearcherSettings) o;

        if (!Objects.equals(name, that.name)) return false;
        if (!Objects.equals(indexSetting, that.indexSetting)) return false;
        if (!Objects.equals(server, that.server)) return false;
        if (!Objects.equals(rest, that.rest)) return false;
        return Objects.equals(elasticsearch, that.elasticsearch);

    }

    @Override
    public int hashCode() {
        int result = name != null ? name.hashCode() : 0;
        result = 31 * result + (indexSetting != null ? indexSetting.hashCode() : 0);
        result = 31 * result + (server != null ? server.hashCode() : 0);
        result = 31 * result + (rest != null ? rest.hashCode() : 0);
        result = 31 * result + (elasticsearch != null ? elasticsearch.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "TheSearcherSettings{" + "name='" + name + '\'' +
                ", indexSetting=" + indexSetting +
                ", server=" + server +
                ", elasticsearch=" + elasticsearch +
                ", rest=" + rest +
                '}';
    }
}
