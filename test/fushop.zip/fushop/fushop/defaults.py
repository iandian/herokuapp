from collections import OrderedDict

from django.urls import reverse_lazy
from django.utils.translation import gettext_lazy as _



FUSN_SLUG_ALLOW_UNICODE = False
FUSN_IMAGE_FOLDER = 'images/products/%Y/%m/'
FUSN_PROMOTION_FOLDER = 'images/promotions/'
FUSN_DEFAULT_CURRENCY = 'GBP'
# This dict defines the new order statuses than an order can move to
FUSN_ORDER_STATUS_PIPELINE = {
    'Pending': ('Being processed', 'Cancelled',),
    'Being processed': ('Complete', 'Cancelled',),
    'Cancelled': (),
    'Complete': (),
}
# Hidden Oscar features, e.g. wishlists or reviews
FUSN_HIDDEN_FEATURES = []
FUSN_LINE_STATUS_PIPELINE = {'a': ('b', ), 'b': ()}

# This dict defines the line statuses that will be set when an order's status
# is changed
FUSN_ORDER_STATUS_CASCADE = {
    'Being processed': 'Being processed',
    'Cancelled': 'Cancelled',
    'Complete': 'Shipped',
}

FUSN_DYNAMIC_CLASS_LOADER = 'fusn.utils.loading.default_class_loader'

FUSN_SLUG_MAP = {}

FUSN_SLUG_BLACKLIST = []

FUSN_MAX_BASKET_QUANTITY_THRESHOLD = 10000

FUSN_SLUG_FUNCTION = 'fusn.utils.utils.default_slugifier'

FUSN_ALLOW_ANON_REVIEWS = True

# Copy this image from oscar/static/img to your MEDIA_ROOT folder.
# It needs to be there so Sorl can resize it.
FUSN_MISSING_IMAGE_URL = 'image_not_found.jpg'
FUSN_UPLOAD_ROOT = '/tmp'

