package org.flow.searcher.models;


import com.fasterxml.jackson.core.JsonProcessingException;

import java.io.IOException;

import static org.flow.searcher.common.MetaParser.prettyMapper;

public class PathParser {

    public static String toJson(Path path) throws JsonProcessingException {
        return prettyMapper.writeValueAsString(path);
    }

    public static Path fromJson(String json) throws IOException {
        return prettyMapper.readValue(json, Path.class);
    }
}
