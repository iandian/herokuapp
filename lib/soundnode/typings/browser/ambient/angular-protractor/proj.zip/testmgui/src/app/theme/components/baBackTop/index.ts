export * from './baBackTop.component';
