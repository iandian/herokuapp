class TestUnitTestCase < ApplicationRecord

  belongs_to :test_unit
  belongs_to :test_case


end