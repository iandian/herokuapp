require_relative 'boot'

require 'rails/all'
require 'rack'
require 'rack/cors'


# Require the gems listed in Gemfile, including any gems
# you've limited to :test, :development, or :production.
Bundler.require(*Rails.groups)

module Rails5GrapeApiExample
  class Application < Rails::Application
    # Settings in config/environments/* take precedence over those specified here.
    # Application configuration should go into files in config/initializers
    # -- all .rb files in that directory are automatically loaded.

    config.paths.add File.join('app', 'api'), glob: File.join('**', '*.rb')
    config.autoload_paths += Dir[Rails.root.join('app', 'api', '*')]

	# If want to expose customer headers to client, you need to expose it here, or client can't see those value
	# http://stackoverflow.com/questions/36406869/add-custom-response-header-with-rack-cors-and-grape/36407464
	# https://github.com/cyu/rack-cors/issues/125
	# http://restlet.com/company/blog/2015/12/15/understanding-and-using-cors/
    config.middleware.use Rack::Cors do
      allow do
        origins "*"
        resource "*", headers: :any,
                      expose:  ['access-token', 'expiry', 'token-type', 'uid', 'client'],		
		              methods: [:get, :post, :put, :delete, :options]
      end
    end
	
	config.middleware.use(Rack::Config) do |env|
		env['api.tilt.root'] = Rails.root.join "app", "views", "api"
	end

    # so can use render_success(Rabl::Renderer.json(build, 'build/show')) now	
    Rabl.configure do |config|
      config.view_paths = [Rails.root.join("app", "views", "api")]
    end


    # don't generate RSpec tests for views and helpers
    config.generators do |g|
      g.test_framework :rspec, fixture: true
      g.fixture_replacement :factory_girl, dir: 'spec/factories'
      g.view_specs false
      g.helper_specs false
      g.stylesheets = false
      g.javascripts = false
      g.helper = false
    end
	
	

    config.autoload_paths += Dir["#{config.root}/lib"]
	
	require 'custom_formatter'
	config.log_formatter = CustomFormatter.new
	config.log_level = :info
	
  end
end
