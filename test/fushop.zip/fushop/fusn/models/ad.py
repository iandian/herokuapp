# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from .ad_position import AD_Position
import logging


logger = logging.getLogger(__name__)


class AD(models.Model):
    ad_position = models.ForeignKey(
        AD_Position, related_name='ad', on_delete=models.CASCADE)
    media_type = models.IntegerField()
    name = models.CharField(max_length=60)
    link = models.CharField(max_length=255)
    image_url = models.URLField(blank=True)
    content = models.CharField(max_length=255)
    end_time = models.DateTimeField(blank=True, null=True)
    enabled = models.IntegerField()

    class Meta:
        verbose_name = "AD"
        verbose_name_plural = "AD"

    def __unicode__(self):
        return '%s' % (self.name)