package org.flow.searcher.common;


import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;

import java.io.IOException;

/**
 * Jackson Deserializer for TimeValue object
 */
public class TimeValueDeserializer extends StdDeserializer<TimeValue> {
    public TimeValueDeserializer() {
        super(TimeValue.class);
    }

    @Override
    public TimeValue deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
        return TimeValue.parseTimeValue(p.getText());
    }
}

