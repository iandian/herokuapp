# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from django.contrib.auth.models import User
import logging


logger = logging.getLogger(__name__)

#TODO
class GoodsIssue(models.Model):
    goods_id = models.TextField(blank=True, null=True)
    question = models.CharField(max_length=255, blank=True, null=True)
    answer = models.CharField(max_length=45, blank=True, null=True)

    class Meta:
        verbose_name = "Address"
        verbose_name_plural = "Address"

    def __unicode__(self):
        return '%s %s' % (self.name, self.address)