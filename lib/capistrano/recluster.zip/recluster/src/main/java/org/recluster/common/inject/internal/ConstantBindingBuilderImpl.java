/* 
 * The MIT License
 *
 * Copyright 2017 apex-yu.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package org.recluster.common.inject.internal;

import org.recluster.common.inject.Binder;
import org.recluster.common.inject.Key;
import org.recluster.common.inject.binder.AnnotatedConstantBindingBuilder;
import org.recluster.common.inject.binder.ConstantBindingBuilder;
import org.recluster.common.inject.spi.Element;

import java.lang.annotation.Annotation;
import java.util.List;

import static java.util.Collections.emptySet;

/**
 * Bind a constant.
 *
 * @author jessewilson@google.com (Jesse Wilson)
 */
public final class ConstantBindingBuilderImpl<T>
        extends AbstractBindingBuilder<T>
        implements AnnotatedConstantBindingBuilder, ConstantBindingBuilder {

    @SuppressWarnings("unchecked") // constant bindings start out with T unknown
    public ConstantBindingBuilderImpl(Binder binder, List<Element> elements, Object source) {
        super(binder, elements, source, (Key<T>) NULL_KEY);
    }

    @Override
    public ConstantBindingBuilder annotatedWith(Class<? extends Annotation> annotationType) {
        annotatedWithInternal(annotationType);
        return this;
    }

    @Override
    public ConstantBindingBuilder annotatedWith(Annotation annotation) {
        annotatedWithInternal(annotation);
        return this;
    }

    @Override
    public void to(final String value) {
        toConstant(String.class, value);
    }

    @Override
    public void to(final int value) {
        toConstant(Integer.class, value);
    }

    @Override
    public void to(final long value) {
        toConstant(Long.class, value);
    }

    @Override
    public void to(final boolean value) {
        toConstant(Boolean.class, value);
    }

    @Override
    public void to(final double value) {
        toConstant(Double.class, value);
    }

    @Override
    public void to(final float value) {
        toConstant(Float.class, value);
    }

    @Override
    public void to(final short value) {
        toConstant(Short.class, value);
    }

    @Override
    public void to(final char value) {
        toConstant(Character.class, value);
    }

    @Override
    public void to(final Class<?> value) {
        toConstant(Class.class, value);
    }

    @Override
    public <E extends Enum<E>> void to(final E value) {
        toConstant(value.getDeclaringClass(), value);
    }

    private void toConstant(Class<?> type, Object instance) {
        // this type will define T, so these assignments are safe
        @SuppressWarnings("unchecked")
        Class<T> typeAsClassT = (Class<T>) type;
        @SuppressWarnings("unchecked")
        T instanceAsT = (T) instance;

        if (keyTypeIsSet()) {
            binder.addError(CONSTANT_VALUE_ALREADY_SET);
            return;
        }

        BindingImpl<T> base = getBinding();
        Key<T> key;
        if (base.getKey().getAnnotation() != null) {
            key = Key.get(typeAsClassT, base.getKey().getAnnotation());
        } else if (base.getKey().getAnnotationType() != null) {
            key = Key.get(typeAsClassT, base.getKey().getAnnotationType());
        } else {
            key = Key.get(typeAsClassT);
        }

        if (instanceAsT == null) {
            binder.addError(BINDING_TO_NULL);
        }

        setBinding(new InstanceBindingImpl<>(
                base.getSource(), key, base.getScoping(), emptySet(), instanceAsT));
    }

    @Override
    public String toString() {
        return "ConstantBindingBuilder";
    }
}