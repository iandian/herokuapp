# -*- coding: utf-8 -*-
from django.db import models
from django.utils.translation import gettext_lazy as _

from phonenumber_field.modelfields import PhoneNumberField

from fusn.utils.compat import AUTH_USER_MODEL

import logging


logger = logging.getLogger(__name__)


class Province(models.Model):
    code = models.CharField(max_length=255, primary_key=True, db_index=True)
    name = models.CharField(max_length=255, db_index=True)

    class Meta:
        verbose_name = "Province"
        verbose_name_plural = "Province"

    def __unicode__(self):
        return '%s %s' % (self.name, self.code)


class City(models.Model):
    code = models.CharField(max_length=255, primary_key=True, db_index=True)
    name = models.CharField(max_length=255, db_index=True)
    provice = models.ForeignKey(
        Province, related_name='city', on_delete=models.CASCADE, db_column="provinceCode")

    class Meta:
        verbose_name = "City"
        verbose_name_plural = "City"

    def __unicode__(self):
        return '%s %s' % (self.name, self.code)



class Area(models.Model):
    code = models.CharField(max_length=255, primary_key=True, db_index=True)
    name = models.CharField(max_length=255, db_index=True)
    city = models.ForeignKey(
        City, related_name='area', on_delete=models.CASCADE, db_column="cityCode")
    provice = models.ForeignKey(
        Province, related_name='area', on_delete=models.CASCADE, db_column="provinceCode")

    class Meta:
        verbose_name = "Area"
        verbose_name_plural = "Area"

    def __unicode__(self):
        return '%s %s' % (self.name, self.code)



class Street(models.Model):
    code = models.CharField(max_length=255, primary_key=True, db_index=True)
    name = models.CharField(max_length=255, db_index=True)
    area = models.ForeignKey(
        Area, related_name='street', on_delete=models.CASCADE, db_column="areaCode")
    city = models.ForeignKey(
        City, related_name='street', on_delete=models.CASCADE, db_column="cityCode")
    provice = models.ForeignKey(
        Province, related_name='street', on_delete=models.CASCADE, db_column="provinceCode")

    class Meta:
        verbose_name = "Street"
        verbose_name_plural = "Street"

    def __unicode__(self):
        return '%s %s' % (self.name, self.code)




class Village(models.Model):
    code = models.CharField(max_length=255, primary_key=True, db_index=True)
    name = models.CharField(max_length=255, db_index=True)
    street = models.ForeignKey(
        Street, related_name='village', on_delete=models.CASCADE, db_column="streetCode")
    area = models.ForeignKey(
        Area, related_name='village', on_delete=models.CASCADE, db_column="areaCode")
    city = models.ForeignKey(
        City, related_name='village', on_delete=models.CASCADE, db_column="cityCode")
    provice = models.ForeignKey(
        Province, related_name='village', on_delete=models.CASCADE, db_column="provinceCode")


    class Meta:
        verbose_name = "Village"
        verbose_name_plural = "Village"

    def __unicode__(self):
        return '%s %s' % (self.name, self.code)

class Address(models.Model):
    name = models.CharField(max_length=50)
    user = models.ForeignKey(
        AUTH_USER_MODEL, related_name="address",
        blank=True, verbose_name=_("User"))
    province = models.ForeignKey(
        Province, related_name='address', on_delete=models.CASCADE)
    city = models.ForeignKey(
        City, related_name='address', on_delete=models.CASCADE)
    area = models.ForeignKey(
        Area, related_name='address', on_delete=models.CASCADE)
    street = models.ForeignKey(
        Street, related_name='address', on_delete=models.CASCADE)
    village = models.ForeignKey(
        Village, related_name='address', on_delete=models.CASCADE)
    address = models.CharField(max_length=120)
    mobile = models.CharField(max_length=60)
    is_default = models.BooleanField(default=False)

    class Meta:
        verbose_name = "Address"
        verbose_name_plural = "Address"

    def __unicode__(self):
        return '%s %s' % (self.name, self.address)



class BillingAddress(Address):
    class Meta:
        app_label = 'fusn'
        verbose_name = _("Billing address")
        verbose_name_plural = _("Billing addresses")

    @property
    def order(self):
        """
        Return the order linked to this shipping address
        """
        try:
            return self.order_set.all()[0]
        except IndexError:
            return None


class ShippingAddress(Address):
    """
    A shipping address.

    A shipping address should not be edited once the order has been placed -
    it should be read-only after that.

    NOTE:
    ShippingAddress is a model of the order app. But moving it there is tricky
    due to circular import issues that are amplified by get_model/get_class
    calls pre-Django 1.7 to register receivers. So...
    TODO: Once Django 1.6 support is dropped, move AbstractBillingAddress and
    AbstractShippingAddress to the order app, and move
    PartnerAddress to the partner app.
    """

    phone_number = PhoneNumberField(
        _("Phone number"), blank=True,
        help_text=_("In case we need to call you about your order"))
    notes = models.TextField(
        blank=True, verbose_name=_('Instructions'),
        help_text=_("Tell us anything we should know when delivering "
                    "your order."))

    class Meta:
        app_label = 'fusn'
        verbose_name = _("Shipping address")
        verbose_name_plural = _("Shipping addresses")

    @property
    def order(self):
        """
        Return the order linked to this shipping address
        """
        try:
            return self.order_set.all()[0]
        except IndexError:
            return None
