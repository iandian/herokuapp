# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from django.contrib.auth.models import User
import logging


logger = logging.getLogger(__name__)

class AttributeCategory(models.Model):
    name = models.CharField(max_length=50, blank=True, default='')
    enabled = models.BooleanField(default=False)

    class Meta:
        verbose_name = "AttributeCategory"
        verbose_name_plural = "AttributeCategory"

    def __unicode__(self):
        return '%s %s' % (self.name, self.enabled)