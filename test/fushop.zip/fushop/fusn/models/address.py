# -*- coding: utf-8 -*-
from .province import Province
from .user import User
from __future__ import unicode_literals
from django.db import models

import logging
from .province import Province
from .city import City
from .area import Area


logger = logging.getLogger(__name__)

class Address(models.Model):
    name = models.CharField(max_length=50)
    user = models.ForeignKey(
        User, related_name='address', on_delete=models.CASCADE)
    province = models.ForeignKey(
        Province, related_name='address', on_delete=models.CASCADE)
    city = models.ForeignKey(
        City, related_name='address', on_delete=models.CASCADE)
    area = models.ForeignKey(
        Area, related_name='address', on_delete=models.CASCADE)
    address = models.CharField(max_length=120)
    mobile = models.CharField(max_length=60)
    is_default = models.BooleanField(default=False)

    class Meta:
        verbose_name = "Address"
        verbose_name_plural = "Address"

    def __unicode__(self):
        return '%s %s' % (self.name, self.address)