module TestPlanBase
  extend ActiveSupport::Concern

  included do

    helpers do
      def get_test_plan(id)
        @test_plan = TestPlan.find(id)

        unless @test_plan
          raise ApiException.new(
            http_status: RESPONSE_CODE[:not_found], 
            code: RESPONSE_CODE[:not_found], 
            message: I18n.t('errors.test_plan.not_found')
          )
        end
      end
	  
      def create_test_plan(params)
        @test_plan = TestPlan.new(params)

        unless @test_plan.save
          raise ApiException.new(
            http_status: RESPONSE_CODE[:not_found], 
            code: RESPONSE_CODE[:not_found], 
            message: I18n.t('errors.test_plan.not_found')
          )
        end
      end

    end
  end
end