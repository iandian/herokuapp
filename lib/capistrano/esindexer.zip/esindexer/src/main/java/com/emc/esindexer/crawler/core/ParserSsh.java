
package com.emc.esindexer.crawler.core;


import com.emc.esindexer.crawler.client.ElasticsearchClientManager;
import com.emc.esindexer.crawler.common.settings.Settings;
import com.emc.esindexer.crawler.filewrapper.FileWrapper;
import com.emc.esindexer.crawler.filewrapper.FileWrapperLocal;

import java.nio.file.Path;

public class ParserSsh extends Parser {

    public ParserSsh(Settings settings, Path config, ElasticsearchClientManager esClientManager, Integer loop) {
        super(settings, config, esClientManager, loop);
    }

    protected FileWrapper buildFileWrapper() {
        return new FileWrapperLocal(settings);
    }
}
