
package com.emc.esindexer.crawler.client;

import com.emc.esindexer.crawler.common.utils.JsonUtil;
import org.elasticsearch.client.Response;

import java.io.IOException;
import java.util.Map;

public class LowLevelClientJsonUtil extends JsonUtil {

    public static <T> T deserialize(Response response, Class<T> clazz) {
        try {
            if (response.getEntity() == null) {
                return null;
            }
            return deserialize(response.getEntity().getContent(), clazz);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static Map<String, Object> asMap(Response response) {
        try {
            if (response.getEntity() == null) {
                return null;
            }
            return asMap(response.getEntity().getContent());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
