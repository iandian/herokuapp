module V1
  class Dashboard < Grape::API
    include V1Base
	include DashboardBase

    resource :dashboard do
      resource :products do

		  desc 'Get product dashboard', headers: HEADERS_DOCS, http_codes: [
			{ code: 200, message: 'success' },
			{ code: RESPONSE_CODE[:not_found], message: I18n.t('errors.not_found') }
		  ]
		  params do
			requires :id, type: String, desc: 'Product id'
		  end
		  get ':id', :rabl => "dashboard/product.rabl" do
			logger.info "get product dashboard with id #{params[:id]}"
			get_product_dashboard(params[:id])
		  end
		  
        desc 'Get products dashboard', headers: HEADERS_DOCS, http_codes: [
          { code: 200, message: 'success' },
          { code: RESPONSE_CODE[:forbidden], message: I18n.t('errors.forbidden') }
        ]
		  get :rabl => "dashboard/products.rabl" do
            get_all_products_dashboard
          end
	  
	  end
	  
	  
      resource :build do

		  desc 'Get build dashboard', headers: HEADERS_DOCS, http_codes: [
			{ code: 200, message: 'success' },
			{ code: RESPONSE_CODE[:not_found], message: I18n.t('errors.not_found') }
		  ]
		  params do
			requires :id, type: String, desc: 'Build id'
		  end
		  get ':id', :rabl => "dashboard/build.rabl" do
			logger.info "start to get build dashboard with id #{params[:id]}"
			get_build_dashboard(params[:id])
		  end
	  
	  end
	  
    end
  end
end