FactoryGirl.define do

  factory :result do
    run_record
	test_unit
    sequence(:value){[true, false].sample}
  end
end