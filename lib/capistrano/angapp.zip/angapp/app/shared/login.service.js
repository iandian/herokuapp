"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var http_1 = require("@angular/common/http");
var ErrorObservable_1 = require("rxjs/observable/ErrorObservable");
var operators_1 = require("rxjs/operators");
var backend_service_1 = require("./backend.service");
var LoginService = /** @class */ (function () {
    function LoginService(http) {
        this.http = http;
    }
    LoginService.prototype.register = function (user) {
        return this.http.post(backend_service_1.BackendService.baseUrl + "user/" + backend_service_1.BackendService.appKey, JSON.stringify({
            username: user.email,
            email: user.email,
            password: user.password
        }), { headers: this.getCommonHeaders() })
            .pipe(operators_1.catchError(this.handleErrors));
    };
    LoginService.prototype.login = function (user) {
        return this.http.post(backend_service_1.BackendService.baseUrl + "user/" + backend_service_1.BackendService.appKey + "/login", JSON.stringify({
            username: user.email,
            password: user.password
        }), { headers: this.getCommonHeaders() })
            .pipe(operators_1.tap(function (data) {
            backend_service_1.BackendService.token = data._kmd.authtoken;
        }), operators_1.catchError(this.handleErrors));
    };
    LoginService.prototype.logoff = function () {
        backend_service_1.BackendService.token = "";
    };
    LoginService.prototype.resetPassword = function (email) {
        return this.http.post(backend_service_1.BackendService.baseUrl + "rpc/" + backend_service_1.BackendService.appKey + "/" + email + "/user-password-reset-initiate", {}, { headers: this.getCommonHeaders() }).pipe(operators_1.catchError(this.handleErrors));
    };
    LoginService.prototype.getCommonHeaders = function () {
        return new http_1.HttpHeaders({
            "Content-Type": "application/json",
            "Authorization": backend_service_1.BackendService.appUserHeader,
        });
    };
    LoginService.prototype.handleErrors = function (error) {
        console.log(JSON.stringify(error));
        return ErrorObservable_1.ErrorObservable.create(error);
    };
    LoginService = __decorate([
        core_1.Injectable(),
        __metadata("design:paramtypes", [http_1.HttpClient])
    ], LoginService);
    return LoginService;
}());
exports.LoginService = LoginService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibG9naW4uc2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImxvZ2luLnNlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQSxzQ0FBMkM7QUFDM0MsNkNBQWtGO0FBRWxGLG1FQUFrRTtBQUNsRSw0Q0FBc0Q7QUFHdEQscURBQW1EO0FBR25EO0lBQ0Usc0JBQW9CLElBQWdCO1FBQWhCLFNBQUksR0FBSixJQUFJLENBQVk7SUFBSSxDQUFDO0lBRXpDLCtCQUFRLEdBQVIsVUFBUyxJQUFVO1FBQ2pCLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FDbkIsZ0NBQWMsQ0FBQyxPQUFPLEdBQUcsT0FBTyxHQUFHLGdDQUFjLENBQUMsTUFBTSxFQUN4RCxJQUFJLENBQUMsU0FBUyxDQUFDO1lBQ2IsUUFBUSxFQUFFLElBQUksQ0FBQyxLQUFLO1lBQ3BCLEtBQUssRUFBRSxJQUFJLENBQUMsS0FBSztZQUNqQixRQUFRLEVBQUUsSUFBSSxDQUFDLFFBQVE7U0FDeEIsQ0FBQyxFQUNGLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxFQUFFLENBQ3JDO2FBQ0EsSUFBSSxDQUFDLHNCQUFVLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUM7SUFDdkMsQ0FBQztJQUVELDRCQUFLLEdBQUwsVUFBTSxJQUFVO1FBQ2QsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUNuQixnQ0FBYyxDQUFDLE9BQU8sR0FBRyxPQUFPLEdBQUcsZ0NBQWMsQ0FBQyxNQUFNLEdBQUcsUUFBUSxFQUNuRSxJQUFJLENBQUMsU0FBUyxDQUFDO1lBQ2IsUUFBUSxFQUFFLElBQUksQ0FBQyxLQUFLO1lBQ3BCLFFBQVEsRUFBRSxJQUFJLENBQUMsUUFBUTtTQUN4QixDQUFDLEVBQ0YsRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLGdCQUFnQixFQUFFLEVBQUUsQ0FDckM7YUFDQSxJQUFJLENBQ0gsZUFBRyxDQUFDLFVBQUMsSUFBUztZQUNaLGdDQUFjLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDO1FBQzdDLENBQUMsQ0FBQyxFQUNGLHNCQUFVLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUM5QixDQUFDO0lBQ0osQ0FBQztJQUVELDZCQUFNLEdBQU47UUFDRSxnQ0FBYyxDQUFDLEtBQUssR0FBRyxFQUFFLENBQUM7SUFDNUIsQ0FBQztJQUVELG9DQUFhLEdBQWIsVUFBYyxLQUFLO1FBQ2pCLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FDbkIsZ0NBQWMsQ0FBQyxPQUFPLEdBQUcsTUFBTSxHQUFHLGdDQUFjLENBQUMsTUFBTSxHQUFHLEdBQUcsR0FBRyxLQUFLLEdBQUcsK0JBQStCLEVBQ3ZHLEVBQUUsRUFDRixFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsRUFBRSxDQUNyQyxDQUFDLElBQUksQ0FBQyxzQkFBVSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDO0lBQ3hDLENBQUM7SUFFTyx1Q0FBZ0IsR0FBeEI7UUFDRSxNQUFNLENBQUMsSUFBSSxrQkFBVyxDQUFDO1lBQ3JCLGNBQWMsRUFBRSxrQkFBa0I7WUFDbEMsZUFBZSxFQUFFLGdDQUFjLENBQUMsYUFBYTtTQUM5QyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRU8sbUNBQVksR0FBcEIsVUFBcUIsS0FBd0I7UUFDM0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7UUFDbkMsTUFBTSxDQUFDLGlDQUFlLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ3ZDLENBQUM7SUF2RFUsWUFBWTtRQUR4QixpQkFBVSxFQUFFO3lDQUVlLGlCQUFVO09BRHpCLFlBQVksQ0F3RHhCO0lBQUQsbUJBQUM7Q0FBQSxBQXhERCxJQXdEQztBQXhEWSxvQ0FBWSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tIFwiQGFuZ3VsYXIvY29yZVwiO1xuaW1wb3J0IHsgSHR0cEhlYWRlcnMsIEh0dHBDbGllbnQsIEh0dHBFcnJvclJlc3BvbnNlIH0gZnJvbSBcIkBhbmd1bGFyL2NvbW1vbi9odHRwXCI7XG5pbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAncnhqcy9PYnNlcnZhYmxlJztcbmltcG9ydCB7IEVycm9yT2JzZXJ2YWJsZSB9IGZyb20gXCJyeGpzL29ic2VydmFibGUvRXJyb3JPYnNlcnZhYmxlXCI7XG5pbXBvcnQgeyB0YXAsIG1hcCwgY2F0Y2hFcnJvciB9IGZyb20gXCJyeGpzL29wZXJhdG9yc1wiO1xuXG5pbXBvcnQgeyBVc2VyIH0gZnJvbSBcIi4vdXNlci5tb2RlbFwiO1xuaW1wb3J0IHsgQmFja2VuZFNlcnZpY2UgfSBmcm9tIFwiLi9iYWNrZW5kLnNlcnZpY2VcIjtcblxuQEluamVjdGFibGUoKVxuZXhwb3J0IGNsYXNzIExvZ2luU2VydmljZSB7XG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgaHR0cDogSHR0cENsaWVudCkgeyB9XG5cbiAgcmVnaXN0ZXIodXNlcjogVXNlcikge1xuICAgIHJldHVybiB0aGlzLmh0dHAucG9zdChcbiAgICAgIEJhY2tlbmRTZXJ2aWNlLmJhc2VVcmwgKyBcInVzZXIvXCIgKyBCYWNrZW5kU2VydmljZS5hcHBLZXksXG4gICAgICBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIHVzZXJuYW1lOiB1c2VyLmVtYWlsLFxuICAgICAgICBlbWFpbDogdXNlci5lbWFpbCxcbiAgICAgICAgcGFzc3dvcmQ6IHVzZXIucGFzc3dvcmRcbiAgICAgIH0pLFxuICAgICAgeyBoZWFkZXJzOiB0aGlzLmdldENvbW1vbkhlYWRlcnMoKSB9XG4gICAgKVxuICAgIC5waXBlKGNhdGNoRXJyb3IodGhpcy5oYW5kbGVFcnJvcnMpKTtcbiAgfVxuXG4gIGxvZ2luKHVzZXI6IFVzZXIpIHtcbiAgICByZXR1cm4gdGhpcy5odHRwLnBvc3QoXG4gICAgICBCYWNrZW5kU2VydmljZS5iYXNlVXJsICsgXCJ1c2VyL1wiICsgQmFja2VuZFNlcnZpY2UuYXBwS2V5ICsgXCIvbG9naW5cIixcbiAgICAgIEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgdXNlcm5hbWU6IHVzZXIuZW1haWwsXG4gICAgICAgIHBhc3N3b3JkOiB1c2VyLnBhc3N3b3JkXG4gICAgICB9KSxcbiAgICAgIHsgaGVhZGVyczogdGhpcy5nZXRDb21tb25IZWFkZXJzKCkgfVxuICAgIClcbiAgICAucGlwZShcbiAgICAgIHRhcCgoZGF0YTogYW55KSA9PiB7XG4gICAgICAgIEJhY2tlbmRTZXJ2aWNlLnRva2VuID0gZGF0YS5fa21kLmF1dGh0b2tlbjtcbiAgICAgIH0pLFxuICAgICAgY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9ycylcbiAgICApO1xuICB9XG5cbiAgbG9nb2ZmKCkge1xuICAgIEJhY2tlbmRTZXJ2aWNlLnRva2VuID0gXCJcIjtcbiAgfVxuXG4gIHJlc2V0UGFzc3dvcmQoZW1haWwpIHtcbiAgICByZXR1cm4gdGhpcy5odHRwLnBvc3QoXG4gICAgICBCYWNrZW5kU2VydmljZS5iYXNlVXJsICsgXCJycGMvXCIgKyBCYWNrZW5kU2VydmljZS5hcHBLZXkgKyBcIi9cIiArIGVtYWlsICsgXCIvdXNlci1wYXNzd29yZC1yZXNldC1pbml0aWF0ZVwiLFxuICAgICAge30sXG4gICAgICB7IGhlYWRlcnM6IHRoaXMuZ2V0Q29tbW9uSGVhZGVycygpIH1cbiAgICApLnBpcGUoY2F0Y2hFcnJvcih0aGlzLmhhbmRsZUVycm9ycykpO1xuICB9XG5cbiAgcHJpdmF0ZSBnZXRDb21tb25IZWFkZXJzKCkge1xuICAgIHJldHVybiBuZXcgSHR0cEhlYWRlcnMoe1xuICAgICAgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIsXG4gICAgICBcIkF1dGhvcml6YXRpb25cIjogQmFja2VuZFNlcnZpY2UuYXBwVXNlckhlYWRlcixcbiAgICB9KTtcbiAgfVxuXG4gIHByaXZhdGUgaGFuZGxlRXJyb3JzKGVycm9yOiBIdHRwRXJyb3JSZXNwb25zZSkge1xuICAgIGNvbnNvbGUubG9nKEpTT04uc3RyaW5naWZ5KGVycm9yKSk7XG4gICAgcmV0dXJuIEVycm9yT2JzZXJ2YWJsZS5jcmVhdGUoZXJyb3IpO1xuICB9XG59XG4iXX0=