# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from django.contrib.auth.models import User
import logging


logger = logging.getLogger(__name__)

#TODO
class TopicCategory(models.Model):
    title = models.CharField(max_length=255)
    pic_url = models.CharField(max_length=255)

    class Meta:
        verbose_name = "Address"
        verbose_name_plural = "Address"

    def __unicode__(self):
        return '%s %s' % (self.name, self.address)