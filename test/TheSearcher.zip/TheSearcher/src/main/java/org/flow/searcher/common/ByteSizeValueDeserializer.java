package org.flow.searcher.common;


import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;

import java.io.IOException;

/**
 * Jackson Deserializer for ByteSizeValue object
 */
public class ByteSizeValueDeserializer extends StdDeserializer<ByteSizeValue> {
    public ByteSizeValueDeserializer() {
        super(TimeValue.class);
    }

    @Override
    public ByteSizeValue deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
        return ByteSizeValue.parseBytesSizeValue(p.getText());
    }
}
