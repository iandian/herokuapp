module DataHelpers
  def clean_db
	Product.delete_all
	Build.delete_all
	TestScene.delete_all
	TestPipe.delete_all
	TestUnit.delete_all
	TestUnitTestCase.delete_all
	TestCase.delete_all
	TestPlan.delete_all
	RunRecord.delete_all
	Result.delete_all
	Report.delete_all
  end
end