module DashboardBase
  extend ActiveSupport::Concern

  included do

    helpers do
      def get_product_dashboard(id)
        @product = Product.find(id)

        if @product
		  
		else
          raise ApiException.new(
            http_status: RESPONSE_CODE[:not_found], 
            code: RESPONSE_CODE[:not_found], 
            message: I18n.t('errors.product.not_found')
          )
        end
      end
	  
      def get_all_products_dashboard
        @products = Product.all

        if @products
		  
		else
          raise ApiException.new(
            http_status: RESPONSE_CODE[:not_found], 
            code: RESPONSE_CODE[:not_found], 
            message: I18n.t('errors.product.not_found')
          )
        end
      end
	  
      def get_build_dashboard(id)
        @product = Product.find(id)

        if @product
		  
		else
          raise ApiException.new(
            http_status: RESPONSE_CODE[:not_found], 
            code: RESPONSE_CODE[:not_found], 
            message: I18n.t('errors.build.not_found')
          )
        end
      end

    end
  end
end