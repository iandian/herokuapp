import {Component} from '@angular/core';

@Component({
  selector: 'basic-form',
  templateUrl: './basicForm.html',
})
export class BasicForm {

  constructor() {
  }

  isChecked: boolean = false;
}
