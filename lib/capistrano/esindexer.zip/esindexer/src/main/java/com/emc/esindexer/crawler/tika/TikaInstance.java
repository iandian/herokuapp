
package com.emc.esindexer.crawler.tika;


import com.emc.esindexer.crawler.common.settings.EsSettings;
import com.emc.esindexer.crawler.common.settings.Settings;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.tika.config.ServiceLoader;
import org.apache.tika.exception.TikaException;
import org.apache.tika.language.detect.LanguageDetector;
import org.apache.tika.metadata.Metadata;
import org.apache.tika.mime.MediaTypeRegistry;
import org.apache.tika.parser.AutoDetectParser;
import org.apache.tika.parser.DefaultParser;
import org.apache.tika.parser.ParseContext;
import org.apache.tika.parser.Parser;
import org.apache.tika.parser.external.ExternalParser;
import org.apache.tika.parser.ocr.TesseractOCRConfig;
import org.apache.tika.parser.ocr.TesseractOCRParser;
import org.apache.tika.parser.pdf.PDFParser;
import org.apache.tika.sax.BodyContentHandler;
import org.apache.tika.sax.WriteOutContentHandler;
import org.xml.sax.SAXException;

import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;

import static org.apache.tika.langdetect.OptimaizeLangDetector.getDefaultLanguageDetector;

/**
 *
 */
public class TikaInstance {

    private static final Logger logger = LogManager.getLogger(TikaInstance.class);

    private static Parser parser;
    private static ParseContext context;
    private static LanguageDetector detector;

    /* For tests only */
    public static void reloadTika() {
        parser = null;
        context = null;
    }

    /**
     * This initialize if needed a parser and a parse context for tika
     * @param esSettings esSettings settings
     */
    private static void initTika(EsSettings esSettings) {
        initParser(esSettings);
        initContext(esSettings);
    }

    private static void initParser(EsSettings esSettings) {
        if (parser == null) {
            PDFParser pdfParser = new PDFParser();
            DefaultParser defaultParser;

            if (esSettings.isPdfOcr()) {
                logger.debug("OCR is activated for PDF documents");
                if (ExternalParser.check("tesseract")) {
                    pdfParser.setOcrStrategy("ocr_and_text");
                } else {
                    logger.debug("But Tesseract is not installed so we won't run OCR.");
                }
                defaultParser = new DefaultParser();
            } else {
                logger.debug("OCR is disabled. Even though it's detected, it must be disabled explicitly");
                defaultParser = new DefaultParser(
                        MediaTypeRegistry.getDefaultRegistry(),
                        new ServiceLoader(),
                        Collections.singletonList(TesseractOCRParser.class));
            }

            Parser PARSERS[] = new Parser[2];
            PARSERS[0] = defaultParser;
            PARSERS[1] = pdfParser;

            parser = new AutoDetectParser(PARSERS);
        }

    }

    private static void initContext(EsSettings esSettings) {
        if (context == null) {
            context = new ParseContext();
            context.set(Parser.class, parser);
            if (esSettings.isPdfOcr()) {
                logger.debug("OCR is activated");
                TesseractOCRConfig config = new TesseractOCRConfig();
                if (esSettings.getOcr().getPath() != null) {
                    config.setTesseractPath(esSettings.getOcr().getPath());
                }
                if (esSettings.getOcr().getDataPath() != null) {
                    config.setTessdataPath(esSettings.getOcr().getDataPath());
                }
                config.setLanguage(esSettings.getOcr().getLanguage());
                context.set(TesseractOCRConfig.class, config);
            }
        }
    }

    static String extractText(Settings settings, int indexedChars, InputStream stream, Metadata metadata) throws IOException,
            TikaException {
        initTika(settings.getEsSettings());
        WriteOutContentHandler handler = new WriteOutContentHandler(indexedChars);
        try {
            parser.parse(stream, new BodyContentHandler(handler), metadata, context);
        } catch (SAXException e) {
            if (!handler.isWriteLimitReached(e)) {
                // This should never happen with BodyContentHandler...
                throw new TikaException("Unexpected SAX processing failure", e);
            }
        } finally {
            stream.close();
        }
        return handler.toString();
    }

    static LanguageDetector langDetector() {
        if (detector == null) {
            try {
                detector = getDefaultLanguageDetector();
                detector.loadModels();
            } catch (IOException e) {
                logger.warn("Can not load lang detector models", e);
            }
        }
        return detector;
    }
}
