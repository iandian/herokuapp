/* 
 * The MIT License
 *
 * Copyright 2017 apex-yu.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package org.recluster.common.inject.assistedinject;

import org.recluster.common.inject.Inject;
import org.recluster.common.inject.TypeLiteral;

import java.lang.annotation.Annotation;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Internal representation of a constructor annotated with
 * {@link AssistedInject}
 *
 * @author jmourits@google.com (Jerome Mourits)
 * @author jessewilson@google.com (Jesse Wilson)
 */
class AssistedConstructor<T> {

    private final Constructor<T> constructor;
    private final ParameterListKey assistedParameters;
    private final List<Parameter> allParameters;

    @SuppressWarnings("unchecked")
    AssistedConstructor(Constructor<T> constructor, List<TypeLiteral<?>> parameterTypes) {
        this.constructor = constructor;

        Annotation[][] annotations = constructor.getParameterAnnotations();

        List<Type> typeList = new ArrayList<>();
        allParameters = new ArrayList<>(parameterTypes.size());

        // categorize params as @Assisted or @Injected
        for (int i = 0; i < parameterTypes.size(); i++) {
            Parameter parameter = new Parameter(parameterTypes.get(i).getType(), annotations[i]);
            allParameters.add(parameter);
            if (parameter.isProvidedByFactory()) {
                typeList.add(parameter.getType());
            }
        }
        this.assistedParameters = new ParameterListKey(typeList);
    }

    /**
     * Returns the {@link ParameterListKey} for this constructor.  The
     * {@link ParameterListKey} is created from the ordered list of {@link Assisted}
     * constructor parameters.
     */
    public ParameterListKey getAssistedParameters() {
        return assistedParameters;
    }

    /**
     * Returns an ordered list of all constructor parameters (both
     * {@link Assisted} and {@link Inject}ed).
     */
    public List<Parameter> getAllParameters() {
        return allParameters;
    }

    public Set<Class<?>> getDeclaredExceptions() {
        return new HashSet<>(Arrays.asList(constructor.getExceptionTypes()));
    }

    /**
     * Returns an instance of T, constructed using this constructor, with the
     * supplied arguments.
     */
    public T newInstance(Object[] args) throws Throwable {
        try {
            return constructor.newInstance(args);
        } catch (InvocationTargetException e) {
            throw e.getCause();
        }
    }

    @Override
    public String toString() {
        return constructor.toString();
    }
}
