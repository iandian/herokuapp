# coding=utf-8
import factory

from fusn.models.catalogue import ProductClass, Category, ProductCategory, \
    Product, ProductRecommendation, ProductAttribute, \
    ProductAttributeValue, AttributeOptionGroup, \
    AttributeOption, Option, ProductImage

__all__ = [
    'ProductClassFactory', 'ProductFactory',
    'CategoryFactory', 'ProductCategoryFactory',
    'ProductAttributeFactory', 'AttributeOptionGroupFactory',
    'OptionFactory', 'AttributeOptionFactory',
    'ProductAttributeValueFactory',
]


class ProductClassFactory(factory.DjangoModelFactory):
    name = "Books"
    requires_shipping = True
    track_stock = True

    class Meta:
        model = ProductClass


class ProductFactory(factory.DjangoModelFactory):
    class Meta:
        model = Product

    structure = Meta.model.STANDALONE
    upc = factory.Sequence(lambda n: '978080213020%d' % n)
    title = "A confederacy of dunces"
    product_class = factory.SubFactory(ProductClassFactory)

    stockrecords = factory.RelatedFactory(
        'fusn.tests.factories.StockRecordFactory', 'product')
    categories = factory.RelatedFactory(
        'fusn.tests.factories.ProductCategoryFactory', 'product')


class CategoryFactory(factory.DjangoModelFactory):
    name = factory.Sequence(lambda n: 'Category %d' % n)

    # Very naive handling of treebeard node fields. Works though!
    depth = 1
    path = factory.Sequence(lambda n: '%04d' % n)

    class Meta:
        model = Category


class ProductCategoryFactory(factory.DjangoModelFactory):
    category = factory.SubFactory(CategoryFactory)

    class Meta:
        model = ProductCategory


class ProductAttributeFactory(factory.DjangoModelFactory):
    code = name = 'weight'
    product_class = factory.SubFactory(ProductClassFactory)
    type = "float"

    class Meta:
        model = ProductAttribute


class OptionFactory(factory.DjangoModelFactory):
    class Meta:
        model = Option

    name = 'example option'
    code = 'example'
    type = Meta.model.OPTIONAL


class AttributeOptionFactory(factory.DjangoModelFactory):
    # Ideally we'd get_or_create a AttributeOptionGroup here, but I'm not
    # aware of how to not create a unique option group for each call of the
    # factory

    option = factory.Sequence(lambda n: 'Option %d' % n)

    class Meta:
        model = AttributeOption


class AttributeOptionGroupFactory(factory.DjangoModelFactory):
    name = 'Grüppchen'

    class Meta:
        model = AttributeOptionGroup


class ProductAttributeValueFactory(factory.DjangoModelFactory):
    attribute = factory.SubFactory(ProductAttributeFactory)
    product = factory.SubFactory(ProductFactory)

    class Meta:
        model = ProductAttributeValue


# class ProductReviewFactory(factory.DjangoModelFactory):
#     score = 5
#     product = factory.SubFactory(ProductFactory, stockrecords=[])

#     class Meta:
#         model = get_model('reviews', 'ProductReview')
