/* 
 * The MIT License
 *
 * Copyright 2017 apex-yu.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package org.recluster.common.inject.util;

import org.recluster.common.inject.Provider;
import org.recluster.common.inject.internal.MoreTypes;
import org.recluster.common.inject.internal.MoreTypes.GenericArrayTypeImpl;
import org.recluster.common.inject.internal.MoreTypes.ParameterizedTypeImpl;
import org.recluster.common.inject.internal.MoreTypes.WildcardTypeImpl;

import java.lang.reflect.GenericArrayType;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.WildcardType;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Static methods for working with types.
 *
 * @author crazybob@google.com (Bob Lee)
 * @since 2.0
 */
public final class Types {
    private Types() {
    }

    /**
     * Returns a new parameterized type, applying {@code typeArguments} to
     * {@code rawType}. The returned type does not have an owner type.
     *
     * @return a parameterized type.
     */
    public static ParameterizedType newParameterizedType(Type rawType, Type... typeArguments) {
        return newParameterizedTypeWithOwner(null, rawType, typeArguments);
    }

    /**
     * Returns a new parameterized type, applying {@code typeArguments} to
     * {@code rawType} and enclosed by {@code ownerType}.
     *
     * @return a parameterized type.
     */
    public static ParameterizedType newParameterizedTypeWithOwner(
            Type ownerType, Type rawType, Type... typeArguments) {
        return new ParameterizedTypeImpl(ownerType, rawType, typeArguments);
    }

    /**
     * Returns an array type whose elements are all instances of
     * {@code componentType}.
     *
     * @return a generic array type.
     */
    public static GenericArrayType arrayOf(Type componentType) {
        return new GenericArrayTypeImpl(componentType);
    }

    /**
     * Returns a type that represents an unknown type that extends {@code bound}.
     * For example, if {@code bound} is {@code CharSequence.class}, this returns
     * {@code ? extends CharSequence}. If {@code bound} is {@code Object.class},
     * this returns {@code ?}, which is shorthand for {@code ? extends Object}.
     */
    public static WildcardType subtypeOf(Type bound) {
        return new WildcardTypeImpl(new Type[]{bound}, MoreTypes.EMPTY_TYPE_ARRAY);
    }

    /**
     * Returns a type that represents an unknown supertype of {@code bound}. For
     * example, if {@code bound} is {@code String.class}, this returns {@code ?
     * super String}.
     */
    public static WildcardType supertypeOf(Type bound) {
        return new WildcardTypeImpl(new Type[]{Object.class}, new Type[]{bound});
    }

    /**
     * Returns a type modelling a {@link List} whose elements are of type
     * {@code elementType}.
     *
     * @return a parameterized type.
     */
    public static ParameterizedType listOf(Type elementType) {
        return newParameterizedType(List.class, elementType);
    }

    /**
     * Returns a type modelling a {@link Set} whose elements are of type
     * {@code elementType}.
     *
     * @return a parameterized type.
     */
    public static ParameterizedType setOf(Type elementType) {
        return newParameterizedType(Set.class, elementType);
    }

    /**
     * Returns a type modelling a {@link Map} whose keys are of type
     * {@code keyType} and whose values are of type {@code valueType}.
     *
     * @return a parameterized type.
     */
    public static ParameterizedType mapOf(Type keyType, Type valueType) {
        return newParameterizedType(Map.class, keyType, valueType);
    }

    // for other custom collections types, use newParameterizedType()

    /**
     * Returns a type modelling a {@link Provider} that provides elements of type
     * {@code elementType}.
     *
     * @return a parameterized type.
     */
    public static ParameterizedType providerOf(Type providedType) {
        return newParameterizedType(Provider.class, providedType);
    }
}