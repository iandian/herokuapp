# encoding: utf-8
require "rails_helper"

describe "Product APIs"  do
  before(:each) {
  }

  describe "GET #show" do

    context "when success get by id" do
      before(:each) do
        @product = create :product
      end

      it "render product json" do
        get "/api/products/#{@product.id}", params: {}, headers: request_headers

        json_data = json_response[:data][:product]

        expect(json_data[:id]).to eql @product.id
        expect(json_data[:name]).to eql @product.name
      end
    end
	

    context "when success get all" do
      before(:each) do
        @product = create :product
      end

      it "render product json" do
        get "/api/products/#{@product.id}", params: {}, headers: request_headers

        json_data = json_response[:data][:product]

        expect(json_data[:id]).to eql @product.id
        expect(json_data[:name]).to eql @product.name
      end
    end

    context "when error" do
      after do
        expect(json_response[:meta][:code]).not_to eql RESPONSE_CODE[:success]
      end

      it "returns the error when product id is not found" do
        @product = create :product


        get "/api/products/1111", params: {}, headers: request_headers

        json_data = json_response[:data]

        expect(json_data.blank?).to eql true
        expect(json_response[:meta][:code]).to eql RESPONSE_CODE[:not_found]
        expect(json_response[:meta][:message]).to eql I18n.t("errors.product.not_found")
      end
    end
  end
end

