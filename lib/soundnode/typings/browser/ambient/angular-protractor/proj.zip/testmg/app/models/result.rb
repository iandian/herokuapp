class Result < ApplicationRecord

	belongs_to :run_record, inverse_of: :results
	belongs_to :test_unit, inverse_of: :results

end