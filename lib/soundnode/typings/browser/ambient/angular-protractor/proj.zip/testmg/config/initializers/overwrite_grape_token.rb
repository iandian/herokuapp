module GrapeDeviseTokenAuth
  class Middleware
    private def unauthorized
      [401,
       { 'Content-Type' => 'application/json'
       },
       [
         { :meta=>{:code=>RESPONSE_CODE[:unauthorized], :message=>I18n.t("errors.not_authenticated") } }.to_json
       ]
      ]
    end
  end
end
