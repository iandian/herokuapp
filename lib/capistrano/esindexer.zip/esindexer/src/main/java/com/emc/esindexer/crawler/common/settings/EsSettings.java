
package com.emc.esindexer.crawler.common.settings;

import com.emc.esindexer.crawler.common.Percentage;
import com.emc.esindexer.crawler.common.TimeValue;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@SuppressWarnings("SameParameterValue")
public class EsSettings {
    private String url;
    private TimeValue updateRate = TimeValue.timeValueMinutes(15);
    private List<String> includes = null;
    private List<String> excludes = null;
    private boolean jsonSupport = false;
    private boolean filenameAsId = false;
    private boolean addFilesize = true;
    private boolean removeDeleted = true;
    private boolean addAsInnerObject = false;
    private boolean storeSource = false;
    private boolean indexContent = true;
    private Percentage indexedChars = null;
    private boolean attributesSupport = false;
    private boolean rawMetadata = false;
    private boolean xmlSupport = false;
    private String checksum = null;
    private boolean indexFolders = true;
    private boolean langDetect = false;
    private boolean continueOnError = false;
    private boolean pdfOcr = true;
    private Ocr ocr = new Ocr();

    public static Builder builder() {
        return new Builder();
    }

    public static final String DEFAULT_DIR = "/tmp/es";
    public static final List<String> DEFAULT_EXCLUDED = Collections.singletonList("~*");
    public static final EsSettings DEFAULT = EsSettings.builder().setUrl(DEFAULT_DIR).setExcludes(DEFAULT_EXCLUDED).build();

    public static class Builder {
        private String url;
        private TimeValue updateRate = TimeValue.timeValueMinutes(15);
        private List<String> includes = null;
        private List<String> excludes = null;
        private boolean jsonSupport = false;
        private boolean filenameAsId = false;
        private boolean addFilesize = true;
        private boolean removeDeleted = true;
        private boolean addAsInnerObject = false;
        private boolean storeSource = false;
        private boolean indexContent = true;
        private Percentage indexedChars = null;
        private boolean attributesSupport = false;
        private boolean rawMetadata = true;
        private String checksum = null;
        private boolean xmlSupport = false;
        private boolean indexFolders = true;
        private boolean langDetect = false;
        private boolean continueOnError = false;
        private boolean pdfOcr = true;
        private Ocr ocr = new Ocr();

        public Builder setUrl(String url) {
            this.url = url;
            return this;
        }

        public Builder setUpdateRate(TimeValue updateRate) {
            this.updateRate = updateRate;
            return this;
        }

        public Builder setIncludes(List<String> includes) {
            this.includes = includes;
            return this;
        }

        public Builder addInclude(String include) {
            if (this.includes == null) {
                this.includes = new ArrayList<>();
            }

            // We refuse to add duplicates
            if (!this.includes.contains(include)) {
                this.includes.add(include);
            }

            return this;
        }

        public Builder setExcludes(List<String> excludes) {
            this.excludes = excludes;
            return this;
        }

        public Builder addExclude(String exclude) {
            if (this.excludes == null) {
                this.excludes = new ArrayList<>();
            }

            // We refuse to add duplicates
            if (!this.excludes.contains(exclude)) {
                this.excludes.add(exclude);
            }

            return this;
        }

        public Builder setJsonSupport(boolean jsonSupport) {
            this.jsonSupport = jsonSupport;
            return this;
        }

        public Builder setFilenameAsId(boolean filenameAsId) {
            this.filenameAsId = filenameAsId;
            return this;
        }

        public Builder setAddFilesize(boolean addFilesize) {
            this.addFilesize = addFilesize;
            return this;
        }

        public Builder setRemoveDeleted(boolean removeDeleted) {
            this.removeDeleted = removeDeleted;
            return this;
        }

        public Builder setAddAsInnerObject(boolean addAsInnerObject) {
            this.addAsInnerObject = addAsInnerObject;
            return this;
        }

        public Builder setStoreSource(boolean storeSource) {
            this.storeSource = storeSource;
            return this;
        }

        public Builder setIndexedChars(Percentage indexedChars) {
            this.indexedChars = indexedChars;
            return this;
        }

        public Builder setIndexContent(boolean indexContent) {
            this.indexContent = indexContent;
            return this;
        }

        public Builder setAttributesSupport(boolean attributesSupport) {
            this.attributesSupport = attributesSupport;
            return this;
        }

        public Builder setRawMetadata(boolean rawMetadata) {
            this.rawMetadata = rawMetadata;
            return this;
        }

        public Builder setChecksum(String checksum) {
            this.checksum = checksum;
            return this;
        }

        public Builder setXmlSupport(boolean xmlSupport) {
            this.xmlSupport = xmlSupport;
            return this;
        }

        public Builder setIndexFolders(boolean indexFolders) {
            this.indexFolders = indexFolders;
            return this;
        }

        public Builder setLangDetect(boolean langDetect) {
            this.langDetect = langDetect;
            return this;
        }

        public Builder setContinueOnError(boolean continueOnError) {
            this.continueOnError = continueOnError;
            return this;
        }

        public Builder setPdfOcr(boolean pdfOcr) {
            this.pdfOcr = pdfOcr;
            return this;
        }

        public Builder setOcr(Ocr ocr) {
            this.ocr = ocr;
            return this;
        }

        public EsSettings build() {
            return new EsSettings(url, updateRate, includes, excludes, jsonSupport, filenameAsId, addFilesize,
                    removeDeleted, addAsInnerObject, storeSource, indexedChars, indexContent, attributesSupport, rawMetadata,
                    checksum, xmlSupport, indexFolders, langDetect, continueOnError, pdfOcr, ocr);
        }
    }

    public EsSettings( ) {

    }

    private EsSettings(String url, TimeValue updateRate, List<String> includes, List<String> excludes, boolean jsonSupport,
                       boolean filenameAsId, boolean addFilesize, boolean removeDeleted, boolean addAsInnerObject, boolean storeSource,
                       Percentage indexedChars, boolean indexContent, boolean attributesSupport, boolean rawMetadata, String checksum, boolean xmlSupport,
                       boolean indexFolders, boolean langDetect, boolean continueOnError, boolean pdfOcr, Ocr ocr) {
        this.url = url;
        this.updateRate = updateRate;
        this.includes = includes;
        this.excludes = excludes;
        this.jsonSupport = jsonSupport;
        this.filenameAsId = filenameAsId;
        this.addFilesize = addFilesize;
        this.removeDeleted = removeDeleted;
        this.addAsInnerObject = addAsInnerObject;
        this.storeSource = storeSource;
        this.indexedChars = indexedChars;
        this.indexContent = indexContent;
        this.attributesSupport = attributesSupport;
        this.rawMetadata = rawMetadata;
        this.checksum = checksum;
        this.xmlSupport = xmlSupport;
        this.indexFolders = indexFolders;
        this.langDetect = langDetect;
        this.continueOnError = continueOnError;
        this.pdfOcr = pdfOcr;
        this.ocr = ocr;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public TimeValue getUpdateRate() {
        return updateRate;
    }

    public void setUpdateRate(TimeValue updateRate) {
        this.updateRate = updateRate;
    }

    public List<String> getIncludes() {
        return includes;
    }

    public void setIncludes(List<String> includes) {
        this.includes = includes;
    }

    public List<String> getExcludes() {
        return excludes;
    }

    public void setExcludes(List<String> excludes) {
        this.excludes = excludes;
    }

    public boolean isJsonSupport() {
        return jsonSupport;
    }

    public void setJsonSupport(boolean jsonSupport) {
        this.jsonSupport = jsonSupport;
    }

    public boolean isFilenameAsId() {
        return filenameAsId;
    }

    public void setFilenameAsId(boolean filenameAsId) {
        this.filenameAsId = filenameAsId;
    }

    public boolean isAddFilesize() {
        return addFilesize;
    }

    public void setAddFilesize(boolean addFilesize) {
        this.addFilesize = addFilesize;
    }

    public boolean isRemoveDeleted() {
        return removeDeleted;
    }

    public void setRemoveDeleted(boolean removeDeleted) {
        this.removeDeleted = removeDeleted;
    }

    public boolean isAddAsInnerObject() {
        return addAsInnerObject;
    }

    public void setAddAsInnerObject(boolean addAsInnerObject) {
        this.addAsInnerObject = addAsInnerObject;
    }

    public boolean isStoreSource() {
        return storeSource;
    }

    public void setStoreSource(boolean storeSource) {
        this.storeSource = storeSource;
    }

    public Percentage getIndexedChars() {
        return indexedChars;
    }

    public void setIndexedChars(Percentage indexedChars) {
        this.indexedChars = indexedChars;
    }

    public boolean isIndexContent() {
        return indexContent;
    }

    public void setIndexContent(boolean indexContent) {
        this.indexContent = indexContent;
    }

    public boolean isAttributesSupport() {
        return attributesSupport;
    }

    public void setAttributesSupport(boolean attributesSupport) {
        this.attributesSupport = attributesSupport;
    }

    public boolean isRawMetadata() {
        return rawMetadata;
    }

    public void setRawMetadata(boolean rawMetadata) {
        this.rawMetadata = rawMetadata;
    }

    public String getChecksum() {
        return checksum;
    }

    public void setChecksum(String checksum) {
        this.checksum = checksum;
    }

    public boolean isXmlSupport() {
        return xmlSupport;
    }

    public void setXmlSupport(boolean xmlSupport) {
        this.xmlSupport = xmlSupport;
    }

    public boolean isIndexFolders() {
        return indexFolders;
    }

    public void setIndexFolders(boolean indexFolders) {
        this.indexFolders = indexFolders;
    }

    public boolean isLangDetect() {
        return langDetect;
    }

    public void setLangDetect(boolean langDetect) {
        this.langDetect = langDetect;
    }

    public boolean isContinueOnError() {
        return continueOnError;
    }

    public void setContinueOnError(boolean continueOnError) {
        this.continueOnError = continueOnError;
    }

    public boolean isPdfOcr() {
        return pdfOcr;
    }

    public void setPdfOcr(boolean pdfOcr) {
        this.pdfOcr = pdfOcr;
    }

    public Ocr getOcr() {
        return ocr;
    }

    public void setOcr(Ocr ocr) {
        this.ocr = ocr;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        EsSettings esSettings = (EsSettings) o;

        if (jsonSupport != esSettings.jsonSupport) return false;
        if (xmlSupport != esSettings.xmlSupport) return false;
        if (indexFolders != esSettings.indexFolders) return false;
        if (filenameAsId != esSettings.filenameAsId) return false;
        if (addFilesize != esSettings.addFilesize) return false;
        if (removeDeleted != esSettings.removeDeleted) return false;
        if (addAsInnerObject != esSettings.addAsInnerObject) return false;
        if (storeSource != esSettings.storeSource) return false;
        if (indexContent != esSettings.indexContent) return false;
        if (attributesSupport != esSettings.attributesSupport) return false;
        if (rawMetadata != esSettings.rawMetadata) return false;
        if (langDetect != esSettings.langDetect) return false;
        if (continueOnError != esSettings.continueOnError) return false;
        if (pdfOcr != esSettings.pdfOcr) return false;
        if (url != null ? !url.equals(esSettings.url) : esSettings.url != null) return false;
        if (updateRate != null ? !updateRate.equals(esSettings.updateRate) : esSettings.updateRate != null) return false;
        if (includes != null ? !includes.equals(esSettings.includes) : esSettings.includes != null) return false;
        if (excludes != null ? !excludes.equals(esSettings.excludes) : esSettings.excludes != null) return false;
        if (indexedChars != null ? !indexedChars.equals(esSettings.indexedChars) : esSettings.indexedChars != null) return false;
        return checksum != null ? checksum.equals(esSettings.checksum) : esSettings.checksum == null;

    }

    @Override
    public int hashCode() {
        int result = url != null ? url.hashCode() : 0;
        result = 31 * result + (updateRate != null ? updateRate.hashCode() : 0);
        result = 31 * result + (includes != null ? includes.hashCode() : 0);
        result = 31 * result + (excludes != null ? excludes.hashCode() : 0);
        result = 31 * result + (jsonSupport ? 1 : 0);
        result = 31 * result + (filenameAsId ? 1 : 0);
        result = 31 * result + (addFilesize ? 1 : 0);
        result = 31 * result + (removeDeleted ? 1 : 0);
        result = 31 * result + (addAsInnerObject ? 1 : 0);
        result = 31 * result + (storeSource ? 1 : 0);
        result = 31 * result + (indexContent ? 1 : 0);
        result = 31 * result + (indexedChars != null ? indexedChars.hashCode() : 0);
        result = 31 * result + (attributesSupport ? 1 : 0);
        result = 31 * result + (rawMetadata ? 1 : 0);
        result = 31 * result + (xmlSupport ? 1 : 0);
        result = 31 * result + (checksum != null ? checksum.hashCode() : 0);
        result = 31 * result + (indexFolders ? 1 : 0);
        result = 31 * result + (langDetect ? 1 : 0);
        result = 31 * result + (continueOnError ? 1 : 0);
        result = 31 * result + (pdfOcr ? 1 : 0);
        return result;
    }
}
