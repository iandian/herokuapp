class CreateResults < ActiveRecord::Migration[5.0]
  def change
    create_table :results do |t|
      t.boolean :value
	  t.belongs_to :test_unit
	  t.belongs_to :run_record
	  t.timestamps
    end
  end
end
