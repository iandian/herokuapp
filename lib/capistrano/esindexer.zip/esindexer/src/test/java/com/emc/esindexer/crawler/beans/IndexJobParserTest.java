/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.emc.esindexer.crawler.beans;

import com.emc.esindexer.testbase.AbstractTestCase;
import java.io.IOException;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

import java.time.LocalDateTime;
import static org.hamcrest.CoreMatchers.is;

/**
 *
 * @author yua13
 */
public class IndexJobParserTest extends AbstractTestCase{

    public IndexJobParserTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    /**
     * We check that the date which is generated on disk does not change when we
     * read it again
     *
     * @throws IOException In case of serialization problem
     */
    @Test
    public void testDateTimeSerialization() throws IOException {
        LocalDateTime now = LocalDateTime.now();
        IndexJob job = IndexJob.builder().setLastrun(now).build();
        String json = IndexJobParser.toJson(job);
        IndexJob generated = IndexJobParser.fromJson(json);
        assertThat(generated.getLastrun(), is(now));
    }

    @Test
    public void testParseEmptyJob() throws IOException {
        IndexJob emptyJob = IndexJob.builder().build();
        String json = IndexJobParser.toJson(emptyJob);
        IndexJob generated = IndexJobParser.fromJson(json);
        assertThat(generated, is(emptyJob));
    }

    @Test
    public void testParseJob() throws IOException {
        IndexJob job = IndexJob.builder()
                .setName(getCurrentTestName())
                .setLastrun(LocalDateTime.now())
                .setIndexed(1000)
                .setDeleted(5)
                .build();
        String json = IndexJobParser.toJson(job);
        IndexJob generated = IndexJobParser.fromJson(json);
        assertThat(generated, is(job));
    }

}
