class TestScenePolicy < ApplicationPolicy

end
