/*
 * Licensed to Recluster under one or more contributor
 * license agreements. See the NOTICE file distributed with
 * this work for additional information regarding copyright
 * ownership. Recluster licenses this file to you under
 * the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.recluster.client.support;

import org.recluster.action.Action;
import org.recluster.action.ActionFuture;
import org.recluster.action.ActionListener;
import org.recluster.action.ActionRequest;
import org.recluster.action.ActionRequestBuilder;
import org.recluster.action.ActionResponse;
import org.recluster.action.admin.cluster.node.hotthreads.NodesHotThreadsAction;
import org.recluster.action.admin.cluster.node.hotthreads.NodesHotThreadsRequest;
import org.recluster.action.admin.cluster.node.hotthreads.NodesHotThreadsRequestBuilder;
import org.recluster.action.admin.cluster.node.hotthreads.NodesHotThreadsResponse;
import org.recluster.action.admin.cluster.node.info.NodesInfoAction;
import org.recluster.action.admin.cluster.node.info.NodesInfoRequest;
import org.recluster.action.admin.cluster.node.info.NodesInfoRequestBuilder;
import org.recluster.action.admin.cluster.node.info.NodesInfoResponse;
import org.recluster.action.admin.cluster.node.stats.NodesStatsAction;
import org.recluster.action.admin.cluster.node.stats.NodesStatsRequest;
import org.recluster.action.admin.cluster.node.stats.NodesStatsRequestBuilder;
import org.recluster.action.admin.cluster.node.stats.NodesStatsResponse;
import org.recluster.action.admin.cluster.node.tasks.cancel.CancelTasksAction;
import org.recluster.action.admin.cluster.node.tasks.cancel.CancelTasksRequest;
import org.recluster.action.admin.cluster.node.tasks.cancel.CancelTasksRequestBuilder;
import org.recluster.action.admin.cluster.node.tasks.cancel.CancelTasksResponse;
import org.recluster.action.admin.cluster.node.tasks.list.ListTasksAction;
import org.recluster.action.admin.cluster.node.tasks.list.ListTasksRequest;
import org.recluster.action.admin.cluster.node.tasks.list.ListTasksRequestBuilder;
import org.recluster.action.admin.cluster.node.tasks.list.ListTasksResponse;
import org.recluster.action.support.PlainActionFuture;
import org.recluster.action.support.ThreadedActionListener;
import org.recluster.action.admin.cluster.state.ClusterStateAction;
import org.recluster.action.admin.cluster.state.ClusterStateRequest;
import org.recluster.action.admin.cluster.state.ClusterStateRequestBuilder;
import org.recluster.action.admin.cluster.state.ClusterStateResponse;
import org.recluster.client.AdminClient;
import org.recluster.client.Client;
import org.recluster.client.ClusterAdminClient;
import org.recluster.client.ReclusterClient;
import org.recluster.common.component.AbstractComponent;
import org.recluster.common.settings.Settings;
import org.recluster.tasks.TaskId;
import org.recluster.threadpool.ThreadPool;


public abstract class AbstractClient extends AbstractComponent implements Client {

    private final ThreadPool threadPool;
    private final Admin admin;
    private final ThreadedActionListener.Wrapper threadedWrapper;

    public AbstractClient(Settings settings, ThreadPool threadPool) {
        super(settings);
        this.threadPool = threadPool;
        this.admin = new Admin(this);
        this.threadedWrapper = new ThreadedActionListener.Wrapper(logger, settings, threadPool);
    }

    @Override
    public final Settings settings() {
        return this.settings;
    }

    @Override
    public final ThreadPool threadPool() {
        return this.threadPool;
    }

    @Override
    public final AdminClient admin() {
        return admin;
    }

    @Override
    public final <Request extends ActionRequest, Response extends ActionResponse, RequestBuilder extends ActionRequestBuilder<Request, Response, RequestBuilder>> RequestBuilder prepareExecute(
            final Action<Request, Response, RequestBuilder> action) {
        return action.newRequestBuilder(this);
    }

    @Override
    public final <Request extends ActionRequest, Response extends ActionResponse, RequestBuilder extends ActionRequestBuilder<Request, Response, RequestBuilder>> ActionFuture<Response> execute(
            Action<Request, Response, RequestBuilder> action, Request request) {
        PlainActionFuture<Response> actionFuture = PlainActionFuture.newFuture();
        execute(action, request, actionFuture);
        return actionFuture;
    }

    /**
     * This is the single execution point of *all* clients.
     */
    @Override
    public final <Request extends ActionRequest, Response extends ActionResponse, RequestBuilder extends ActionRequestBuilder<Request, Response, RequestBuilder>> void execute(
            Action<Request, Response, RequestBuilder> action, Request request, ActionListener<Response> listener) {
        listener = threadedWrapper.wrap(listener);
        doExecute(action, request, listener);
    }

    protected abstract <Request extends ActionRequest, Response extends ActionResponse, RequestBuilder extends ActionRequestBuilder<Request, Response, RequestBuilder>> void doExecute(Action<Request, Response, RequestBuilder> action, Request request, ActionListener<Response> listener);


    static class Admin implements AdminClient {

        private final ClusterAdmin clusterAdmin;

        Admin(ReclusterClient client) {
            this.clusterAdmin = new ClusterAdmin(client);
        }

        @Override
        public ClusterAdminClient cluster() {
            return clusterAdmin;
        }
    }

    static class ClusterAdmin implements ClusterAdminClient {

        private final ReclusterClient client;

        ClusterAdmin(ReclusterClient client) {
            this.client = client;
        }

        @Override
        public <Request extends ActionRequest, Response extends ActionResponse, RequestBuilder extends ActionRequestBuilder<Request, Response, RequestBuilder>> ActionFuture<Response> execute(
                Action<Request, Response, RequestBuilder> action, Request request) {
            return client.execute(action, request);
        }

        @Override
        public <Request extends ActionRequest, Response extends ActionResponse, RequestBuilder extends ActionRequestBuilder<Request, Response, RequestBuilder>> void execute(
                Action<Request, Response, RequestBuilder> action, Request request, ActionListener<Response> listener) {
            client.execute(action, request, listener);
        }

        @Override
        public <Request extends ActionRequest, Response extends ActionResponse, RequestBuilder extends ActionRequestBuilder<Request, Response, RequestBuilder>> RequestBuilder prepareExecute(
                Action<Request, Response, RequestBuilder> action) {
            return client.prepareExecute(action);
        }

        @Override
        public ThreadPool threadPool() {
            return client.threadPool();
        }

        @Override
        public ActionFuture<ClusterStateResponse> state(final ClusterStateRequest request) {
            return execute(ClusterStateAction.INSTANCE, request);
        }

        @Override
        public void state(final ClusterStateRequest request, final ActionListener<ClusterStateResponse> listener) {
            execute(ClusterStateAction.INSTANCE, request, listener);
        }

        @Override
        public ClusterStateRequestBuilder prepareState() {
            return new ClusterStateRequestBuilder(this, ClusterStateAction.INSTANCE);
        }

        @Override
        public ActionFuture<NodesInfoResponse> nodesInfo(final NodesInfoRequest request) {
            return execute(NodesInfoAction.INSTANCE, request);
        }

        @Override
        public void nodesInfo(final NodesInfoRequest request, final ActionListener<NodesInfoResponse> listener) {
            execute(NodesInfoAction.INSTANCE, request, listener);
        }

        @Override
        public NodesInfoRequestBuilder prepareNodesInfo(String... nodesIds) {
            return new NodesInfoRequestBuilder(this, NodesInfoAction.INSTANCE).setNodesIds(nodesIds);
        }

        @Override
        public ActionFuture<NodesStatsResponse> nodesStats(final NodesStatsRequest request) {
            return execute(NodesStatsAction.INSTANCE, request);
        }

        @Override
        public void nodesStats(final NodesStatsRequest request, final ActionListener<NodesStatsResponse> listener) {
            execute(NodesStatsAction.INSTANCE, request, listener);
        }

        @Override
        public NodesStatsRequestBuilder prepareNodesStats(String... nodesIds) {
            return new NodesStatsRequestBuilder(this, NodesStatsAction.INSTANCE).setNodesIds(nodesIds);
        }

        @Override
        public ActionFuture<NodesHotThreadsResponse> nodesHotThreads(NodesHotThreadsRequest request) {
            return execute(NodesHotThreadsAction.INSTANCE, request);
        }

        @Override
        public void nodesHotThreads(NodesHotThreadsRequest request, ActionListener<NodesHotThreadsResponse> listener) {
            execute(NodesHotThreadsAction.INSTANCE, request, listener);
        }

        @Override
        public NodesHotThreadsRequestBuilder prepareNodesHotThreads(String... nodesIds) {
            return new NodesHotThreadsRequestBuilder(this, NodesHotThreadsAction.INSTANCE).setNodesIds(nodesIds);
        }

        @Override
        public ActionFuture<ListTasksResponse> listTasks(final ListTasksRequest request) {
            return execute(ListTasksAction.INSTANCE, request);
        }

        @Override
        public void listTasks(final ListTasksRequest request, final ActionListener<ListTasksResponse> listener) {
            execute(ListTasksAction.INSTANCE, request, listener);
        }

        @Override
        public ListTasksRequestBuilder prepareListTasks(String... nodesIds) {
            return new ListTasksRequestBuilder(this, ListTasksAction.INSTANCE).setNodesIds(nodesIds);
        }

        @Override
        public ActionFuture<CancelTasksResponse> cancelTasks(CancelTasksRequest request) {
            return execute(CancelTasksAction.INSTANCE, request);
        }

        @Override
        public void cancelTasks(CancelTasksRequest request, ActionListener<CancelTasksResponse> listener) {
            execute(CancelTasksAction.INSTANCE, request, listener);
        }

        @Override
        public CancelTasksRequestBuilder prepareCancelTasks(String... nodesIds) {
            return new CancelTasksRequestBuilder(this, CancelTasksAction.INSTANCE).setNodesIds(nodesIds);
        }

    }

}
