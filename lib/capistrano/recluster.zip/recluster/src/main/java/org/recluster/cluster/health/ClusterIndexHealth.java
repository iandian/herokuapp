///* 
// * The MIT License
// *
// * Copyright 2017 apex-yu.
// *
// * Permission is hereby granted, free of charge, to any person obtaining a copy
// * of this software and associated documentation files (the "Software"), to deal
// * in the Software without restriction, including without limitation the rights
// * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// * copies of the Software, and to permit persons to whom the Software is
// * furnished to do so, subject to the following conditions:
// *
// * The above copyright notice and this permission notice shall be included in
// * all copies or substantial portions of the Software.
// *
// * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// * THE SOFTWARE.
// */
//package org.recluster.cluster.health;
//
//import org.recluster.cluster.metadata.IndexMetaData;
//import org.recluster.cluster.routing.IndexRoutingTable;
//import org.recluster.cluster.routing.IndexShardRoutingTable;
//import org.recluster.common.io.stream.StreamInput;
//import org.recluster.common.io.stream.StreamOutput;
//import org.recluster.common.io.stream.Writeable;
//import org.recluster.common.xcontent.ToXContentFragment;
//import org.recluster.common.xcontent.XContentBuilder;
//
//import java.io.IOException;
//import java.util.HashMap;
//import java.util.Iterator;
//import java.util.Locale;
//import java.util.Map;
//
//public final class ClusterIndexHealth implements Iterable<ClusterShardHealth>, Writeable, ToXContentFragment {
//
//    private final String index;
//    private final int numberOfShards;
//    private final int numberOfReplicas;
//    private final int activeShards;
//    private final int relocatingShards;
//    private final int initializingShards;
//    private final int unassignedShards;
//    private final int activePrimaryShards;
//    private final ClusterHealthStatus status;
//    private final Map<Integer, ClusterShardHealth> shards = new HashMap<>();
//
//    public ClusterIndexHealth(final IndexMetaData indexMetaData, final IndexRoutingTable indexRoutingTable) {
//        this.index = indexMetaData.getIndex().getName();
//        this.numberOfShards = indexMetaData.getNumberOfShards();
//        this.numberOfReplicas = indexMetaData.getNumberOfReplicas();
//
//        for (IndexShardRoutingTable shardRoutingTable : indexRoutingTable) {
//            int shardId = shardRoutingTable.shardId().id();
//            shards.put(shardId, new ClusterShardHealth(shardId, shardRoutingTable));
//        }
//
//        // update the index status
//        ClusterHealthStatus computeStatus = ClusterHealthStatus.GREEN;
//        int computeActivePrimaryShards = 0;
//        int computeActiveShards = 0;
//        int computeRelocatingShards = 0;
//        int computeInitializingShards = 0;
//        int computeUnassignedShards = 0;
//        for (ClusterShardHealth shardHealth : shards.values()) {
//            if (shardHealth.isPrimaryActive()) {
//                computeActivePrimaryShards++;
//            }
//            computeActiveShards += shardHealth.getActiveShards();
//            computeRelocatingShards += shardHealth.getRelocatingShards();
//            computeInitializingShards += shardHealth.getInitializingShards();
//            computeUnassignedShards += shardHealth.getUnassignedShards();
//
//            if (shardHealth.getStatus() == ClusterHealthStatus.RED) {
//                computeStatus = ClusterHealthStatus.RED;
//            } else if (shardHealth.getStatus() == ClusterHealthStatus.YELLOW && computeStatus != ClusterHealthStatus.RED) {
//                // do not override an existing red
//                computeStatus = ClusterHealthStatus.YELLOW;
//            }
//        }
//        if (shards.isEmpty()) { // might be since none has been created yet (two phase index creation)
//            computeStatus = ClusterHealthStatus.RED;
//        }
//
//        this.status = computeStatus;
//        this.activePrimaryShards = computeActivePrimaryShards;
//        this.activeShards = computeActiveShards;
//        this.relocatingShards = computeRelocatingShards;
//        this.initializingShards = computeInitializingShards;
//        this.unassignedShards = computeUnassignedShards;
//    }
//
//    public ClusterIndexHealth(final StreamInput in) throws IOException {
//        index = in.readString();
//        numberOfShards = in.readVInt();
//        numberOfReplicas = in.readVInt();
//        activePrimaryShards = in.readVInt();
//        activeShards = in.readVInt();
//        relocatingShards = in.readVInt();
//        initializingShards = in.readVInt();
//        unassignedShards = in.readVInt();
//        status = ClusterHealthStatus.fromValue(in.readByte());
//
//        int size = in.readVInt();
//        for (int i = 0; i < size; i++) {
//            ClusterShardHealth shardHealth = new ClusterShardHealth(in);
//            shards.put(shardHealth.getId(), shardHealth);
//        }
//    }
//
//    public String getIndex() {
//        return index;
//    }
//
//    public int getNumberOfShards() {
//        return numberOfShards;
//    }
//
//    public int getNumberOfReplicas() {
//        return numberOfReplicas;
//    }
//
//    public int getActiveShards() {
//        return activeShards;
//    }
//
//    public int getRelocatingShards() {
//        return relocatingShards;
//    }
//
//    public int getActivePrimaryShards() {
//        return activePrimaryShards;
//    }
//
//    public int getInitializingShards() {
//        return initializingShards;
//    }
//
//    public int getUnassignedShards() {
//        return unassignedShards;
//    }
//
//    public ClusterHealthStatus getStatus() {
//        return status;
//    }
//
//    public Map<Integer, ClusterShardHealth> getShards() {
//        return this.shards;
//    }
//
//    @Override
//    public Iterator<ClusterShardHealth> iterator() {
//        return shards.values().iterator();
//    }
//
//    @Override
//    public void writeTo(final StreamOutput out) throws IOException {
//        out.writeString(index);
//        out.writeVInt(numberOfShards);
//        out.writeVInt(numberOfReplicas);
//        out.writeVInt(activePrimaryShards);
//        out.writeVInt(activeShards);
//        out.writeVInt(relocatingShards);
//        out.writeVInt(initializingShards);
//        out.writeVInt(unassignedShards);
//        out.writeByte(status.value());
//
//        out.writeVInt(shards.size());
//        for (ClusterShardHealth shardHealth : this) {
//            shardHealth.writeTo(out);
//        }
//    }
//
//    private static final String STATUS = "status";
//    private static final String NUMBER_OF_SHARDS = "number_of_shards";
//    private static final String NUMBER_OF_REPLICAS = "number_of_replicas";
//    private static final String ACTIVE_PRIMARY_SHARDS = "active_primary_shards";
//    private static final String ACTIVE_SHARDS = "active_shards";
//    private static final String RELOCATING_SHARDS = "relocating_shards";
//    private static final String INITIALIZING_SHARDS = "initializing_shards";
//    private static final String UNASSIGNED_SHARDS = "unassigned_shards";
//    private static final String SHARDS = "shards";
//    private static final String PRIMARY_ACTIVE = "primary_active";
//
//    @Override
//    public XContentBuilder toXContent(final XContentBuilder builder, final Params params) throws IOException {
//        builder.field(STATUS, getStatus().name().toLowerCase(Locale.ROOT));
//        builder.field(NUMBER_OF_SHARDS, getNumberOfShards());
//        builder.field(NUMBER_OF_REPLICAS, getNumberOfReplicas());
//        builder.field(ACTIVE_PRIMARY_SHARDS, getActivePrimaryShards());
//        builder.field(ACTIVE_SHARDS, getActiveShards());
//        builder.field(RELOCATING_SHARDS, getRelocatingShards());
//        builder.field(INITIALIZING_SHARDS, getInitializingShards());
//        builder.field(UNASSIGNED_SHARDS, getUnassignedShards());
//
//        if ("shards".equals(params.param("level", "indices"))) {
//            builder.startObject(SHARDS);
//
//            for (ClusterShardHealth shardHealth : shards.values()) {
//                builder.startObject(Integer.toString(shardHealth.getId()));
//
//                builder.field(STATUS, shardHealth.getStatus().name().toLowerCase(Locale.ROOT));
//                builder.field(PRIMARY_ACTIVE, shardHealth.isPrimaryActive());
//                builder.field(ACTIVE_SHARDS, shardHealth.getActiveShards());
//                builder.field(RELOCATING_SHARDS, shardHealth.getRelocatingShards());
//                builder.field(INITIALIZING_SHARDS, shardHealth.getInitializingShards());
//                builder.field(UNASSIGNED_SHARDS, shardHealth.getUnassignedShards());
//
//                builder.endObject();
//            }
//
//            builder.endObject();
//        }
//        return builder;
//    }
//}
