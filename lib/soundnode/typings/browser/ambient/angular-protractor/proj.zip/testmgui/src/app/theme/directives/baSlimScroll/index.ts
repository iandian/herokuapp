export * from './baSlimScroll.directive';
