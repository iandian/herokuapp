/* 
 * The MIT License
 *
 * Copyright 2017 apex-yu.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package org.recluster.common.inject;

import org.recluster.common.inject.internal.Errors;
import org.recluster.common.inject.spi.InjectionListener;
import org.recluster.common.inject.spi.Message;
import org.recluster.common.inject.spi.TypeEncounter;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * @author jessewilson@google.com (Jesse Wilson)
 */
final class EncounterImpl<T> implements TypeEncounter<T> {

    private final Errors errors;
    private final Lookups lookups;
    private List<MembersInjector<? super T>> membersInjectors; // lazy
    private List<InjectionListener<? super T>> injectionListeners; // lazy
    private boolean valid = true;

    EncounterImpl(Errors errors, Lookups lookups) {
        this.errors = errors;
        this.lookups = lookups;
    }

    public void invalidate() {
        valid = false;
    }

    public List<MembersInjector<? super T>> getMembersInjectors() {
        return membersInjectors == null
                ? Collections.<MembersInjector<? super T>>emptyList()
                : Collections.unmodifiableList(membersInjectors);
    }

    public List<InjectionListener<? super T>> getInjectionListeners() {
        return injectionListeners == null
                ? Collections.<InjectionListener<? super T>>emptyList()
                : Collections.unmodifiableList(injectionListeners);
    }

    @Override
    public void register(MembersInjector<? super T> membersInjector) {
        if (!valid) {
            throw new IllegalStateException("Encounters may not be used after hear() returns.");
        }

        if (membersInjectors == null) {
            membersInjectors = new ArrayList<>();
        }

        membersInjectors.add(membersInjector);
    }

    @Override
    public void register(InjectionListener<? super T> injectionListener) {
        if (!valid) {
            throw new IllegalStateException("Encounters may not be used after hear() returns.");
        }

        if (injectionListeners == null) {
            injectionListeners = new ArrayList<>();
        }

        injectionListeners.add(injectionListener);
    }

    @Override
    public void addError(String message, Object... arguments) {
        if (!valid) {
            throw new IllegalStateException("Encounters may not be used after hear() returns.");
        }
        errors.addMessage(message, arguments);
    }

    @Override
    public void addError(Throwable t) {
        if (!valid) {
            throw new IllegalStateException("Encounters may not be used after hear() returns.");
        }
        errors.errorInUserCode(t, "An exception was caught and reported. Message: %s", t.getMessage());
    }

    @Override
    public void addError(Message message) {
        if (!valid) {
            throw new IllegalStateException("Encounters may not be used after hear() returns.");
        }
        errors.addMessage(message);
    }

    @Override
    public <T> Provider<T> getProvider(Key<T> key) {
        if (!valid) {
            throw new IllegalStateException("Encounters may not be used after hear() returns.");
        }
        return lookups.getProvider(key);
    }

    @Override
    public <T> Provider<T> getProvider(Class<T> type) {
        return getProvider(Key.get(type));
    }

    @Override
    public <T> MembersInjector<T> getMembersInjector(TypeLiteral<T> typeLiteral) {
        if (!valid) {
            throw new IllegalStateException("Encounters may not be used after hear() returns.");
        }
        return lookups.getMembersInjector(typeLiteral);
    }

    @Override
    public <T> MembersInjector<T> getMembersInjector(Class<T> type) {
        return getMembersInjector(TypeLiteral.get(type));
    }
}