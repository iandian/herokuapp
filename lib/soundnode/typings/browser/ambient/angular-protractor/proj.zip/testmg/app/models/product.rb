class Product < ApplicationRecord

	has_many :builds, :dependent => :destroy, inverse_of: :product

end