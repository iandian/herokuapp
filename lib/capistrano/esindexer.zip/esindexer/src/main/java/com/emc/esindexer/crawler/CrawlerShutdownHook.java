package com.emc.esindexer.crawler;


/**
 * Shutdown hook so we make sure we close everything
 */
public class CrawlerShutdownHook extends Thread implements Runnable {

    private final Crawler crawler;

    public CrawlerShutdownHook(Crawler crawler) {
        this.crawler = crawler;
    }

    @Override
    public void run() {
        try {
            crawler.close();
            // Stop the REST Server if needed
//            RestServer.close();
        } catch (InterruptedException ignored) {
            Thread.currentThread().interrupt();
        }
    }
}
