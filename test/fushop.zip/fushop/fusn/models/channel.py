# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
import logging


logger = logging.getLogger(__name__)

class Channel(models.Model):    
    name = models.CharField(max_length=50, blank=True, default='')
    url = models.URLField(blank=True, default='')
    icon_url = models.URLField(blank=True, default='')
    sort_order = models.IntegerField()


    class Meta:
        verbose_name = "Channel"
        verbose_name_plural = "Channel"

    def __unicode__(self):
        return '%s %s' % (self.name, self.url)