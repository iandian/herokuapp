module BuildBase
  extend ActiveSupport::Concern

  included do

    helpers do
      def get_build(id)
        @build = Build.find(id)

        unless @build
          raise ApiException.new(
            http_status: RESPONSE_CODE[:not_found], 
            code: RESPONSE_CODE[:not_found], 
            message: I18n.t('errors.build.not_found')
          )
        end
      end
	  
      def create_build(params)
        @build = Build.new(params)
		authorize @build, :create?
        unless @build.save
          raise ApiException.new(
            http_status: RESPONSE_CODE[:not_found], 
            code: RESPONSE_CODE[:not_found], 
            message: I18n.t('errors.build.not_found')
          )
        end
      end

    end
  end
end