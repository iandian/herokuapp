export * from './baMsgCenter.component';
