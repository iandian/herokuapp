# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from django.contrib.auth.models import User
import logging


logger = logging.getLogger(__name__)

#TODO
class Category(models.Model):
    name = models.CharField(max_length=90)
    keywords = models.CharField(max_length=255)
    front_desc = models.CharField(max_length=255)
    parent = models.ForeignKey("self", blank=True, related_name="children")
    sort_order = models.IntegerField()
    show_index = models.IntegerField()
    is_show = models.BooleanField(default=False)
    banner_url = models.URLField(blank=True)
    icon_url = models.URLField(blank=True)
    img_url = models.URLField(blank=True)
    wap_banner_url = models.URLField(blank=True)
    level = models.CharField(max_length=255)
    type = models.IntegerField()
    front_name = models.CharField(max_length=255)


    class Meta:
        verbose_name = "Category"
        verbose_name_plural = "Category"

    def __unicode__(self):
        return '%s %s' % (self.name, self.keywords)