module TestPipeBase
  extend ActiveSupport::Concern

  included do

    helpers do
      def get_test_pipe(id)
        @test_pipe = TestPipe.find(id)

        unless @test_pipe
          raise ApiException.new(
            http_status: RESPONSE_CODE[:not_found], 
            code: RESPONSE_CODE[:not_found], 
            message: I18n.t('errors.test_pipe.not_found')
          )
        end
      end
	  
      def create_test_pipe(params)
        @test_pipe = TestPipe.new(params)

        unless @test_pipe.save
          raise ApiException.new(
            http_status: RESPONSE_CODE[:not_found], 
            code: RESPONSE_CODE[:not_found], 
            message: I18n.t('errors.test_pipe.not_found')
          )
        end
      end

    end
  end
end