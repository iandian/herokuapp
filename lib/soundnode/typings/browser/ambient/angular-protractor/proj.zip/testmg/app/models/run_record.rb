class RunRecord < ApplicationRecord

	belongs_to :build, inverse_of: :run_records
	
	has_many :results, :dependent => :destroy, inverse_of: :run_record
	
	has_one :report, :dependent => :destroy
end