export * from './responsiveTable.component';
