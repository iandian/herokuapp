# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from attribute_category import AttributeCategory
import logging


logger = logging.getLogger(__name__)

class Brand(models.Model):
    name = models.CharField(max_length=50)
    list_pic_url = models.URLField(blank=True)
    simple_desc = models.CharField(max_length=255, blank=True)
    pic_url = models.URLField(blank=True)
    sort_order = models.IntegerField()
    floor_price = models.DecimalField(
        decimal_places=2, max_digits=12,
        blank=True, null=True)
    app_list_pic_url = models.URLField(blank=True)
    is_new = models.BooleanField(default=False)
    new_pic_url = models.URLField(blank=True)
    new_sort_order = models.IntegerField()

    class Meta:
        verbose_name = "Brand"
        verbose_name_plural = "Brand"

    def __unicode__(self):
        return '%s %s' % (self.name, self.floor_price)