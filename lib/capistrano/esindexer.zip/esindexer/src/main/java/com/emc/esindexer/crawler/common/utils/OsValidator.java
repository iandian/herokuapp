
package com.emc.esindexer.crawler.common.utils;

@SuppressWarnings("WeakerAccess")
public class OsValidator {
    public static final String OS;
    public static final boolean windows;
    public static final boolean mac;
    public static final boolean unix;
    public static final boolean solaris;

    static {
        OS = System.getProperty("os.name").toLowerCase();
        windows = (OS.contains("win"));
        mac = (OS.contains("mac"));
        unix = (OS.contains("nix") || OS.contains("nux") || OS.indexOf("aix") > 0 );
        solaris = (OS.contains("sunos"));
    }
}
