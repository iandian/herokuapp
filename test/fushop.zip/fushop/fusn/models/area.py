# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from django.contrib.auth.models import User
import logging
from .city import City
from .province import Province


logger = logging.getLogger(__name__)


class Area(models.Model):
    code = models.CharField(max_length=255, primary_key=True, db_index=True)
    name = models.CharField(max_length=255, db_index=True)
    city = models.ForeignKey(
        City, related_name='area', on_delete=models.CASCADE, db_column="cityCode")
    provice = models.ForeignKey(
        Province, related_name='area', on_delete=models.CASCADE, db_column="provinceCode")

    class Meta:
        verbose_name = "Area"
        verbose_name_plural = "Area"

    def __unicode__(self):
        return '%s %s' % (self.name, self.code)