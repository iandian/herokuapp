package org.flow.searcher.models;


import com.fasterxml.jackson.core.JsonProcessingException;

import java.io.IOException;
import java.util.Map;

import static org.flow.searcher.common.MetaParser.prettyMapper;

public class DocParser {

    public static String toJson(Doc doc) throws JsonProcessingException {
        return prettyMapper.writeValueAsString(doc);
    }

    public static Doc fromJson(String json) throws IOException {
        return prettyMapper.readValue(json, Doc.class);
    }

    public static Map asMap(String json) throws IOException {
        return prettyMapper.readValue(json, Map.class);
    }
}

