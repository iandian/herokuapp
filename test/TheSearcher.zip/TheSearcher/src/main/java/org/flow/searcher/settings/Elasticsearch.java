package org.flow.searcher.settings;


import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.flow.searcher.common.ByteSizeUnit;
import org.flow.searcher.common.ByteSizeValue;
import org.flow.searcher.common.TimeValue;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Elasticsearch {

    protected static final Logger logger = LogManager.getLogger(Elasticsearch.class);
    public static final ServerUrl NODE_DEFAULT = new ServerUrl("http://127.0.0.1:9200");

    private List<ServerUrl> nodes;
    private String index;
    private String indexFolder;
    private int bulkSize = 100;
    private TimeValue flushInterval = TimeValue.timeValueSeconds(5);
    private ByteSizeValue byteSize = new ByteSizeValue(10, ByteSizeUnit.MB);
    private String username;
    @JsonIgnore
    private String password;
    private String pipeline;

    public Elasticsearch() {

    }

    private Elasticsearch(List<ServerUrl> nodes, String index, String indexFolder, int bulkSize,
                          TimeValue flushInterval, ByteSizeValue byteSize, String username, String password, String pipeline) {
        this.nodes = nodes;
        this.index = index;
        this.indexFolder = indexFolder;
        this.bulkSize = bulkSize;
        this.flushInterval = flushInterval;
        this.byteSize = byteSize;
        this.username = username;
        this.password = password;
        this.pipeline = pipeline;
    }

    public static Builder builder() {
        return new Builder();
    }

    // Using here a method instead of a constant as sadly FSCrawlerValidator can modify this object
    // TODO fix that: a validator should not modify the original object but return a modified copy
    public static Elasticsearch DEFAULT() {
        return Elasticsearch.builder()
                .addNode(NODE_DEFAULT)
                .build();
    }

    public List<ServerUrl> getNodes() {
        return nodes;
    }

    public String getIndex() {
        return index;
    }

    public void setIndex(String index) {
        this.index = index;
    }

    public String getIndexFolder() {
        return indexFolder;
    }

    public void setIndexFolder(String indexFolder) {
        this.indexFolder = indexFolder;
    }

    public int getBulkSize() {
        return bulkSize;
    }

    public TimeValue getFlushInterval() {
        return flushInterval;
    }

    public ByteSizeValue getByteSize() {
        return byteSize;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    @JsonIgnore
    public String getPassword() {
        return password;
    }

    @JsonProperty
    public void setPassword(String password) {
        this.password = password;
    }

    public String getPipeline() {
        return pipeline;
    }

    public void setPipeline(String pipeline) {
        this.pipeline = pipeline;
    }

    public static class Builder {
        private List<ServerUrl> nodes;
        private String index;
        private String indexFolder;
        private int bulkSize = 100;
        private TimeValue flushInterval = TimeValue.timeValueSeconds(5);
        private ByteSizeValue byteSize = new ByteSizeValue(10, ByteSizeUnit.MB);
        private String username = null;
        private String password = null;
        private String pipeline = null;

        public Builder setNodes(List<ServerUrl> nodes) {
            this.nodes = nodes;
            return this;
        }

        public Builder addNode(ServerUrl node) {
            if (this.nodes == null) {
                this.nodes = new ArrayList<>();
            }
            this.nodes.add(node);
            return this;
        }

        public Builder setIndex(String index) {
            this.index = index;
            return this;
        }

        public Builder setIndexFolder(String indexFolder) {
            this.indexFolder = indexFolder;
            return this;
        }

        public Builder setBulkSize(int bulkSize) {
            this.bulkSize = bulkSize;
            return this;
        }

        public Builder setFlushInterval(TimeValue flushInterval) {
            this.flushInterval = flushInterval;
            return this;
        }

        public Builder setByteSize(ByteSizeValue byteSize) {
            this.byteSize = byteSize;
            return this;
        }

        public Builder setUsername(String username) {
            this.username = username;
            return this;
        }

        public Builder setPassword(String password) {
            this.password = password;
            return this;
        }

        public Builder setPipeline(String pipeline) {
            this.pipeline = pipeline;
            return this;
        }

        public Elasticsearch build() {
            return new Elasticsearch(nodes, index, indexFolder, bulkSize, flushInterval, byteSize, username, password, pipeline);
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Elasticsearch that = (Elasticsearch) o;

        if (bulkSize != that.bulkSize) return false;
        if (!Objects.equals(nodes, that.nodes)) return false;
        if (!Objects.equals(index, that.index)) return false;
        if (!Objects.equals(indexFolder, that.indexFolder)) return false;
        if (!Objects.equals(username, that.username)) return false;
        // We can't really test the password as it may be obfuscated
        if (!Objects.equals(pipeline, that.pipeline)) return false;
        return Objects.equals(flushInterval, that.flushInterval);

    }

    @Override
    public int hashCode() {
        int result = nodes != null ? nodes.hashCode() : 0;
        result = 31 * result + (index != null ? index.hashCode() : 0);
        result = 31 * result + (indexFolder != null ? indexFolder.hashCode() : 0);
        result = 31 * result + (username != null ? username.hashCode() : 0);
        result = 31 * result + (pipeline != null ? pipeline.hashCode() : 0);
        result = 31 * result + bulkSize;
        result = 31 * result + (flushInterval != null ? flushInterval.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "Elasticsearch{" + "nodes=" + nodes +
                ", index='" + index + '\'' +
                ", indexFolder='" + indexFolder + '\'' +
                ", bulkSize=" + bulkSize +
                ", flushInterval=" + flushInterval +
                ", byteSize=" + byteSize +
                ", username='" + username + '\'' +
                ", pipeline='" + pipeline + '\'' +
                '}';
    }
}
