# encoding: utf-8
require "rails_helper"

describe "Dashboard APIs"  do
  before(:each) {
	@user = create(:user)
	@user.add_role :admin
  }

  describe "GET product dashboard #show" do

    context "when success" do
      before(:each) do
        @product = create(:product, :with_builds_run_records)
      end

      it "render dashboard product json" do
        auth_get @user, "/api/dashboard/product/#{@product.id}", params: {}, headers: request_headers

        json_data = json_response[:data][:product]

        expect(json_data[:id]).to eql @product.id
        expect(json_data[:name]).to eql @product.name
      end
    end

    context "when error" do
      after do
        expect(json_response[:meta][:code]).not_to eql RESPONSE_CODE[:success]
      end

      it "returns the error when build id is not found" do
        @product = create(:product, :with_builds_run_records)


        auth_get @user, "/api/dashboard/product/1111", params: {}, headers: request_headers

        json_data = json_response[:data]

        expect(json_data.blank?).to eql true
        expect(json_response[:meta][:code]).to eql RESPONSE_CODE[:not_found]
        expect(json_response[:meta][:message]).to eql I18n.t("errors.product.not_found")
      end
    end
  end
  
 # describe "GET build dashboard #show" do

    # context "when success" do
      # before(:each) do
        # @build = create(:build, :with_run_records)
      # end

      # it "render build json" do
        # get "/api/dashboard/build/#{@build.id}", params: {}, headers: request_headers

        # json_data = json_response[:data][:build]

        # expect(json_data[:id]).to eql @build.id
        # expect(json_data[:version]).to eql @build.version
      # end
    # end

    # context "when error" do
      # after do
        # expect(json_response[:meta][:code]).not_to eql RESPONSE_CODE[:success]
      # end

      # it "returns the error when build id is not found" do
        # @build = create :build


        # get "/api/builds/1111", params: {}, headers: request_headers

        # json_data = json_response[:data]

        # expect(json_data.blank?).to eql true
        # expect(json_response[:meta][:code]).to eql RESPONSE_CODE[:not_found]
        # expect(json_response[:meta][:message]).to eql I18n.t("errors.build.not_found")
      # end
    # end
  # end
  
end

