module Montage::Worker

  class Worker
  

	  def work
		begin
		  # log "Running before_start callback..."
		  register_trap_ints        # do it before calling before_start callback!
		  # @callback_handler.before_start
		  @cleaned = false

		  log "Running files ..."
		  @amqp.start_worker @file_queue_name, @reply_exchange_name do |queue, exchange|
			while filename = queue.pop
			  exchange.publish make_start_message(filename)
			  log "Running '#{filename}' with Worker: #{@worker_id}"
			  test_results = nil # needed so run_file() inside the Benchmark will use this
			  runtime = Benchmark.realtime do
				test_results = run_file(filename)
			  end
			  exchange.publish make_finish_message(filename, test_results, runtime)
			end
		  end
		rescue Exception => e
		  clean_up
		  raise e                     # So worker manager can catch it
		end
		clean_up
	  end
	  
 private

	  def clean_up
		return if @cleaned
		log "Running after_complete callback"
		@callback_handler.after_complete
		@cleaned = true
	  end

	  def run_file(filename)
		framework = test_framework(filename).to_s

		require_runner_code_for framework
		runner_class = get_runner_class_for framework

		TestRunner.run_file(filename, runner_class)
	  end

	  def test_framework(filename)
		if filename =~ /_spec.rb$/i && defined?(RSpec)
		  :rspec
		elsif defined?(MiniTest) && !test_unit_gem?
		  :mini_test
		elsif defined?(Test)
		  :test_unit
		else
		  :unknown
		end
	  end

	  # Is the user using test-unit gem?
	  def test_unit_gem?
		gemfile_lock = "./Gemfile.lock"
		@using_test_unit_gem ||= File.exists?(gemfile_lock) &&
		  File.read(gemfile_lock).scan(/\btest-unit/).any?
	  end

	  def make_start_message(filename)
		{action: :start, hostname: Socket.gethostname, worker_id: @worker_id, filename: filename}
	  end

	  def make_finish_message(filename, results, runtime)
		{action: :finish, hostname: Socket.gethostname, worker_id: @worker_id, filename: filename, runtime: runtime}.merge(results)
	  end

	  def require_runner_code_for framework
		ruby_file = framework.to_s + "_runner"
		require_relative ruby_file
	  end

	  def get_runner_class_for framework
		class_name = camelize(framework) + "Runner"
		Kernel.const_get(class_name)
	  end

	  def camelize str
		str.split("_").map(&:capitalize).join
	  end

	  def register_trap_ints
		Signal.trap("INT") { ctrl_c }
		Signal.trap("TERM") { ctrl_c }
	  end

	  def ctrl_c
		clean_up
		exit
	  end
  
  end
 
  
end