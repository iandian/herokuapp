/* 
 * The MIT License
 *
 * Copyright 2017 apex-yu.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package org.recluster.common.inject.spi;

import org.recluster.common.inject.Binder;
import org.recluster.common.inject.MembersInjector;
import org.recluster.common.inject.TypeLiteral;

import java.util.Objects;

/**
 * A lookup of the members injector for a type. Lookups are created explicitly in a module using
 * {@link org.recluster.common.inject.Binder#getMembersInjector(Class) getMembersInjector()} statements:
 * <pre>
 *     MembersInjector&lt;PaymentService&gt; membersInjector
 *         = getMembersInjector(PaymentService.class);</pre>
 *
 * @author crazybob@google.com (Bob Lee)
 * @since 2.0
 */
public final class MembersInjectorLookup<T> implements Element {

    private final Object source;
    private final TypeLiteral<T> type;
    private MembersInjector<T> delegate;

    public MembersInjectorLookup(Object source, TypeLiteral<T> type) {
        this.source = Objects.requireNonNull(source, "source");
        this.type = Objects.requireNonNull(type, "type");
    }

    @Override
    public Object getSource() {
        return source;
    }

    /**
     * Gets the type containing the members to be injected.
     */
    public TypeLiteral<T> getType() {
        return type;
    }

    @Override
    public <T> T acceptVisitor(ElementVisitor<T> visitor) {
        return visitor.visit(this);
    }

    /**
     * Sets the actual members injector.
     *
     * @throws IllegalStateException if the delegate is already set
     */
    public void initializeDelegate(MembersInjector<T> delegate) {
        if (this.delegate != null) {
            throw new IllegalStateException("delegate already initialized");
        }
        this.delegate = Objects.requireNonNull(delegate, "delegate");
    }

    @Override
    public void applyTo(Binder binder) {
        initializeDelegate(binder.withSource(getSource()).getMembersInjector(type));
    }

    /**
     * Returns the delegate members injector, or {@code null} if it has not yet been initialized.
     * The delegate will be initialized when this element is processed, or otherwise used to create
     * an injector.
     */
    public MembersInjector<T> getDelegate() {
        return delegate;
    }

    /**
     * Returns the looked up members injector. The result is not valid until this lookup has been
     * initialized, which usually happens when the injector is created. The members injector will
     * throw an {@code IllegalStateException} if you try to use it beforehand.
     */
    public MembersInjector<T> getMembersInjector() {
        return new MembersInjector<T>() {
            @Override
            public void injectMembers(T instance) {
                if (delegate == null) {
                    throw new IllegalStateException("This MembersInjector cannot be used until the Injector has been created.");
                }
                delegate.injectMembers(instance);
            }

            @Override
            public String toString() {
                return "MembersInjector<" + type + ">";
            }
        };
    }
}