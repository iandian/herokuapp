module V1
  class Users < Grape::API
    include V1Base
    include AuthenticateRequest
    include UserBase

    VALID_PARAMS = %w(name email password password_confirmation)

    helpers do
      def user_params
        params.select{|key,value| VALID_PARAMS.include?(key.to_s)}
      end
    end

    resource :users do

 
      desc 'Get user', headers: HEADERS_DOCS, http_codes: [
        { code: 200, message: 'success' },
        { code: RESPONSE_CODE[:not_found], message: I18n.t('errors.not_found') }
      ]
      params do
        requires :id, type: String, desc: 'User id'
      end
      get ':id' do
        authenticate!
        get_user(params[:id])

        serialization = UserSerializer.new(@user, {show_token: false})
        render_success(serialization.as_json)
      end


      desc 'Get users', headers: HEADERS_DOCS, http_codes: [
        { code: 200, message: 'success' },
        { code: RESPONSE_CODE[:forbidden], message: I18n.t('errors.forbidden') }
      ]
      params do
        optional :page, type: Integer, desc: 'page'
        optional :per_page, type: Integer, desc: 'per_page'
      end
      get do
        authenticate!

        page = (params[:page] || 1).to_i
        per_page = (params[:per_page] || PER_PAGE).to_i 
        users = User.order("created_at DESC").page(page).per(per_page)

        serialization = ActiveModel::Serializer::CollectionSerializer.new(users, each_serializer: UserSerializer, show_token: false)

        render_success({users: serialization.as_json}, pagination_dict(users))
      end
    end
  end
end