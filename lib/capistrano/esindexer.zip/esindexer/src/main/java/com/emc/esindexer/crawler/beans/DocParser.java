package com.emc.esindexer.crawler.beans;

import com.fasterxml.jackson.core.JsonProcessingException;

import java.io.IOException;
import java.util.Map;

import static com.emc.esindexer.crawler.common.MetaParser.prettyMapper;

public class DocParser {

    public static String toJson(Doc doc) throws JsonProcessingException {
        return prettyMapper.writeValueAsString(doc);
    }

    public static Doc fromJson(String json) throws IOException {
        return prettyMapper.readValue(json, Doc.class);
    }

    public static Map asMap(String json) throws IOException {
        return prettyMapper.readValue(json, Map.class);
    }
}
