require 'em-websocket-client'
require 'json'
require "socket"


  class Client
  
	def self.register
		{'type' => "register", 'data' => { 'hostname' => Socket.gethostname,
		'ip' => IPSocket.getaddress(Socket.gethostname), 'version' => '0.0.0.1'}}
	end
  
  end
 

def process_msg conn, req
        case req['type']
        when 'execute'

        when 'ping'
          conn.send_msg({"type" => "ping", "data" => "current time is #{Time.now} with hostname: #{Socket.gethostname}"}.to_json)
        when 'clients'
                  puts "show all clients"
                  p req['data']
          conn.send_msg({"type" => "ack", "data" => ""}.to_json)
        else
                end

end
 

EM.run do
  conn = EventMachine::WebSocketClient.connect("ws://0.0.0.0:9000")

  conn.callback do
    conn.send_msg Client.register.to_json
  end

  conn.errback do |e|
    puts "Got error: #{e}"
  end

  conn.stream do |msg|
    req = JSON.parse(msg.data)
    process_msg conn, req
  end

  conn.disconnect do
    puts "gone"
    EM::stop_event_loop
  end
end


