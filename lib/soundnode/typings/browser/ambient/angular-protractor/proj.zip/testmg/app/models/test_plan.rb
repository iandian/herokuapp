class TestPlan < ApplicationRecord

	has_many :test_units

end