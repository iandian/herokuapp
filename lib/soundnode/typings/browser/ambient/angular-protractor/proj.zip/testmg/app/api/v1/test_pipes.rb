module V1
  class TestPipes < Grape::API
    include V1Base
	include TestPipeBase

    VALID_PARAMS = %w(name build_id)

    helpers do
      def test_pipe_params
        params.select{|key,value| VALID_PARAMS.include?(key.to_s)}
      end
	  
	  
    end
	
    resource :test_pipes do

      desc 'Create new test pipe', http_codes: [
        { code: 200, message: 'success' },
        { code: RESPONSE_CODE[:unprocessable_entity], message: 'Detail error messages' }
      ]
      params do
        requires :name, type: String, desc: 'Test pipe name'
      end
      post :rabl => "test_pipe/show.rabl" do
        create_test_pipe(test_pipe_params)
      end


      desc 'Get test pipe', headers: HEADERS_DOCS, http_codes: [
        { code: 200, message: 'success' },
        { code: RESPONSE_CODE[:not_found], message: I18n.t('errors.not_found') }
      ]
      params do
        requires :id, type: String, desc: 'Test pipe id'
      end
      get ':id', :rabl => "test_pipe/show.rabl" do
	    logger.info "start to get test pipe with id #{params[:id]}"
        get_test_pipe(params[:id])
      end

	  
    end
	
  end
end