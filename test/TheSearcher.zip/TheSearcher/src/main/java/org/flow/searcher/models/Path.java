package org.flow.searcher.models;



/**
 * Represents a Path
 */
public class Path {

    /**
     * Generated json field names
     */
    static public final class FIELD_NAMES {
        public static final String ROOT = "root";
        public static final String VIRTUAL = "virtual";
        public static final String REAL = "real";
    }

    private String root;
    private String virtual;
    private String real;

    public String getRoot() {
        return root;
    }

    public void setRoot(String root) {
        this.root = root;
    }

    public String getVirtual() {
        return virtual;
    }

    public void setVirtual(String virtual) {
        this.virtual = virtual;
    }

    public String getReal() {
        return real;
    }

    public void setReal(String real) {
        this.real = real;
    }
}
