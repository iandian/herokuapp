
package com.emc.esindexer.crawler.filewrapper;


import java.time.LocalDateTime;

public class FileModel {
    public String name;
    public boolean file;
    public boolean directory;
    public LocalDateTime lastModifiedDate;
    public LocalDateTime creationDate;
    public String path;
    public String fullpath;
    public long size;
    public String owner;
    public String group;
    public String extension;

    @Override
    public String toString() {
        String sb = "FileModel{" + "name='" + name + '\'' +
                ", file=" + file +
                ", directory=" + directory +
                ", lastModifiedDate=" + lastModifiedDate +
                ", creationDate=" + creationDate +
                ", path='" + path + '\'' +
                ", owner='" + owner + '\'' +
                ", group='" + group + '\'' +
                ", extension='" + extension + '\'' +
                ", fullpath='" + fullpath + '\'' +
                ", size=" + size +
                '}';
        return sb;
    }
}
