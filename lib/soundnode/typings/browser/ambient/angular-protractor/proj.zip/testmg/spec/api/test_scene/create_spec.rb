# encoding: utf-8
require "rails_helper"

describe "Test Scene APIs"  do
  before(:each) {
    @test_scene_attributes = FactoryGirl.attributes_for :test_scene
	@user = create(:user)
	@user.add_role :admin
  }

  describe "POST #create" do

    context "when is successfully created" do
      after do
        expect(json_response[:meta][:code]).to eql RESPONSE_CODE[:success]
      end

      it "render created build" do
        auth_post @user, "/api/test_scenes", params: @test_scene_attributes.to_json, headers: request_headers

        json_data = json_response[:data][:test_scene]

        expect(json_data[:name]).to eql @test_scene_attributes[:name]
        expect(json_data[:filename]).to eql @test_scene_attributes[:filename]
      end
    end

    context "when has error" do
      it "render unprocessable_entity error when name value is missing" do
        @test_scene_attributes[:name] = ""
        auth_post @user, "/api/test_scenes", params: @test_scene_attributes.to_json, headers: request_headers

        json_data = json_response[:data]

        expect(json_data.blank?).to eql true

        expect(json_response[:meta][:code]).to eql RESPONSE_CODE[:unprocessable_entity]
        expect(json_response[:meta][:message].downcase).to include "name"
      end
    end
  end
end