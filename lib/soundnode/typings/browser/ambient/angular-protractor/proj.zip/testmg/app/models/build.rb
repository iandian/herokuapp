class Build < ApplicationRecord

	belongs_to :product, inverse_of: :builds
	
	has_many :test_scenes, :dependent => :destroy
	
	has_many :run_records, :dependent => :destroy, inverse_of: :build
	
	
end