/* 
 * The MIT License
 *
 * Copyright 2017 apex-yu.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package org.recluster.common.lucene;

import org.apache.lucene.index.IndexCommit;
import org.apache.lucene.store.Directory;

import java.io.IOException;
import java.util.Collection;
import java.util.Map;

/**
 * A simple delegate that delegates all {@link IndexCommit} calls to a delegated
 * {@link IndexCommit}.
 *
 *
 */
public abstract class IndexCommitDelegate extends IndexCommit {

    protected final IndexCommit delegate;

    /**
     * Constructs a new {@link IndexCommit} that will delegate all calls
     * to the provided delegate.
     *
     * @param delegate The delegate
     */
    public IndexCommitDelegate(IndexCommit delegate) {
        this.delegate = delegate;
    }

    @Override
    public String getSegmentsFileName() {
        return delegate.getSegmentsFileName();
    }

    @Override
    public Collection<String> getFileNames() throws IOException {
        return delegate.getFileNames();
    }

    @Override
    public Directory getDirectory() {
        return delegate.getDirectory();
    }

    @Override
    public void delete() {
        delegate.delete();
    }

    @Override
    public boolean isDeleted() {
        return delegate.isDeleted();
    }

    @Override
    public int getSegmentCount() {
        return delegate.getSegmentCount();
    }

    @Override
    public boolean equals(Object other) {
        return delegate.equals(other);
    }

    @Override
    public int hashCode() {
        return delegate.hashCode();
    }

    @Override
    public long getGeneration() {
        return delegate.getGeneration();
    }

    @Override
    public Map<String, String> getUserData() throws IOException {
        return delegate.getUserData();
    }
}
