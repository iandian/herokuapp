module V1
  class TestCases < Grape::API
    include V1Base
	include TestCaseBase

    VALID_PARAMS = %w(testid title description build_id)

    helpers do
      def test_case_params
        params.select{|key,value| VALID_PARAMS.include?(key.to_s)}
      end
	  
	  
    end
	
    resource :test_cases do

      desc 'Create new test case', http_codes: [
        { code: 200, message: 'success' },
        { code: RESPONSE_CODE[:unprocessable_entity], message: 'Detail error messages' }
      ]
      params do
        requires :testid, type: String, desc: 'Test case name'
      end
      post :rabl => "test_case/show.rabl" do
        create_test_case(test_case_params)
      end


      desc 'Get test case', headers: HEADERS_DOCS, http_codes: [
        { code: 200, message: 'success' },
        { code: RESPONSE_CODE[:not_found], message: I18n.t('errors.not_found') }
      ]
      params do
        requires :id, type: String, desc: 'Test case id'
      end
      get ':id', :rabl => "test_case/show.rabl" do
	    logger.info "start to get test case with id #{params[:id]}"
        get_test_case(params[:id])
      end

	  
    end
	
  end
end