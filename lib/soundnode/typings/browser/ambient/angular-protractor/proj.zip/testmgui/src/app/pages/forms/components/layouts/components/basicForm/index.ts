export * from './basicForm.component';
