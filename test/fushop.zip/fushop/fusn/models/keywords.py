# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from django.contrib.auth.models import User
import logging


logger = logging.getLogger(__name__)

#TODO
class Keywords(models.Model):
    keyword = models.CharField(max_length=90)
    is_hot = models.IntegerField()
    is_default = models.IntegerField()
    is_show = models.IntegerField()
    sort_order = models.IntegerField()
    scheme_url = models.CharField(db_column='scheme _url', max_length=255)  # Field renamed to remove unsuitable characters.
    type = models.IntegerField()

    class Meta:
        verbose_name = "Keywords"
        verbose_name_plural = "Keywords"

    def __unicode__(self):
        return '%s %s' % (self.name, self.address)