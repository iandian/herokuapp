# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from decimal import Decimal as D

from django.db import models
from django.db.models import Sum
from django.utils.encoding import smart_text
from django.utils.timezone import now
from django.utils.translation import gettext_lazy as _
from .user import User
from .goods import Goods
from .product import Product
from ..utils.utils import get_default_currency
import logging


logger = logging.getLogger(__name__)

#TODO
class Cart(models.Model):
    user_id = models.IntegerField()
    session_id = models.CharField(max_length=32)
    goods_id = models.IntegerField()
    goods_sn = models.CharField(max_length=60)
    product_id = models.IntegerField()
    goods_name = models.CharField(max_length=120)
    market_price = models.DecimalField(max_digits=10, decimal_places=2)
    retail_price = models.DecimalField(max_digits=10, decimal_places=2)
    number = models.SmallIntegerField()
    goods_specifition_name_value = models.TextField()
    goods_specifition_ids = models.CharField(max_length=60)
    checked = models.IntegerField()
    list_pic_url = models.CharField(max_length=255)

    # Basket statuses
    # - Frozen is for when a basket is in the process of being submitted
    #   and we need to prevent any changes to it.
    OPEN, MERGED, SAVED, FROZEN, SUBMITTED = (
        "Open", "Merged", "Saved", "Frozen", "Submitted")
    STATUS_CHOICES = (
        (OPEN, _("Open - currently active")),
        (MERGED, _("Merged - superceded by another basket")),
        (SAVED, _("Saved - for items to be purchased later")),
        (FROZEN, _("Frozen - the basket cannot be modified")),
        (SUBMITTED, _("Submitted - has been ordered at the checkout")),
    )
    status = models.CharField(
        _("Status"), max_length=128, default=OPEN, choices=STATUS_CHOICES)


    date_created = models.DateTimeField(_("Date created"), auto_now_add=True)
    date_merged = models.DateTimeField(_("Date merged"), null=True, blank=True)
    date_submitted = models.DateTimeField(_("Date submitted"), null=True,
                                          blank=True)


    # Only if a basket is in one of these statuses can it be edited
    editable_statuses = (OPEN, SAVED)

    class Meta:
        verbose_name = "Cart"
        verbose_name_plural = "Cart"

    def __unicode__(self):
        return '%s %s' % (self.name, self.address)


    
class Line(models.Model):
    """A line of a basket (product and a quantity)

    Common approaches on ordering basket lines:

        a) First added at top. That's the history-like approach; new items are
           added to the bottom of the list. Changing quantities doesn't impact
           position.
           Oscar does this by default. It just sorts by Line.pk, which is
           guaranteed to increment after each creation.

        b) Last modified at top. That means items move to the top when you add
           another one, and new items are added to the top as well.  Amazon
           mostly does this, but doesn't change the position when you update
           the quantity in the basket view.
           To get this behaviour, add a date_updated field, change
           Meta.ordering and optionally do something similar on wishlist lines.
           Order lines should already be created in the order of the basket
           lines, and are sorted by their primary key, so no changes should be
           necessary there.

    """
    cart = models.ForeignKey(Cart, related_name='lines', on_delete=models.CASCADE)
    # This is to determine which products belong to the same line
    # We can't just use product.id as you can have customised products
    # which should be treated as separate lines.  Set as a
    # SlugField as it is included in the path for certain views.
    line_reference = SlugField(
        _("Line Reference"), max_length=128, db_index=True)
    product = models.ForeignKey(Product, related_name='lines', on_delete=models.CASCADE)

    # We store the stockrecord that should be used to fulfil this line.
    stockrecord = models.ForeignKey(
        'partner.StockRecord',
        on_delete=models.CASCADE,
        related_name='basket_lines')

    quantity = models.PositiveIntegerField(_('Quantity'), default=1)
    
    # We store the unit price incl tax of the product when it is first added to
    # the basket.  This allows us to tell if a product has changed price since
    # a person first added it to their basket.
    price_currency = models.CharField(
        _("Currency"), max_length=12, default=get_default_currency)
    price_excl_tax = models.DecimalField(
        _('Price excl. Tax'), decimal_places=2, max_digits=12,
        null=True)
    price_incl_tax = models.DecimalField(
        _('Price incl. Tax'), decimal_places=2, max_digits=12, null=True)
        
    # Track date of first addition
    date_created = models.DateTimeField(_("Date Created"), auto_now_add=True)
    

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Instance variables used to persist discount information
        self._discount_excl_tax = D('0.00')
        self._discount_incl_tax = D('0.00')

    class Meta:
        # Enforce sorting by order of creation.
        ordering = ['date_created', 'pk']
        unique_together = ("cart", "line_reference")


    def __str__(self):
        return _(
            "Cart #%(cart_id)d, Product #%(product_id)d, quantity"
            " %(quantity)d") % {'cart_id': self.cart.pk,
                                'product_id': self.product.pk,
                                'quantity': self.quantity}

                                
class LineAttribute(models.Model):
    """
    An attribute of a cart line
    """
    line = models.ForeignKey(
        Line,
        on_delete=models.CASCADE,
        related_name='attributes',
        verbose_name=_("Line"))
    option = models.ForeignKey(
        'catalogue.Option',
        on_delete=models.CASCADE,
        verbose_name=_("Option"))
    value = models.CharField(_("Value"), max_length=255)

    class Meta:
        verbose_name = _('Line attribute')
        verbose_name_plural = _('Line attributes')