FactoryGirl.define do

  factory :test_plan do
    sequence(:name){|n|"test_plan_#{n}"}
  end
end