# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from django.contrib.auth.models import User
import logging


logger = logging.getLogger(__name__)

class Province(models.Model):
    code = models.CharField(max_length=255, primary_key=True, db_index=True)
    name = models.CharField(max_length=255, db_index=True)

    class Meta:
        verbose_name = "Province"
        verbose_name_plural = "Province"

    def __unicode__(self):
        return '%s %s' % (self.name, self.code)