# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from django.contrib.auth.models import User
import logging


logger = logging.getLogger(__name__)

#TODO
class Goods(models.Model):
    category_id = models.IntegerField()
    goods_sn = models.CharField(max_length=60)
    name = models.CharField(max_length=120)
    brand_id = models.IntegerField()
    goods_number = models.IntegerField()
    keywords = models.CharField(max_length=255)
    goods_brief = models.CharField(max_length=255)
    goods_desc = models.TextField(blank=True, null=True)
    is_on_sale = models.IntegerField()
    add_time = models.IntegerField()
    sort_order = models.SmallIntegerField()
    is_delete = models.IntegerField()
    attribute_category = models.IntegerField()
    counter_price = models.DecimalField(max_digits=10, decimal_places=2)
    extra_price = models.DecimalField(max_digits=10, decimal_places=2)
    is_new = models.IntegerField()
    goods_unit = models.CharField(max_length=45)
    primary_pic_url = models.CharField(max_length=255)
    list_pic_url = models.CharField(max_length=255)
    retail_price = models.DecimalField(max_digits=10, decimal_places=2)
    sell_volume = models.IntegerField()
    primary_product_id = models.IntegerField()
    unit_price = models.DecimalField(max_digits=10, decimal_places=2)
    promotion_desc = models.CharField(max_length=255)
    promotion_tag = models.CharField(max_length=45)
    app_exclusive_price = models.DecimalField(max_digits=10, decimal_places=2)
    is_app_exclusive = models.IntegerField()
    is_limited = models.IntegerField()
    is_hot = models.IntegerField()

    class Meta:
        verbose_name = "Address"
        verbose_name_plural = "Address"

    def __unicode__(self):
        return '%s %s' % (self.name, self.address)