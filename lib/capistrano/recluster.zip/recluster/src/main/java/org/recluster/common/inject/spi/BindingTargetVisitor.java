/* 
 * The MIT License
 *
 * Copyright 2017 apex-yu.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package org.recluster.common.inject.spi;

/**
 * Visits each of the strategies used to find an instance to satisfy an injection.
 *
 * @param <V> any type to be returned by the visit method. Use {@link Void} with
 *            {@code return null} if no return type is needed.
 * @since 2.0
 */
public interface BindingTargetVisitor<T, V> {

    /**
     * Visit a instance binding. The same instance is returned for every injection. This target is
     * found in both module and injector bindings.
     */
    V visit(InstanceBinding<? extends T> binding);

    /**
     * Visit a provider instance binding. The provider's {@code get} method is invoked to resolve
     * injections. This target is found in both module and injector bindings.
     */
    V visit(ProviderInstanceBinding<? extends T> binding);

    /**
     * Visit a provider key binding. To resolve injections, the provider key is first resolved, then
     * that provider's {@code get} method is invoked. This target is found in both module and injector
     * bindings.
     */
    V visit(ProviderKeyBinding<? extends T> binding);

    /**
     * Visit a linked key binding. The other key's binding is used to resolve injections. This
     * target is found in both module and injector bindings.
     */
    V visit(LinkedKeyBinding<? extends T> binding);

    /**
     * Visit a binding to a key exposed from an enclosed private environment. This target is only
     * found in injector bindings.
     */
    V visit(ExposedBinding<? extends T> binding);

    /**
     * Visit an untargetted binding. This target is found only on module bindings. It indicates
     * that the injector should use its implicit binding strategies to resolve injections.
     */
    V visit(UntargettedBinding<? extends T> binding);

    /**
     * Visit a constructor binding. To resolve injections, an instance is instantiated by invoking
     * {@code constructor}. This target is found only on injector bindings.
     */
    V visit(ConstructorBinding<? extends T> binding);

    /**
     * Visit a binding created from converting a bound instance to a new type. The source binding
     * has the same binding annotation but a different type. This target is found only on injector
     * bindings.
     */
    V visit(ConvertedConstantBinding<? extends T> binding);

    /**
     * Visit a binding to a {@link org.recluster.common.inject.Provider} that delegates to the binding for the
     * provided type. This target is found only on injector bindings.
     */
    V visit(ProviderBinding<? extends T> binding);
}
