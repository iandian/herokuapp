class TestCase < ApplicationRecord

	has_many :test_unit_test_cases
	
	has_many :test_units, through: :test_unit_test_cases

end