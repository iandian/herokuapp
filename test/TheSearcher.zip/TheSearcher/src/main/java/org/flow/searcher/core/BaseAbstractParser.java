package org.flow.searcher.core;


import java.util.concurrent.atomic.AtomicInteger;

public abstract class BaseAbstractParser implements Runnable {
    static final Object semaphore = new Object();
    final AtomicInteger runNumber = new AtomicInteger(0);
    boolean closed;

    void close() {
        this.closed = true;
    }

    public boolean isClosed() {
        return closed;
    }

    Object getSemaphore() {
        return semaphore;
    }

    public int getRunNumber() {
        return runNumber.get();
    }
}
