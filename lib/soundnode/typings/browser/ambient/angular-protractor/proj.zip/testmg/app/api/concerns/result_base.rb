module ResultBase
  extend ActiveSupport::Concern

  included do

    helpers do
      def get_result(id)
        @result = Result.find(id)

        unless @result
          raise ApiException.new(
            http_status: RESPONSE_CODE[:not_found], 
            code: RESPONSE_CODE[:not_found], 
            message: I18n.t('errors.result.not_found')
          )
        end
      end
	  
      def create_result(params)
        @result = Result.new(params)

        unless @result.save
          raise ApiException.new(
            http_status: RESPONSE_CODE[:not_found], 
            code: RESPONSE_CODE[:not_found], 
            message: I18n.t('errors.result.not_found')
          )
        end
      end

    end
  end
end