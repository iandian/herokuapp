module AuthHelper
  module Controller
    def sign_in(user)
      @request.env["devise.mapping"] = Devise.mappings[:merchant]

      @request.headers.merge! user.create_new_auth_token
      sign_in user
    end
  end

  module Request
    %i(get post put patch delete).each do |http_method|
      # auth_get, auth_post, auth_put, auth_patch, auth_delete
      define_method("auth_#{http_method}") do |user, action_name, params: {}, headers: {}|
        auth_headers = user.create_new_auth_token
        headers = headers.merge(auth_headers)
        public_send(http_method, action_name, params: params, headers: headers)
      end
    end
  end
  
  # https://github.com/lynndylanhurley/devise_token_auth/issues/521
  # https://github.com/lynndylanhurley/devise_token_auth/issues/75 
  # Controller test usage:
  
	# describe SomeController, type: :controller do
	  # let(:user) { create(:user) }
	  # subject { post :create, params: params }
	  # before { sign_in user }

	  # ...
	# end
	
  # Request spec usage: 
	
	# describe SomeRequest, type: :request do
	  # let(:user) { create(:user) }
	  # subject { auth_post user, '/api/some_endpoint', params: params }

	  # ...
	# end	
  
end