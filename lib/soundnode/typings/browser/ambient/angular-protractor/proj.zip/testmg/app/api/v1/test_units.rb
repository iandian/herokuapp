module V1
  class TestUnits < Grape::API
    include V1Base
	include TestUnitBase

    VALID_PARAMS = %w(name build_id)

    helpers do
      def test_unit_params
        params.select{|key,value| VALID_PARAMS.include?(key.to_s)}
      end
	  
	  
    end
	
    resource :test_units do

      desc 'Create new test unit', http_codes: [
        { code: 200, message: 'success' },
        { code: RESPONSE_CODE[:unprocessable_entity], message: 'Detail error messages' }
      ]
      params do
        requires :name, type: String, desc: 'Test unit name'
      end
      post :rabl => "test_unit/show.rabl" do
        create_test_unit(test_unit_params)
      end


      desc 'Get test unit', headers: HEADERS_DOCS, http_codes: [
        { code: 200, message: 'success' },
        { code: RESPONSE_CODE[:not_found], message: I18n.t('errors.not_found') }
      ]
      params do
        requires :id, type: String, desc: 'Test unit id'
      end
      get ':id', :rabl => "test_unit/show.rabl" do
	    logger.info "start to get test unit with id #{params[:id]}"
        get_test_unit(params[:id])
      end

	  
    end
	
  end
end