export * from './baSlimScroll.directive';
