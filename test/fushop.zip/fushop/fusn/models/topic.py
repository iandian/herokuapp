# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from django.contrib.auth.models import User
import logging


logger = logging.getLogger(__name__)

#TODO
class Topic(models.Model):
    id = models.AutoField()
    title = models.CharField(max_length=255)
    content = models.TextField(blank=True, null=True)
    avatar = models.CharField(max_length=255)
    item_pic_url = models.CharField(max_length=255)
    subtitle = models.CharField(max_length=255)
    topic_category_id = models.IntegerField()
    price_info = models.DecimalField(max_digits=10, decimal_places=2)
    read_count = models.CharField(max_length=255)
    scene_pic_url = models.CharField(max_length=255)
    topic_template_id = models.IntegerField()
    topic_tag_id = models.IntegerField()
    sort_order = models.IntegerField()
    is_show = models.IntegerField()

    class Meta:
        verbose_name = "Address"
        verbose_name_plural = "Address"

    def __unicode__(self):
        return '%s %s' % (self.name, self.address)