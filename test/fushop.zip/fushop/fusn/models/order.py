# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from django.contrib.auth.models import User
import logging


logger = logging.getLogger(__name__)

#TODO
class Order(models.Model):
    order_sn = models.CharField(unique=True, max_length=20)
    user_id = models.IntegerField()
    order_status = models.IntegerField()
    shipping_status = models.IntegerField()
    pay_status = models.IntegerField()
    consignee = models.CharField(max_length=60)
    country = models.SmallIntegerField()
    province = models.SmallIntegerField()
    city = models.SmallIntegerField()
    district = models.SmallIntegerField()
    address = models.CharField(max_length=255)
    mobile = models.CharField(max_length=60)
    postscript = models.CharField(max_length=255)
    shipping_fee = models.DecimalField(max_digits=10, decimal_places=2)
    pay_name = models.CharField(max_length=120)
    pay_id = models.IntegerField()
    actual_price = models.DecimalField(max_digits=10, decimal_places=2)
    integral = models.IntegerField()
    integral_money = models.DecimalField(max_digits=10, decimal_places=2)
    order_price = models.DecimalField(max_digits=10, decimal_places=2)
    goods_price = models.DecimalField(max_digits=10, decimal_places=2)
    add_time = models.IntegerField()
    confirm_time = models.IntegerField()
    pay_time = models.IntegerField()
    freight_price = models.IntegerField()
    coupon_id = models.IntegerField()
    parent_id = models.IntegerField()
    coupon_price = models.DecimalField(max_digits=10, decimal_places=2)
    callback_status = models.CharField(max_length=5, blank=True, null=True)

    class Meta:
        verbose_name = "Address"
        verbose_name_plural = "Address"

    def __unicode__(self):
        return '%s %s' % (self.name, self.address)