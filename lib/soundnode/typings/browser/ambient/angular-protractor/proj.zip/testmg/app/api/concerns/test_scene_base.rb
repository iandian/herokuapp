module TestSceneBase
  extend ActiveSupport::Concern

  included do

    helpers do
      def get_test_scene(id)
        @test_scene = TestScene.find(id)

        unless @test_scene
          raise ApiException.new(
            http_status: RESPONSE_CODE[:not_found], 
            code: RESPONSE_CODE[:not_found], 
            message: I18n.t('errors.test_scene.not_found')
          )
        end
      end
	  
      def create_test_scene(params)
        @test_scene = TestScene.new(params)
		authorize @test_scene, :create?
        unless @test_scene.save
          raise ApiException.new(
            http_status: RESPONSE_CODE[:not_found], 
            code: RESPONSE_CODE[:not_found], 
            message: I18n.t('errors.test_scene.not_found')
          )
        end
      end

    end
  end
end