module V1
  class Builds < Grape::API
    include V1Base
	include BuildBase

    VALID_PARAMS = %w(version product_id)

    helpers do
      def build_params
        params.select{|key,value| VALID_PARAMS.include?(key.to_s)}
      end
	  
	  
      def load_product
        Product.find(params[:product_id])
      end
	  
    end
	
    resource :builds do

      desc 'Create new build', http_codes: [
        { code: 200, message: 'success' },
        { code: RESPONSE_CODE[:unprocessable_entity], message: 'Detail error messages' }
      ]
      params do
        requires :version, type: String, desc: 'Build version'
      end
      post :rabl => "build/show.rabl" do
        create_build(build_params)
      end


      desc 'Get build', headers: HEADERS_DOCS, http_codes: [
        { code: 200, message: 'success' },
        { code: RESPONSE_CODE[:not_found], message: I18n.t('errors.not_found') }
      ]
      params do
        requires :id, type: String, desc: 'Build id'
      end
      get ':id', :rabl => "build/show.rabl" do
	    logger.info "start to get build with id #{params[:id]}"
        get_build(params[:id])
      end

	  
    end
	
  end
end