import {Component} from '@angular/core';

@Component({
  selector: 'inputs',
  templateUrl: './inputs.html',
})
export class Inputs {

  constructor() {
  }
}
