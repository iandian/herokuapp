class Polygon

   @test = {}
   def self.aaa
     @test['a'] = 1
     @test['b'] = 2
   end

   def self.bbb
                if instance_variable_get("@channel").nil?
                        instance_variable_set("@channel",{"channel"=> "aaa","queue"=>"bbb"})
						@test["channel"] = instance_variable_get("@channel")
						instance_variable_set("@other",{"momo" => "gg"})
                end
   end
   
   def self.remove
       channel = @test.delete("channel")
       instance_variables.each do |var|
                cha = instance_variable_get var
                if cha.equal?(channel)
                   remove_instance_variable(var.to_sym)
                end
        end
       # remove_instance_variable(:@channel)
   end



end

# require_relative './test.rb'
# Polygon.bbb
# Polygon.remove

# Polygon.instance_variable_get("@channel")
# Polygon.instance_variable_get("@test")
# Polygon.instance_variable_get("@other")