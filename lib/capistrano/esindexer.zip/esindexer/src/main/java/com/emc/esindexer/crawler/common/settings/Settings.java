
package com.emc.esindexer.crawler.common.settings;

@SuppressWarnings("SameParameterValue")
public class Settings {

    private String name;
    private EsSettings esSettings;
    private Server server;
    private Elasticsearch elasticsearch;
    private Rest rest;

    public Settings() {

    }

    private Settings(String name, EsSettings esSettings, Server server, Elasticsearch elasticsearch, Rest rest) {
        this.name = name;
        this.esSettings = esSettings;
        this.server = server;
        this.elasticsearch = elasticsearch;
        this.rest = rest;
    }

    public static Builder builder(String name) {
        return new Builder().setName(name);
    }

    public static class Builder {
        private String name;
        private EsSettings esSettings = EsSettings.DEFAULT;
        private Server server = null;
        private Elasticsearch elasticsearch = Elasticsearch.DEFAULT();
        private Rest rest = Rest.DEFAULT;

        private Builder setName(String name) {
            this.name = name;
            return this;
        }

        public Builder setEsSettings(EsSettings esSettings) {
            this.esSettings = esSettings;
            return this;
        }

        public Builder setServer(Server server) {
            this.server = server;
            return this;
        }

        public Builder setElasticsearch(Elasticsearch elasticsearch) {
            this.elasticsearch = elasticsearch;
            return this;
        }

        public Builder setRest(Rest rest) {
            this.rest = rest;
            return this;
        }

        public Settings build() {
            return new Settings(name, esSettings, server, elasticsearch, rest);
        }
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public EsSettings getEsSettings() {
        return esSettings;
    }

    public void setEsSettings(EsSettings esSettings) {
        this.esSettings = esSettings;
    }

    public Server getServer() {
        return server;
    }

    public void setServer(Server server) {
        this.server = server;
    }

    public Elasticsearch getElasticsearch() {
        return elasticsearch;
    }

    public void setElasticsearch(Elasticsearch elasticsearch) {
        this.elasticsearch = elasticsearch;
    }

    public Rest getRest() {
        return rest;
    }

    public void setRest(Rest rest) {
        this.rest = rest;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Settings that = (Settings) o;

        if (name != null ? !name.equals(that.name) : that.name != null) return false;
        if (esSettings != null ? !esSettings.equals(that.esSettings) : that.esSettings != null) return false;
        if (server != null ? !server.equals(that.server) : that.server != null) return false;
        if (rest != null ? !rest.equals(that.rest) : that.rest != null) return false;
        return !(elasticsearch != null ? !elasticsearch.equals(that.elasticsearch) : that.elasticsearch != null);

    }

    @Override
    public int hashCode() {
        int result = name != null ? name.hashCode() : 0;
        result = 31 * result + (esSettings != null ? esSettings.hashCode() : 0);
        result = 31 * result + (server != null ? server.hashCode() : 0);
        result = 31 * result + (rest != null ? rest.hashCode() : 0);
        result = 31 * result + (elasticsearch != null ? elasticsearch.hashCode() : 0);
        return result;
    }
}
