
package com.emc.esindexer.crawler.common.settings;

import com.emc.esindexer.crawler.common.utils.CommonUtil;
import com.emc.esindexer.crawler.common.utils.OsValidator;
import org.apache.logging.log4j.Logger;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import static com.emc.esindexer.crawler.common.utils.CommonUtil.INDEX_SUFFIX_FOLDER;

public class CrawlerValidator {

    /**
     * Check if settings are valid. Note that settings can be updated by this method (fallback to defaults if not set)
     * @param logger    Needed to print warn/errors or info
     * @param settings  Settings we want to check
     * @param rest      true If Rest server should be started, so we check Rest settings
     * @return true if we found fatal errors and should prevent from starting
     */
    public static boolean validateSettings(Logger logger, Settings settings, boolean rest) {
        if (settings.getEsSettings() == null || settings.getEsSettings().getUrl() == null) {
            logger.warn("`url` is not set. Please define it. Falling back to default: [{}].", EsSettings.DEFAULT_DIR);
            if (settings.getEsSettings() == null) {
                settings.setEsSettings(EsSettings.DEFAULT);
            } else {
                settings.getEsSettings().setUrl(EsSettings.DEFAULT_DIR);
            }
        }

        if (settings.getElasticsearch() == null) {
            settings.setElasticsearch(Elasticsearch.DEFAULT());
        }
        if (settings.getElasticsearch().getIndex() == null) {
            // When index is not set, we fallback to the config name
            settings.getElasticsearch().setIndex(settings.getName());
        }
        if (settings.getElasticsearch().getIndexFolder() == null) {
            // When index for folders is not set, we fallback to the config name + _folder
            settings.getElasticsearch().setIndexFolder(settings.getName() + INDEX_SUFFIX_FOLDER);
        }

        // Checking protocol
        if (settings.getServer() != null) {
            if (!Server.PROTOCOL.LOCAL.equals(settings.getServer().getProtocol()) &&
                    !Server.PROTOCOL.SSH.equals(settings.getServer().getProtocol())) {
                // Non supported protocol
                logger.error(settings.getServer().getProtocol() + " is not supported yet. Please use " +
                        Server.PROTOCOL.LOCAL + " or " + Server.PROTOCOL.SSH + ". Disabling crawler");
                return true;
            }

            // Checking username/password
            if (Server.PROTOCOL.SSH.equals(settings.getServer().getProtocol()) &&
                    CommonUtil.isNullOrEmpty(settings.getServer().getUsername())) {
                // Non supported protocol
                logger.error("When using SSH, you need to set a username and probably a password or a pem file. Disabling crawler");
                return true;
            }
        }

        // Checking Checksum Algorithm
        if (settings.getEsSettings().getChecksum() != null) {
            try {
                MessageDigest.getInstance(settings.getEsSettings().getChecksum());
            } catch (NoSuchAlgorithmException e) {
                // Non supported protocol
                logger.error("Algorithm [{}] not found. Disabling crawler", settings.getEsSettings().getChecksum());
                return true;
            }
        }

        // Checking That we don't try to do both xml and json
        if (settings.getEsSettings().isJsonSupport() && settings.getEsSettings().isXmlSupport()) {
            logger.error("Can not support both xml and json parsing. Disabling crawler");
            return true;
        }

        // Checking That we don't try to have xml or json but we don't want to index their content
        if ((settings.getEsSettings().isJsonSupport() || settings.getEsSettings().isXmlSupport()) && !settings.getEsSettings().isIndexContent()) {
            logger.error("Json or Xml indexation is activated but you disabled indexing content which does not make sense. Disabling crawler");
            return true;
        }

        // We just warn the user if he is running on windows but want to get attributes
        if (OsValidator.windows && settings.getEsSettings().isAttributesSupport()) {
            logger.info("attributes_support is set to true but getting group is not available on [{}].", OsValidator.OS);
        }

        // Check that REST settings are available when we start with rest option
        if (rest && settings.getRest() == null) {
            logger.warn("`rest` settings are not defined. Falling back to default: [{}].", Rest.DEFAULT.url());
            settings.setRest(Rest.DEFAULT);
        }

        return false;
    }
}
