class TestPipe < ApplicationRecord

	belongs_to :test_scene
	
	has_many :test_units, :dependent => :destroy

end