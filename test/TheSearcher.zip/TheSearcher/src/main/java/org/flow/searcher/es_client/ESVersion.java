package org.flow.searcher.es_client;


public class ESVersion implements Comparable<ESVersion> {
    public final int id;
    public final byte major;
    public final byte minor;
    public final byte revision;
    public final byte build;

    /**
     * Returns the version given its string representation, current version if the argument is null or empty
     */
    public static ESVersion fromString(String version) {
        String lVersion = version;
        final boolean snapshot = lVersion.endsWith("-SNAPSHOT");
        if (snapshot) {
            lVersion = lVersion.substring(0, lVersion.length() - 9);
        }
        String[] parts = lVersion.split("[.-]");
        if (parts.length < 3 || parts.length > 4) {
            throw new IllegalArgumentException(
                    "the lVersion needs to contain major, minor, and revision, and optionally the build: " + lVersion);
        }

        try {
            final int rawMajor = Integer.parseInt(parts[0]);
            if (rawMajor >= 5 && snapshot) { // we don't support snapshot as part of the lVersion here anymore
                throw new IllegalArgumentException("illegal lVersion format - snapshots are only supported until lVersion 2.x");
            }
            final int betaOffset = rawMajor < 5 ? 0 : 25;
            //we reverse the lVersion id calculation based on some assumption as we can't reliably reverse the modulo
            final int major = rawMajor * 1000000;
            final int minor = Integer.parseInt(parts[1]) * 10000;
            final int revision = Integer.parseInt(parts[2]) * 100;


            int build = 99;
            if (parts.length == 4) {
                String buildStr = parts[3];
                if (buildStr.startsWith("alpha")) {
                    assert rawMajor >= 5 : "major must be >= 5 but was " + major;
                    build = Integer.parseInt(buildStr.substring(5));
                    assert build < 25 : "expected a beta build but " + build + " >= 25";
                } else if (buildStr.startsWith("Beta") || buildStr.startsWith("beta")) {
                    build = betaOffset + Integer.parseInt(buildStr.substring(4));
                    assert build < 50 : "expected a beta build but " + build + " >= 50";
                } else if (buildStr.startsWith("RC") || buildStr.startsWith("rc")) {
                    build = Integer.parseInt(buildStr.substring(2)) + 50;
                } else {
                    throw new IllegalArgumentException("unable to parse lVersion " + lVersion);
                }
            }

            return new ESVersion(major + minor + revision + build);

        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("unable to parse lVersion " + lVersion, e);
        }
    }

    ESVersion(int id) {
        this.id = id;
        this.major = (byte) ((id / 1000000) % 100);
        this.minor = (byte) ((id / 10000) % 100);
        this.revision = (byte) ((id / 100) % 100);
        this.build = (byte) (id % 100);
    }

    public boolean after(ESVersion version) {
        return version.id < id;
    }

    public boolean onOrAfter(ESVersion version) {
        return version.id <= id;
    }

    public boolean before(ESVersion version) {
        return version.id > id;
    }

    public boolean onOrBefore(ESVersion version) {
        return version.id >= id;
    }

    @Override
    public int compareTo(ESVersion other) {
        return Integer.compare(this.id, other.id);
    }

    @Override
    public String toString() {
        return String.valueOf(major) + '.' + minor + '.' + revision;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        ESVersion version = (ESVersion) o;

        return id == version.id;
    }

    @Override
    public int hashCode() {
        return id;
    }
}

