
package com.emc.esindexer.crawler.filewrapper;

import com.emc.esindexer.crawler.common.settings.Settings;
import com.emc.esindexer.crawler.common.settings.Server;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;

import java.io.InputStream;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Vector;
import java.util.stream.Collectors;

public class FileWrapperSSH extends FileWrapper<ChannelSftp.LsEntry> {

    private ChannelSftp sftp;

    public FileWrapperSSH(Settings settings) {
        super(settings);
    }

    @Override
    public FileModel toFileAbstractModel(String path, ChannelSftp.LsEntry file) {
        FileModel model = new FileModel();
        model.name = file.getFilename();
        model.directory = file.getAttrs().isDir();
        model.file = !model.directory;
        // We are using here the local TimeZone as a reference. If the remote system is under another TZ, this might cause issues
        model.lastModifiedDate = LocalDateTime.ofInstant(Instant.ofEpochMilli(file.getAttrs().getMTime()*1000L), ZoneId.systemDefault());
        model.path = path;
        model.fullpath = model.path.concat("/").concat(model.name);
        model.size = file.getAttrs().getSize();
        model.owner = Integer.toString(file.getAttrs().getUId());
        model.group = Integer.toString(file.getAttrs().getGId());
        return model;
    }

    @Override
    public InputStream getInputStream(FileModel file) throws Exception {
        return sftp.get(file.fullpath);
    }

    @SuppressWarnings("unchecked")
    @Override
    public Collection<FileModel> getFiles(String dir) throws Exception {
        logger.debug("Listing local files from {}", dir);
        Vector<ChannelSftp.LsEntry> ls;

        ls = sftp.ls(dir);
        if (ls == null) return null;

        Collection<FileModel> result = new ArrayList<>(ls.size());
        // Iterate other files
        // We ignore here all files like . and ..
        result.addAll(ls.stream().filter(file -> !".".equals(file.getFilename()) &&
                !"..".equals(file.getFilename()))
                .map(file -> toFileAbstractModel(dir, file))
                .collect(Collectors.toList()));

        logger.debug("{} local files found", result.size());
        return result;
    }

    @Override
    public boolean exists(String dir) {
        try {
            sftp.ls(dir);
        } catch (Exception e) {
            return false;
        }
        return true;
    }

    @Override
    public void open() throws Exception {
        sftp = openSSHConnection(settings.getServer());
    }

    @Override
    public void close() throws Exception {
        sftp.getSession().disconnect();
        sftp.disconnect();
    }

    private ChannelSftp openSSHConnection(Server server) throws Exception {
        logger.debug("Opening SSH connection to {}@{}", server.getUsername(), server.getHostname());

        JSch jsch = new JSch();
        Session session = jsch.getSession(server.getUsername(), server.getHostname(), server.getPort());
        java.util.Properties config = new java.util.Properties();
        config.put("StrictHostKeyChecking", "no");
        if (server.getPemPath() != null) {
            jsch.addIdentity(server.getPemPath());
        }
        session.setConfig(config);
        if (server.getPassword() != null) {
            session.setPassword(server.getPassword());
        }
        session.connect();

        //Open a new session for SFTP.
        Channel channel = session.openChannel("sftp");
        channel.connect();

        //checking SSH client connection.
        if (!channel.isConnected()) {
            logger.warn("Cannot connect with SSH to {}@{}", server.getUsername(),
                    server.getHostname());
            throw new RuntimeException("Can not connect to " + server.getUsername() + "@" + server.getHostname());
        }
        logger.debug("SSH connection successful");
        return (ChannelSftp) channel;
    }
}
