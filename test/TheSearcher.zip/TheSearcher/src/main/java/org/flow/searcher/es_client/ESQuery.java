package org.flow.searcher.es_client;


public abstract class ESQuery {
    private final String field;

    ESQuery(String field) {
        this.field = field;
    }

    public String getField() {
        return field;
    }
}

