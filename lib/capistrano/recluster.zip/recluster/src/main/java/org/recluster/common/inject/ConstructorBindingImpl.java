/* 
 * The MIT License
 *
 * Copyright 2017 apex-yu.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package org.recluster.common.inject;

import org.recluster.common.inject.internal.BindingImpl;
import org.recluster.common.inject.internal.Errors;
import org.recluster.common.inject.internal.ErrorsException;
import org.recluster.common.inject.internal.InternalContext;
import org.recluster.common.inject.internal.InternalFactory;
import org.recluster.common.inject.internal.Scoping;
import org.recluster.common.inject.internal.ToStringBuilder;
import org.recluster.common.inject.spi.BindingTargetVisitor;
import org.recluster.common.inject.spi.ConstructorBinding;
import org.recluster.common.inject.spi.Dependency;
import org.recluster.common.inject.spi.InjectionPoint;

import java.util.HashSet;
import java.util.Set;

class ConstructorBindingImpl<T> extends BindingImpl<T> implements ConstructorBinding<T> {

    private final Factory<T> factory;

    private ConstructorBindingImpl(Injector injector, Key<T> key, Object source,
                                   InternalFactory<? extends T> scopedFactory, Scoping scoping, Factory<T> factory) {
        super(injector, key, source, scopedFactory, scoping);
        this.factory = factory;
    }

    static <T> ConstructorBindingImpl<T> create(
            InjectorImpl injector, Key<T> key, Object source, Scoping scoping) {
        Factory<T> factoryFactory = new Factory<>();
        InternalFactory<? extends T> scopedFactory
                = Scopes.scope(key, injector, factoryFactory, scoping);
        return new ConstructorBindingImpl<>(
                injector, key, source, scopedFactory, scoping, factoryFactory);
    }

    public void initialize(InjectorImpl injector, Errors errors) throws ErrorsException {
        factory.constructorInjector = injector.constructors.get(getKey().getTypeLiteral(), errors);
    }

    @Override
    public <V> V acceptTargetVisitor(BindingTargetVisitor<? super T, V> visitor) {
        if (factory.constructorInjector == null) {
            throw new IllegalStateException("not initialized");
        }
        return visitor.visit(this);
    }

    @Override
    public InjectionPoint getConstructor() {
        if (factory.constructorInjector == null) {
            throw new IllegalStateException("Binding is not ready");
        }
        return factory.constructorInjector.getConstructionProxy().getInjectionPoint();
    }

    @Override
    public Set<InjectionPoint> getInjectableMembers() {
        if (factory.constructorInjector == null) {
            throw new IllegalStateException("Binding is not ready");
        }
        return factory.constructorInjector.getInjectableMembers();
    }

    @Override
    public Set<Dependency<?>> getDependencies() {
        Set<InjectionPoint> dependencies = new HashSet<>();
        dependencies.add(getConstructor());
        dependencies.addAll(getInjectableMembers());
        return Dependency.forInjectionPoints(dependencies);
    }

    @Override
    public void applyTo(Binder binder) {
        throw new UnsupportedOperationException("This element represents a synthetic binding.");
    }

    @Override
    public String toString() {
        return new ToStringBuilder(ConstructorBinding.class)
                .add("key", getKey())
                .add("source", getSource())
                .add("scope", getScoping())
                .toString();
    }

    private static class Factory<T> implements InternalFactory<T> {
        private ConstructorInjector<T> constructorInjector;

        @Override
        @SuppressWarnings("unchecked")
        public T get(Errors errors, InternalContext context, Dependency<?> dependency)
                throws ErrorsException {
            if (constructorInjector == null) {
                throw new IllegalStateException("Constructor not ready");
            }

            // This may not actually be safe because it could return a super type of T (if that's all the
            // client needs), but it should be OK in practice thanks to the wonders of erasure.
            return (T) constructorInjector.construct(errors, context, dependency.getKey().getRawType());
        }
    }
}
