# encoding: utf-8
require "rails_helper"

describe "Products APIs"  do
  
  before(:each) {
    @products = create_list :product, 30
  }

  describe "GET #index" do

    context "when success get all" do

      it "render array" do
        get "/api/products", params: {}, headers: request_headers

        json_data = json_response[:data]

        expect(json_data[:products].length).to eql 20
		expect(json_data[:count]).to eql 20
		expect(json_data[:current_page]).to eql 1
		expect(json_data[:pages]).to eql 2

      end

      it "render the products json in page = 1 & per_page = 10" do
        sleep 2

        get "/api/products", params: {page: 1, per_page: 10}, headers: request_headers

        json_data = json_response[:data]

        expect(json_data[:products].length).to eql 10
		expect(json_data[:count]).to eql 10
		expect(json_data[:current_page]).to eql 1
		expect(json_data[:pages]).to eql 3
      end


      it "render the products json in page = 3 & per_page = 10" do
        sleep 2

        get "/api/products", params: {page: 3, per_page: 10}, headers: request_headers

        json_data = json_response[:data]

        expect(json_data[:products].length).to eql 10
		expect(json_data[:count]).to eql 10
		expect(json_data[:current_page]).to eql 3
		expect(json_data[:pages]).to eql 3
      end

	end
  end
end