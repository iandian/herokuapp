export * from './condensedTable.component';
