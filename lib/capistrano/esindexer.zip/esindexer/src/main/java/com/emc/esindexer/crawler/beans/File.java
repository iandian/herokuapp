package com.emc.esindexer.crawler.beans;

import java.util.Date;

/**
 * Represents File attributes
 */
public class File {

    /**
     * Generated json field names
     */
    static public final class FIELD_NAMES {
        public static final String EXTENSION = "extension";
        public static final String CONTENT_TYPE = "content_type";
        public static final String LAST_MODIFIED = "last_modified";
        public static final String INDEXING_DATE = "indexing_date";
        public static final String FILESIZE = "filesize";
        public static final String FILENAME = "filename";
        public static final String URL = "url";
        public static final String INDEXED_CHARS = "indexed_chars";
        public static final String CHECKSUM = "checksum";
    }

    private String extension;
    private String contentType;
    private Date lastModified;
    private Date indexingDate;
    private Long filesize;
    private String filename;
    private String url;
    private Integer indexedChars;
    private String checksum;

    public String getExtension() {
        return extension;
    }

    public void setExtension(String extension) {
        this.extension = extension;
    }

    public String getContentType() {
        return contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    public Date getLastModified() {
        return lastModified;
    }

    public void setLastModified(Date lastModified) {
        this.lastModified = lastModified;
    }

    public Date getIndexingDate() {
        return indexingDate;
    }

    public void setIndexingDate(Date indexingDate) {
        this.indexingDate = indexingDate;
    }

    public Long getFilesize() {
        return filesize;
    }

    public void setFilesize(Long filesize) {
        this.filesize = filesize;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Integer getIndexedChars() {
        return indexedChars;
    }

    public void setIndexedChars(Integer indexedChars) {
        this.indexedChars = indexedChars;
    }

    public void setChecksum(String checksum) {
        this.checksum = checksum;
    }

    public String getChecksum() {
        return checksum;
    }
}
