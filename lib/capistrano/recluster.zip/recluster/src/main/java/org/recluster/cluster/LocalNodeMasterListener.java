/* 
 * The MIT License
 *
 * Copyright 2017 apex-yu.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package org.recluster.cluster;

/**
 * Enables listening to master changes events of the local node (when the local node becomes the master, and when the local
 * node cease being a master).
 */
public interface LocalNodeMasterListener {

    /**
     * Called when local node is elected to be the master
     */
    void onMaster();

    /**
     * Called when the local node used to be the master, a new master was elected and it's no longer the local node.
     */
    void offMaster();

    /**
     * The name of the executor that the implementation of the callbacks of this lister should be executed on. The thread
     * that is responsible for managing instances of this lister is the same thread handling the cluster state events. If
     * the work done is the callbacks above is inexpensive, this value may be {@link org.recluster.threadpool.ThreadPool.Names#SAME SAME}
     * (indicating that the callbacks will run on the same thread as the cluster state events are fired with). On the other hand,
     * if the logic in the callbacks are heavier and take longer to process (or perhaps involve blocking due to IO operations),
     * prefer to execute them on a separate more appropriate executor (eg. {@link org.recluster.threadpool.ThreadPool.Names#GENERIC GENERIC}
     * or {@link org.recluster.threadpool.ThreadPool.Names#MANAGEMENT MANAGEMENT}).
     *
     * @return The name of the executor that will run the callbacks of this listener.
     */
    String executorName();

}

