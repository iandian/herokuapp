FactoryGirl.define do

  factory :test_unit do
    test_pipe
    sequence(:name){|n|"test_unit_#{n}"}
  end
end