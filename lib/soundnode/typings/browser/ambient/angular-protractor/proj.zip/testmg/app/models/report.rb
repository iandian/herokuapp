class Report < ApplicationRecord

	belongs_to :run_record

end