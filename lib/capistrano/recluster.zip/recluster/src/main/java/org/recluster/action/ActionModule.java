/*
 * Licensed to Recluster under one or more contributor
 * license agreements. See the NOTICE file distributed with
 * this work for additional information regarding copyright
 * ownership. Recluster licenses this file to you under
 * the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.recluster.action;

import org.apache.logging.log4j.Logger;
import org.recluster.action.admin.cluster.node.hotthreads.NodesHotThreadsAction;
import org.recluster.action.admin.cluster.node.hotthreads.TransportNodesHotThreadsAction;
import org.recluster.action.admin.cluster.node.info.NodesInfoAction;
import org.recluster.action.admin.cluster.node.info.TransportNodesInfoAction;
import org.recluster.action.admin.cluster.node.liveness.TransportLivenessAction;
import org.recluster.action.admin.cluster.node.stats.NodesStatsAction;
import org.recluster.action.admin.cluster.node.stats.TransportNodesStatsAction;
import org.recluster.action.admin.cluster.node.tasks.cancel.CancelTasksAction;
import org.recluster.action.admin.cluster.node.tasks.cancel.TransportCancelTasksAction;
import org.recluster.action.admin.cluster.node.tasks.list.ListTasksAction;
import org.recluster.action.admin.cluster.node.tasks.list.TransportListTasksAction;
import org.recluster.action.admin.cluster.state.ClusterStateAction;
import org.recluster.action.admin.cluster.state.TransportClusterStateAction;
import org.recluster.action.support.ActionFilters;
import org.recluster.action.support.DestructiveOperations;
import org.recluster.action.support.TransportAction;
import org.recluster.client.node.NodeClient;
import org.recluster.cluster.metadata.IndexNameExpressionResolver;
import org.recluster.cluster.node.DiscoveryNodes;
import org.recluster.common.NamedRegistry;
import org.recluster.common.inject.AbstractModule;
import org.recluster.common.inject.multibindings.MapBinder;
import org.recluster.common.logging.ESLoggerFactory;
import org.recluster.common.settings.ClusterSettings;
import org.recluster.common.settings.Settings;
import org.recluster.common.settings.SettingsFilter;
import org.recluster.rest.RestHandler;

import org.recluster.threadpool.ThreadPool;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Consumer;
import java.util.function.Supplier;
import java.util.function.UnaryOperator;
import java.util.stream.Collectors;

import static java.util.Collections.unmodifiableMap;

/**
 * Builds and binds the generic action map, all {@link TransportAction}s, and {@link ActionFilters}.
 */
public class ActionModule extends AbstractModule {

    private static final Logger logger = ESLoggerFactory.getLogger(ActionModule.class);

    private final boolean transportClient;
    private final Settings settings;
    private final IndexNameExpressionResolver indexNameExpressionResolver;
    private final ClusterSettings clusterSettings;
    private final SettingsFilter settingsFilter;
    private final Map<String, ActionHandler<?, ?>> actions;
    private final DestructiveOperations destructiveOperations;
    private final RestController restController;

    public ActionModule(boolean transportClient, Settings settings, IndexNameExpressionResolver indexNameExpressionResolver,
                        ClusterSettings clusterSettings, SettingsFilter settingsFilter,
                        ThreadPool threadPool, NodeClient nodeClient) {
        this.transportClient = transportClient;
        this.settings = settings;
        this.indexNameExpressionResolver = indexNameExpressionResolver;
        this.clusterSettings = clusterSettings;
        this.settingsFilter = settingsFilter;
        actions = setupActions();
        destructiveOperations = new DestructiveOperations(settings, clusterSettings);
        UnaryOperator<RestHandler> restWrapper = null;
        if (transportClient) {
            restController = null;
        } else {
            restController = new RestController(settings, headers, restWrapper, nodeClient);
        }
    }


    public Map<String, ActionHandler<?, ?>> getActions() {
        return actions;
    }

    static Map<String, ActionHandler<?, ?>> setupActions() {
        // Subclass NamedRegistry for easy registration
        class ActionRegistry extends NamedRegistry<ActionHandler<?, ?>> {
            ActionRegistry() {
                super("action");
            }

            public void register(ActionHandler<?, ?> handler) {
                register(handler.getAction().name(), handler);
            }

            public <Request extends ActionRequest, Response extends ActionResponse> void register(
                    GenericAction<Request, Response> action, Class<? extends TransportAction<Request, Response>> transportAction,
                    Class<?>... supportTransportActions) {
                register(new ActionHandler<>(action, transportAction, supportTransportActions));
            }
        }
        ActionRegistry actions = new ActionRegistry();

        actions.register(NodesInfoAction.INSTANCE, TransportNodesInfoAction.class);
        actions.register(NodesStatsAction.INSTANCE, TransportNodesStatsAction.class);
        actions.register(NodesUsageAction.INSTANCE, TransportNodesUsageAction.class);
        actions.register(NodesHotThreadsAction.INSTANCE, TransportNodesHotThreadsAction.class);
        actions.register(ListTasksAction.INSTANCE, TransportListTasksAction.class);
        actions.register(GetTaskAction.INSTANCE, TransportGetTaskAction.class);
        actions.register(CancelTasksAction.INSTANCE, TransportCancelTasksAction.class);

        actions.register(ClusterStateAction.INSTANCE, TransportClusterStateAction.class);


        return unmodifiableMap(actions.getRegistry());
    }


    public void initRestHandlers(Supplier<DiscoveryNodes> nodesInCluster) {
 
    }

    @Override
    protected void configure() {
        bind(DestructiveOperations.class).toInstance(destructiveOperations);

        if (false == transportClient) {
            // Supporting classes only used when not a transport client
            bind(TransportLivenessAction.class).asEagerSingleton();

            // register GenericAction -> transportAction Map used by NodeClient
            @SuppressWarnings("rawtypes")
            MapBinder<GenericAction, TransportAction> transportActionsBinder
                    = MapBinder.newMapBinder(binder(), GenericAction.class, TransportAction.class);
            for (ActionHandler<?, ?> action : actions.values()) {
                // bind the action as eager singleton, so the map binder one will reuse it
                bind(action.getTransportAction()).asEagerSingleton();
                transportActionsBinder.addBinding(action.getAction()).to(action.getTransportAction()).asEagerSingleton();
                for (Class<?> supportAction : action.getSupportTransportActions()) {
                    bind(supportAction).asEagerSingleton();
                }
            }
        }
    }


    public RestController getRestController() {
        return restController;
    }
}
