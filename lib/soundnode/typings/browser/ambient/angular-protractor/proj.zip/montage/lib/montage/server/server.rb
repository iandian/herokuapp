require 'em-websocket'
require 'json'
require 'montage/redis_connection'

module Montage::Server

  class Server
  
    @individual_channels = {}
  
	def self.register ws, client_id
		@individual_channels[ws.object_id]=set_client_channel(ws, client_id)
	end
	
	def self.set_client_channel ws, client_id
		create_client_channel(client_id)
		subscribe_client_channel(ws, client_id)
		get_client_channel(client_id)
	end
	
	def self.create_client_channel(param1)
		if instance_variable_get("@channel_#{param1}").nil?
			instance_variable_set("@channel_#{param1}",{"channel"=> EM::Channel.new,"queue"=>EM::Queue.new})
		end
	end
	
	def self.subscribe_client_channel(ws, param1)
		get_client_channel(param1)["channel"].subscribe{ |msg| ws.send msg}
	end
	
	def self.get_client_channel(param1)
		if instance_variable_get("@channel_#{param1}").nil?
			puts "Please Ensure Channel Is Present"
			# set_user_channel(param1,ws)
			return nil
		end
		instance_variable_get("@channel_#{param1}")
	end
	
	def self.send_to_all(message)
		puts "sending to all: #{message}"
		@individual_channels.each do |_, channel|
			channel["channel"].push(message.to_json)
	    end
    end
	
	def self.terminate_execute
		send_to_all({'type' = 'terminate', 'data' = {}})
	end
  
  end


# EM.run {
  EM::WebSocket.start(:host => "0.0.0.0", :port => 9000) do |ws|
    ws.onopen { |handshake|
      puts "WebSocket connection open"

      # Access properties on the EM::WebSocket::Handshake object, e.g.
      # path, query_string, origin, headers

      # Publish message to the client
      # ws.send "Hello Client, you connected to #{handshake.path}"
    }

    ws.onclose { puts "Connection closed" }

    ws.onmessage { |msg|
      req = JSON.parse(msg)
      process_msg ws, req
    }
  end
# }


def process_msg ws, req
        case req['type']
        when 'register'
          data = req['data']
		  Server.register ws, data['ip']
		  save_a_client data
        when 'result'
        
        when 'complete'
        
        when 'error'
        
        when 'info'
        
        else
		
		end

end



  def self.redis_pool
    @redis ||= Montage::RedisConnection.create
  end
  
    private

    def save_a_client(payloads)
	  payloads['status'] = "online"
      redis_pool.with do |conn|
        conn.mapped_hmset payloads['name'], payloads.except('name')
		conn.sadd 'clients', payloads['name']
      end
    end
