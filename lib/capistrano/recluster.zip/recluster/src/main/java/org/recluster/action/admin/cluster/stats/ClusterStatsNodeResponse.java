/* 
 * The MIT License
 *
 * Copyright 2017 apex-yu.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package org.recluster.action.admin.cluster.stats;

import org.recluster.action.admin.cluster.node.info.NodeInfo;
import org.recluster.action.admin.cluster.node.stats.NodeStats;
//import org.recluster.action.admin.indices.stats.ShardStats;
import org.recluster.action.support.nodes.BaseNodeResponse;
import org.recluster.cluster.health.ClusterHealthStatus;
import org.recluster.cluster.node.DiscoveryNode;
import org.recluster.common.Nullable;
import org.recluster.common.io.stream.StreamInput;
import org.recluster.common.io.stream.StreamOutput;

import java.io.IOException;

public class ClusterStatsNodeResponse extends BaseNodeResponse {

    private NodeInfo nodeInfo;
    private NodeStats nodeStats;
//    private ShardStats[] shardsStats;
    private ClusterHealthStatus clusterStatus;

    ClusterStatsNodeResponse() {
    }

    public ClusterStatsNodeResponse(DiscoveryNode node, @Nullable ClusterHealthStatus clusterStatus, NodeInfo nodeInfo, NodeStats nodeStats) {
        super(node);
        this.nodeInfo = nodeInfo;
        this.nodeStats = nodeStats;
        this.clusterStatus = clusterStatus;
    }

    public NodeInfo nodeInfo() {
        return this.nodeInfo;
    }

    public NodeStats nodeStats() {
        return this.nodeStats;
    }

    /**
     * Cluster Health Status, only populated on master nodes.
     */
    @Nullable
    public ClusterHealthStatus clusterStatus() {
        return clusterStatus;
    }

    public static ClusterStatsNodeResponse readNodeResponse(StreamInput in) throws IOException {
        ClusterStatsNodeResponse nodeResponse = new ClusterStatsNodeResponse();
        nodeResponse.readFrom(in);
        return nodeResponse;
    }

    @Override
    public void readFrom(StreamInput in) throws IOException {
        super.readFrom(in);
        clusterStatus = null;
        if (in.readBoolean()) {
            clusterStatus = ClusterHealthStatus.fromValue(in.readByte());
        }
        this.nodeInfo = NodeInfo.readNodeInfo(in);
        this.nodeStats = NodeStats.readNodeStats(in);
        int size = in.readVInt();
    }

    @Override
    public void writeTo(StreamOutput out) throws IOException {
        super.writeTo(out);
        if (clusterStatus == null) {
            out.writeBoolean(false);
        } else {
            out.writeBoolean(true);
            out.writeByte(clusterStatus.value());
        }
        nodeInfo.writeTo(out);
        nodeStats.writeTo(out);
    }
}
