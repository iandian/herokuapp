
package com.emc.esindexer.crawler.filewrapper;

import com.emc.esindexer.crawler.common.settings.Settings;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.InputStream;
import java.util.Collection;

public abstract class FileWrapper<T> {
    protected static final Logger logger = LogManager.getLogger(FileWrapper.class);

    protected final Settings settings;

    public abstract FileModel toFileAbstractModel(String path, T file);

    public abstract InputStream getInputStream(FileModel file) throws Exception;

    public abstract Collection<FileModel> getFiles(String dir) throws Exception;

    public abstract boolean exists(String dir);

    public abstract void open() throws Exception;

    public abstract void close() throws Exception;

    protected FileWrapper(Settings settings) {
        this.settings = settings;
    }
}
