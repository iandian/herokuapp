/* 
 * The MIT License
 *
 * Copyright 2017 apex-yu.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package org.recluster.common.inject.internal;

import java.util.concurrent.ConcurrentHashMap;

/**
 * Lazily creates (and caches) values for keys. If creating the value fails (with errors), an
 * exception is thrown on retrieval.
 *
 * @author jessewilson@google.com (Jesse Wilson)
 */
public abstract class FailableCache<K, V> {

    private final ConcurrentHashMap<K, Object> cache = new ConcurrentHashMap<>();

    protected abstract V create(K key, Errors errors) throws ErrorsException;

    public V get(K key, Errors errors) throws ErrorsException {
        Object resultOrError = cache.get(key);
        if (resultOrError == null) {
            synchronized (this) {
                resultOrError = load(key);
                // we can't use cache.computeIfAbsent since this might be recursively call this API
                cache.putIfAbsent(key, resultOrError);
            }
        }
        if (resultOrError instanceof Errors) {
            errors.merge((Errors) resultOrError);
            throw errors.toException();
        } else {
            @SuppressWarnings("unchecked") // create returned a non-error result, so this is safe
            V result = (V) resultOrError;
            return result;
        }
    }


    private Object load(K key) {
        Errors errors = new Errors();
        V result = null;
        try {
            result = create(key, errors);
        } catch (ErrorsException e) {
            errors.merge(e.getErrors());
        }
        return errors.hasErrors() ? errors : result;
    }
}
