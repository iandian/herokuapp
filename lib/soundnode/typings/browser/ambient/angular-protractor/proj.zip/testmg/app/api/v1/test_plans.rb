module V1
  class TestPlans < Grape::API
    include V1Base
	include TestPlanBase

    VALID_PARAMS = %w(name build_id)

    helpers do
      def test_plan_params
        params.select{|key,value| VALID_PARAMS.include?(key.to_s)}
      end
	  
	  
    end
	
    resource :test_plans do

      desc 'Create new test plan', http_codes: [
        { code: 200, message: 'success' },
        { code: RESPONSE_CODE[:unprocessable_entity], message: 'Detail error messages' }
      ]
      params do
        requires :name, type: String, desc: 'Test plan name'
      end
      post :rabl => "test_plan/show.rabl" do
        create_test_plan(test_plan_params)
      end


      desc 'Get test plan', headers: HEADERS_DOCS, http_codes: [
        { code: 200, message: 'success' },
        { code: RESPONSE_CODE[:not_found], message: I18n.t('errors.not_found') }
      ]
      params do
        requires :id, type: String, desc: 'Test plan id'
      end
      get ':id', :rabl => "test_plan/show.rabl" do
	    logger.info "start to get test plan with id #{params[:id]}"
        get_test_plan(params[:id])
      end

	  
    end
	
  end
end