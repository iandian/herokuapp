///* 
// * The MIT License
// *
// * Copyright 2017 apex-yu.
// *
// * Permission is hereby granted, free of charge, to any person obtaining a copy
// * of this software and associated documentation files (the "Software"), to deal
// * in the Software without restriction, including without limitation the rights
// * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// * copies of the Software, and to permit persons to whom the Software is
// * furnished to do so, subject to the following conditions:
// *
// * The above copyright notice and this permission notice shall be included in
// * all copies or substantial portions of the Software.
// *
// * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// * THE SOFTWARE.
// */
//package org.recluster.common.settings;
//
//import java.io.BufferedReader;
//import java.io.InputStream;
//import java.io.InputStreamReader;
//import java.nio.charset.StandardCharsets;
//import java.util.Arrays;
//
//import joptsimple.OptionSet;
//import joptsimple.OptionSpec;
//import org.recluster.cli.EnvironmentAwareCommand;
//import org.recluster.cli.ExitCodes;
//import org.recluster.cli.Terminal;
//import org.recluster.cli.UserException;
//import org.recluster.env.Environment;
//
///**
// * A subcommand for the keystore cli which adds a string setting.
// */
//class AddStringKeyStoreCommand extends EnvironmentAwareCommand {
//
//    private final OptionSpec<Void> stdinOption;
//    private final OptionSpec<Void> forceOption;
//    private final OptionSpec<String> arguments;
//
//    AddStringKeyStoreCommand() {
//        super("Add a string setting to the keystore");
//        this.stdinOption = parser.acceptsAll(Arrays.asList("x", "stdin"), "Read setting value from stdin");
//        this.forceOption = parser.acceptsAll(Arrays.asList("f", "force"), "Overwrite existing setting without prompting");
//        this.arguments = parser.nonOptions("setting name");
//    }
//
//    // pkg private so tests can manipulate
//    InputStream getStdin() {
//        return System.in;
//    }
//
//    @Override
//    protected void execute(Terminal terminal, OptionSet options, Environment env) throws Exception {
//        KeyStoreWrapper keystore = KeyStoreWrapper.load(env.configFile());
//        if (keystore == null) {
//            if (options.has(forceOption) == false &&
//                terminal.promptYesNo("The recluster keystore does not exist. Do you want to create it?", false) == false) {
//                terminal.println("Exiting without creating keystore.");
//                return;
//            }
//            keystore = KeyStoreWrapper.create(new char[0] /* always use empty passphrase for auto created keystore */);
//            keystore.save(env.configFile());
//            terminal.println("Created recluster keystore in " + env.configFile());
//        } else {
//            keystore.decrypt(new char[0] /* TODO: prompt for password when they are supported */);
//        }
//
//        String setting = arguments.value(options);
//        if (setting == null) {
//            throw new UserException(ExitCodes.USAGE, "The setting name can not be null");
//        }
//        if (keystore.getSettingNames().contains(setting) && options.has(forceOption) == false) {
//            if (terminal.promptYesNo("Setting " + setting + " already exists. Overwrite?", false) == false) {
//                terminal.println("Exiting without modifying keystore.");
//                return;
//            }
//        }
//
//        final char[] value;
//        if (options.has(stdinOption)) {
//            BufferedReader stdinReader = new BufferedReader(new InputStreamReader(getStdin(), StandardCharsets.UTF_8));
//            value = stdinReader.readLine().toCharArray();
//        } else {
//            value = terminal.readSecret("Enter value for " + setting + ": ");
//        }
//
//        try {
//            keystore.setString(setting, value);
//        } catch (IllegalArgumentException e) {
//            throw new UserException(ExitCodes.DATA_ERROR, "String value must contain only ASCII");
//        }
//        keystore.save(env.configFile());
//    }
//}
