class TestScene < ApplicationRecord

	belongs_to :build
	
	has_many :test_pipes, :dependent => :destroy

end