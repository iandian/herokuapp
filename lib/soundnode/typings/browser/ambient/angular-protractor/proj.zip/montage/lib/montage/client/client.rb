require 'em-websocket-client'
require 'json'

EM.run do
  conn = EventMachine::WebSocketClient.connect("ws://0.0.0.0:9000")

  conn.callback do
    conn.send_msg "Hello!"
  end

  conn.errback do |e|
    puts "Got error: #{e}"
  end

  conn.stream do |msg|
    req = JSON.parse(msg)
    process_msg conn, req
  end

  conn.disconnect do
    puts "gone"
    EM::stop_event_loop
  end
end

def process_msg conn, req
        case req['type']
        when 'execute'
        
        when 'ping'
        
        else
		
		end

end
