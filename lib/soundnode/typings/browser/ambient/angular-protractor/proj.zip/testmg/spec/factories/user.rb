FactoryGirl.define do

  factory :user do
    sequence(:email){|n|"user#{n}@domain.com"}
	sequence(:nickname){|n|"user#{n}"}
    password "secret"
    trait :admin do
      after(:create) do |user|
        user.roles << FactoryGirl.create(:admin)
      end
    end
  end

end
