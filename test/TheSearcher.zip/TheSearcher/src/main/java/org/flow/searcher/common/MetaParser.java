package org.flow.searcher.common;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.Version;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

/**
 * Helper to parse from and to Json
 */
public class MetaParser {

    public static final ObjectMapper prettyMapper;
    public static final ObjectMapper mapper;
    public static final ObjectMapper ymlMapper;

    static {
        SimpleModule fscrawler = new SimpleModule("FsCrawler", new Version(2, 0, 0, null,
                "fr.pilato.elasticsearch.crawler", "fscrawler"));
        fscrawler.addSerializer(new TimeValueSerializer());
        fscrawler.addDeserializer(TimeValue.class, new TimeValueDeserializer());
        fscrawler.addSerializer(new PercentageSerializer());
        fscrawler.addDeserializer(Percentage.class, new PercentageDeserializer());
        fscrawler.addSerializer(new ByteSizeValueSerializer());
        fscrawler.addDeserializer(ByteSizeValue.class, new ByteSizeValueDeserializer());

        mapper = new ObjectMapper();
        mapper.registerModule(new JavaTimeModule());
        mapper.registerModule(fscrawler);
        mapper.setPropertyNamingStrategy(PropertyNamingStrategy.SNAKE_CASE);
        mapper.configure(SerializationFeature.WRITE_DATE_TIMESTAMPS_AS_NANOSECONDS, false);
        mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        mapper.configure(DeserializationFeature.READ_DATE_TIMESTAMPS_AS_NANOSECONDS, false);
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        mapper.setSerializationInclusion(JsonInclude.Include.NON_EMPTY);

        prettyMapper = new ObjectMapper();
        prettyMapper.registerModule(new JavaTimeModule());
        prettyMapper.registerModule(fscrawler);
        prettyMapper.configure(SerializationFeature.INDENT_OUTPUT, true);
        prettyMapper.setPropertyNamingStrategy(PropertyNamingStrategy.SNAKE_CASE);
        prettyMapper.configure(SerializationFeature.WRITE_DATE_TIMESTAMPS_AS_NANOSECONDS, false);
        prettyMapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        prettyMapper.configure(DeserializationFeature.READ_DATE_TIMESTAMPS_AS_NANOSECONDS, false);
        prettyMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        prettyMapper.setSerializationInclusion(JsonInclude.Include.NON_EMPTY);

        YAMLFactory yamlFactory = new YAMLFactory();
        ymlMapper = new ObjectMapper(yamlFactory);
        ymlMapper.registerModule(new JavaTimeModule());
        ymlMapper.registerModule(fscrawler);
        ymlMapper.configure(SerializationFeature.INDENT_OUTPUT, true);
        ymlMapper.setPropertyNamingStrategy(PropertyNamingStrategy.SNAKE_CASE);
        ymlMapper.configure(SerializationFeature.WRITE_DATE_TIMESTAMPS_AS_NANOSECONDS, false);
        ymlMapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        ymlMapper.configure(DeserializationFeature.READ_DATE_TIMESTAMPS_AS_NANOSECONDS, false);
        ymlMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        ymlMapper.setSerializationInclusion(JsonInclude.Include.NON_EMPTY);
    }

}

