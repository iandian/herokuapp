# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from django.contrib.auth.models import User
import logging
from .city import City
from .province import Province
from .area import Area
from .street import Street


logger = logging.getLogger(__name__)


class Village(models.Model):
    code = models.CharField(max_length=255, primary_key=True, db_index=True)
    name = models.CharField(max_length=255, db_index=True)
    street = models.ForeignKey(
        Street, related_name='village', on_delete=models.CASCADE, db_column="streetCode")
    area = models.ForeignKey(
        Area, related_name='village', on_delete=models.CASCADE, db_column="areaCode")
    city = models.ForeignKey(
        City, related_name='village', on_delete=models.CASCADE, db_column="cityCode")
    provice = models.ForeignKey(
        Province, related_name='village', on_delete=models.CASCADE, db_column="provinceCode")


    class Meta:
        verbose_name = "Village"
        verbose_name_plural = "Village"

    def __unicode__(self):
        return '%s %s' % (self.name, self.code)