/* 
 * The MIT License
 *
 * Copyright 2017 apex-yu.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.emc.esindexer.logging;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.spi.ExtendedLogger;

/**
 * Factory to get {@link Logger}s
 */
public final class LoggerFactory {

    private LoggerFactory() {

    }

    public static final Level LOG_DEFAULT_LEVEL_SETTING = Level.TRACE;

    public static Logger getLogger(String prefix, String name) {
        return getLogger(prefix, LogManager.getLogger(name));
    }

    public static Logger getLogger(String prefix, Class<?> clazz) {
        /*
         * Do not use LogManager#getLogger(Class) as this now uses Class#getCanonicalName under the hood; as this returns null for local and
         * anonymous classes, any place we create, for example, an abstract component defined as an anonymous class (e.g., in tests) will
         * result in a logger with a null name which will blow up in a lookup inside of Log4j.
         */
        return getLogger(prefix, LogManager.getLogger(clazz.getName()));
    }

    public static Logger getLogger(String prefix, Logger logger) {
        return new PrefixLogger((ExtendedLogger)logger, logger.getName(), prefix);
    }

    public static Logger getLogger(Class<?> clazz) {
        return getLogger(null, clazz);
    }

    public static Logger getLogger(String name) {
        return getLogger(null, name);
    }

    public static Logger getRootLogger() {
        return LogManager.getRootLogger();
    }

}
