FactoryGirl.define do

  factory :test_case do
    sequence(:testid){|n|(1000 + n).to_s}
    sequence(:title){|n|"test_case_title_#{n}"}
    sequence(:description){|n|"test_case_description_#{n}"}
	after(:create) do |tcase|
      tcase.test_units << FactoryGirl.create(:test_unit)
    end
  end
end