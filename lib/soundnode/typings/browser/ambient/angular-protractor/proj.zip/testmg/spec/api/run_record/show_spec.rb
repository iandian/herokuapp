# encoding: utf-8
require "rails_helper"

describe "Run record APIs"  do
  before(:each) {
  }

  describe "GET #show" do

    context "when success" do
      before(:each) do
        @run_record = create :run_record
      end

      it "render run_record json" do
        get "/api/run_records/#{@run_record.id}", params: {}, headers: request_headers

        json_data = json_response[:data][:run_record]

        expect(json_data[:id]).to eql @run_record.id
        expect(json_data[:name]).to eql @run_record.name
      end
    end

    context "when error" do
      after do
        expect(json_response[:meta][:code]).not_to eql RESPONSE_CODE[:success]
      end

      it "returns the error when run record id is not found" do
        @run_record = create :run_record


        get "/api/run_records/1111", params: {}, headers: request_headers

        json_data = json_response[:data]

        expect(json_data.blank?).to eql true
        expect(json_response[:meta][:code]).to eql RESPONSE_CODE[:not_found]
        expect(json_response[:meta][:message]).to eql I18n.t("errors.runrecord.not_found")
      end
    end
  end
end

