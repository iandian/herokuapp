cart   order    coupon     payment     shiping     withdrew     

address     user     


footprint      feedback       wishlist


need to change app_label to app name and remote abstract flag when to generate db tables, or will not regonize

