# encoding: utf-8
require "rails_helper"

describe "test user model"  do

  describe "#create" do
    it "ldap query" do
	  email = Devise::LDAP::Adapter.get_ldap_param('administrator',"mail").first
	  puts email
          # uid = Devise::LDAP::Adapter.get_ldap_param('administrator',"sAMAccountName").first
          # p uid

          resource = Devise::LDAP::Adapter.ldap_connect('administrator').search_for_login
          p resource

    end
  end
  
end
	  
	  