class CreateTestCases < ActiveRecord::Migration[5.0]
  def change
    create_table :test_cases do |t|
      t.string :testid
      t.string :title
      t.string :description
    end
	
    create_table :test_unit_test_cases do |t|
      t.belongs_to :test_unit
      t.belongs_to :test_case
	  t.timestamps
    end
	
  end
end
