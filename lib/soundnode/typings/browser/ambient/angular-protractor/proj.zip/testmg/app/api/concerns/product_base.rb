module ProductBase
  extend ActiveSupport::Concern

  included do

    helpers do
      def get_product(id)
        @product = Product.find(id)

        unless @product
          raise ApiException.new(
            http_status: RESPONSE_CODE[:not_found], 
            code: RESPONSE_CODE[:not_found], 
            message: I18n.t('errors.product.not_found')
          )
        end
      end
	  
	  
      def get_all_product
        page = (params[:page] || 1).to_i
        per_page = (params[:per_page] || PER_PAGE).to_i 
        @products = Product.all.page(page).per(per_page)

        unless @products
          raise ApiException.new(
            http_status: RESPONSE_CODE[:not_found], 
            code: RESPONSE_CODE[:not_found], 
            message: I18n.t('errors.products.not_found')
          )
        end
      end
	  
	  
      def create_product(params)
        @product = Product.new(params)
        authorize @product, :create?
        unless @product.save
          raise ApiException.new(
            http_status: RESPONSE_CODE[:not_found], 
            code: RESPONSE_CODE[:not_found], 
            message: I18n.t('errors.product.not_found')
          )
        end
      end

    end
  end
end