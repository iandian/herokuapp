package org.flow.searcher.common;


import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;

import java.io.IOException;

/**
 * Jackson Deserializer for Percentage object
 */
public class PercentageDeserializer extends StdDeserializer<Percentage> {
    public PercentageDeserializer() {
        super(Percentage.class);
    }

    @Override
    public Percentage deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
        return Percentage.parse(p.getText());
    }
}

