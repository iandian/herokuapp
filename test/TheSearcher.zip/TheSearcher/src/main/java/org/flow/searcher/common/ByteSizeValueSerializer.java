package org.flow.searcher.common;


import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;

import java.io.IOException;

/**
 * Jackson Serializer for ByteSizeValue object
 */
public class ByteSizeValueSerializer extends StdSerializer<ByteSizeValue> {
    public ByteSizeValueSerializer() {
        super(ByteSizeValue.class);
    }

    @Override
    public void serialize(ByteSizeValue value, JsonGenerator gen, SerializerProvider provider) throws IOException {
        gen.writeString(value.toString());
    }
}
