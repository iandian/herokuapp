package com.emc.esindexer.crawler.common;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;

import java.io.IOException;

/**
 * Jackson Serializer for TimeValue object
 */
public class TimeValueSerializer extends StdSerializer<TimeValue> {
    public TimeValueSerializer() {
        super(TimeValue.class);
    }

    @Override
    public void serialize(TimeValue value, JsonGenerator gen, SerializerProvider provider) throws IOException {
        gen.writeString(value.toString());
    }
}
