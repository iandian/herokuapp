# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from attribute_category import AttributeCategory
import logging


logger = logging.getLogger(__name__)

class Attribute(models.Model):
    attribute_category = models.ForeignKey(
        AttributeCategory, related_name='attributes', on_delete=models.CASCADE)
    name = models.CharField(max_length=60)
    input_type = models.IntegerField()
    values = models.TextField()
    sort_order = models.IntegerField()


    class Meta:
        verbose_name = "Attribute"
        verbose_name_plural = "Attribute"

    def __unicode__(self):
        return '%s %s' % (self.name, self.values)