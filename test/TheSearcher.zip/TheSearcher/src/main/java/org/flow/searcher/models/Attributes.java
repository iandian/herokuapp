package org.flow.searcher.models;


/**
 * Represents additional file attributes.
 */
public class Attributes {

    /**
     * Generated json field names
     */
    static public final class FIELD_NAMES {
        public static final String OWNER = "owner";
        public static final String GROUP = "group";
        public static final String PERMISSIONS = "permissions";
    }

    private String owner;
    private String group;
    private int permissions;

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public String getGroup() {
        return group;
    }

    public void setGroup(String group) {
        this.group = group;
    }

    public int getPermissions() {
        return permissions;
    }

    public void setPermissions(int permissions) {
        this.permissions = permissions;
    }
}