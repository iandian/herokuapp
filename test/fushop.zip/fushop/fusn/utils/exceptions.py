# -*- coding: utf-8 -*-


class ModuleNotFoundError(Exception):
    pass


class AppNotFoundError(Exception):
    pass


class ClassNotFoundError(Exception):
    pass

class InvalidStockAdjustment(Exception):
    pass

class InvalidStatus(Exception):
    pass

class InvalidOrderStatus(InvalidStatus):
    pass


class InvalidLineStatus(InvalidStatus):
    pass


class InvalidShippingEvent(Exception):
    pass
