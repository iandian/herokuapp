/* 
 * The MIT License
 *
 * Copyright 2017 apex-yu.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package org.recluster.common.inject.spi;

import org.recluster.common.inject.Scope;

import java.lang.annotation.Annotation;

/**
 * Visits each of the strategies used to scope an injection.
 *
 * @param <V> any type to be returned by the visit method. Use {@link Void} with
 *            {@code return null} if no return type is needed.
 * @since 2.0
 */
public interface BindingScopingVisitor<V> {

    /**
     * Visit an eager singleton or single instance. This scope strategy is found on both module and
     * injector bindings.
     */
    V visitEagerSingleton();

    /**
     * Visit a scope instance. This scope strategy is found on both module and injector bindings.
     */
    V visitScope(Scope scope);

    /**
     * Visit a scope annotation. This scope strategy is found only on module bindings. The instance
     * that implements this scope is registered by {@link org.recluster.common.inject.Binder#bindScope(Class,
     * Scope) Binder.bindScope()}.
     */
    V visitScopeAnnotation(Class<? extends Annotation> scopeAnnotation);

    /**
     * Visit an unspecified or unscoped strategy. On a module, this strategy indicates that the
     * injector should use scoping annotations to find a scope. On an injector, it indicates that
     * no scope is applied to the binding. An unscoped binding will behave like a scoped one when it
     * is linked to a scoped binding.
     */
    V visitNoScoping();
}
