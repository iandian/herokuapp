package org.flow.searcher.es_client;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ESSearchResponse {
    private List<ESSearchHit> hits = new ArrayList<>();
    private long totalHits;
    private Map<String, ESTermsAggregation> aggregations = new HashMap<>();

    public List<ESSearchHit> getHits() {
        return hits;
    }

    public void addHit(ESSearchHit hit) {
        this.hits.add(hit);
    }

    public long getTotalHits() {
        return totalHits;
    }

    public void setTotalHits(long totalHits) {
        this.totalHits = totalHits;
    }

    public Map<String, ESTermsAggregation> getAggregations() {
        return aggregations;
    }

    public void addAggregation(String name, ESTermsAggregation aggregation) {
        aggregations.put(name, aggregation);
    }
}
