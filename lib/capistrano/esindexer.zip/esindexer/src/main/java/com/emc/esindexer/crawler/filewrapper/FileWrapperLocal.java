
package com.emc.esindexer.crawler.filewrapper;


import com.emc.esindexer.crawler.common.settings.Settings;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

import static com.emc.esindexer.crawler.common.utils.CommonUtil.getCreationTime;
import static com.emc.esindexer.crawler.common.utils.CommonUtil.getFileExtension;
import static com.emc.esindexer.crawler.common.utils.CommonUtil.getGroupName;
import static com.emc.esindexer.crawler.common.utils.CommonUtil.getOwnerName;

public class FileWrapperLocal extends FileWrapper<File> {
    public FileWrapperLocal(Settings settings) {
        super(settings);
    }

    @Override
    public FileModel toFileAbstractModel(String path, File file) {
        FileModel model = new FileModel();
        model.name = file.getName();
        model.file = file.isFile();
        model.directory = !model.file;
        model.lastModifiedDate = LocalDateTime.ofInstant(Instant.ofEpochMilli(file.lastModified()), ZoneId.systemDefault());
        model.creationDate = getCreationTime(file);
        model.extension = getFileExtension(file);
        model.path = path;
        model.fullpath = file.getAbsolutePath();
        model.size = file.length();
        model.owner = getOwnerName(file);
        model.group = getGroupName(file);

        return model;
    }

    @Override
    public InputStream getInputStream(FileModel file) throws Exception {
        return new FileInputStream(new File(file.fullpath));
    }

    @Override
    public Collection<FileModel> getFiles(String dir) {
        logger.debug("Listing local files from {}", dir);
        File[] files = new File(dir).listFiles();
        Collection<FileModel> result;

        if (files != null) {
            result = new ArrayList<>(files.length);

            // Iterate other files
            for (File file : files) {
                result.add(toFileAbstractModel(dir, file));
            }
        } else {
            logger.debug("Symlink on windows gives null for listFiles(). Skipping [{}]", dir);
            result = Collections.emptyList();
        }


        logger.debug("{} local files found", result.size());
        return result;
    }

    @Override
    public boolean exists(String dir) {
        return new File(dir).exists();
    }

    @Override
    public void open() throws Exception {

    }

    @Override
    public void close() throws Exception {

    }
}
