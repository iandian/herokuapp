/* 
 * The MIT License
 *
 * Copyright 2017 apex-yu.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package org.recluster.cluster.metadata;

import org.recluster.common.component.AbstractComponent;
import org.recluster.common.regex.Regex;
import org.recluster.common.settings.Settings;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Resolves cluster names from an expression. The expression must be the exact match of a cluster
 * name or must be a wildcard expression.
 */
public final class ClusterNameExpressionResolver extends AbstractComponent {

    private final WildcardExpressionResolver wildcardResolver = new WildcardExpressionResolver();

    public ClusterNameExpressionResolver(Settings settings) {
        super(settings);
    }

    /**
     * Resolves the provided cluster expression to matching cluster names. This method only
     * supports exact or wildcard matches.
     *
     * @param remoteClusters    the aliases for remote clusters
     * @param clusterExpression the expressions that can be resolved to cluster names.
     * @return the resolved cluster aliases.
     */
    public List<String> resolveClusterNames(Set<String> remoteClusters, String clusterExpression) {
        if (remoteClusters.contains(clusterExpression)) {
            return Collections.singletonList(clusterExpression);
        } else if (Regex.isSimpleMatchPattern(clusterExpression)) {
            return wildcardResolver.resolve(remoteClusters, clusterExpression);
        } else {
            return Collections.emptyList();
        }
    }

    private static class WildcardExpressionResolver {

        private List<String> resolve(Set<String> remoteClusters, String clusterExpression) {
            if (isTrivialWildcard(clusterExpression)) {
                return resolveTrivialWildcard(remoteClusters);
            }

            Set<String> matches = matches(remoteClusters, clusterExpression);
            if (matches.isEmpty()) {
                return Collections.emptyList();
            } else {
                return new ArrayList<>(matches);
            }
        }

        private boolean isTrivialWildcard(String clusterExpression) {
            return Regex.isMatchAllPattern(clusterExpression);
        }

        private List<String> resolveTrivialWildcard(Set<String> remoteClusters) {
            return new ArrayList<>(remoteClusters);
        }

        private static Set<String> matches(Set<String> remoteClusters, String expression) {
            if (expression.indexOf("*") == expression.length() - 1) {
                return otherWildcard(remoteClusters, expression);
            } else {
                return otherWildcard(remoteClusters, expression);
            }
        }

        private static Set<String> otherWildcard(Set<String> remoteClusters, String expression) {
            final String pattern = expression;
            return remoteClusters.stream()
                .filter(n -> Regex.simpleMatch(pattern, n))
                .collect(Collectors.toSet());
        }
    }
}
