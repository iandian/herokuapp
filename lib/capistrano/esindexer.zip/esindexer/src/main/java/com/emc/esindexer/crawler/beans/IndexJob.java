
package com.emc.esindexer.crawler.beans;

import java.time.LocalDateTime;

/**
 * Define a Index Job meta data
 */
public class IndexJob {

    private String name;
    private LocalDateTime lastrun;
    private long indexed;
    private long deleted;

    public static class Builder {
        private String name;
        private LocalDateTime lastrun;
        private long indexed = 0;
        private long deleted = 0;

        public Builder setName(String name) {
            this.name = name;
            return this;
        }

        public Builder setLastrun(LocalDateTime lastrun) {
            this.lastrun = lastrun;
            return this;
        }

        public Builder setIndexed(long indexed) {
            this.indexed = indexed;
            return this;
        }

        public Builder setDeleted(long deleted) {
            this.deleted = deleted;
            return this;
        }

        public IndexJob build() {
            return new IndexJob(name, lastrun, indexed, deleted);
        }
    }

    public static Builder builder() {
        return new Builder();
    }

    public IndexJob() {

    }

    public IndexJob(String name, LocalDateTime lastrun, long indexed, long deleted) {
        this.name = name;
        this.lastrun = lastrun;
        this.indexed = indexed;
        this.deleted = deleted;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public LocalDateTime getLastrun() {
        return lastrun;
    }

    public void setLastrun(LocalDateTime lastrun) {
        this.lastrun = lastrun;
    }

    public long getIndexed() {
        return indexed;
    }

    public void setIndexed(long indexed) {
        this.indexed = indexed;
    }

    public long getDeleted() {
        return deleted;
    }

    public void setDeleted(long deleted) {
        this.deleted = deleted;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        IndexJob indexJob = (IndexJob) o;

        if (indexed != indexJob.indexed) return false;
        if (deleted != indexJob.deleted) return false;
        if (name != null ? !name.equals(indexJob.name) : indexJob.name != null) return false;
        return !(lastrun != null ? !lastrun.equals(indexJob.lastrun) : indexJob.lastrun != null);

    }

    @Override
    public int hashCode() {
        int result = name != null ? name.hashCode() : 0;
        result = 31 * result + (lastrun != null ? lastrun.hashCode() : 0);
        result = 31 * result + (int) (indexed ^ (indexed >>> 32));
        result = 31 * result + (int) (deleted ^ (deleted >>> 32));
        return result;
    }
}
