package org.flow.searcher.crawler;



import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.flow.searcher.settings.TheSearcherSettings;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

import static org.flow.searcher.common.TheSearcherUtil.*;


public class FileAbstractorFile extends FileAbstractor<File> {
    private final Logger logger = LogManager.getLogger(FileAbstractorFile.class);

    public FileAbstractorFile(TheSearcherSettings theSearcherSettings) {
        super(theSearcherSettings);
    }

    @Override
    public FileAbstractModel toFileAbstractModel(String path, File file) {
        return new FileAbstractModel(
                file.getName(),
                file.isFile(),
                getModificationTime(file),
                getCreationTime(file),
                getLastAccessTime(file),
                getFileExtension(file),
                path,
                file.getAbsolutePath(),
                file.length(),
                getOwnerName(file),
                getGroupName(file),
                getFilePermissions(file));
    }

    @Override
    public InputStream getInputStream(FileAbstractModel file) throws Exception {
        return new FileInputStream(new File(file.getFullpath()));
    }

    @Override
    public Collection<FileAbstractModel> getFiles(String dir) {
        logger.debug("Listing local files from {}", dir);
        File[] files = new File(dir).listFiles();
        Collection<FileAbstractModel> result;

        if (files != null) {
            result = new ArrayList<>(files.length);

            // Iterate other files
            for (File file : files) {
                result.add(toFileAbstractModel(dir, file));
            }
        } else {
            logger.debug("Symlink on windows gives null for listFiles(). Skipping [{}]", dir);
            result = Collections.emptyList();
        }


        logger.debug("{} local files found", result.size());
        return result;
    }

    @Override
    public boolean exists(String dir) {
        return new File(dir).exists();
    }

    @Override
    public void open() {
        // Do nothing because we don't open resources in the File implementation.
    }

    @Override
    public void close() {
        // Do nothing because we don't open resources in the File implementation.
    }
}
