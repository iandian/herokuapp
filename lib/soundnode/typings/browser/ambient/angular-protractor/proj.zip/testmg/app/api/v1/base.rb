require "grape-swagger"

module V1
  class Base < Grape::API
    mount V1::Sessions
    mount V1::Users
	mount V1::Products
	mount V1::Builds
	mount V1::TestScenes
	mount V1::TestPipes
	mount V1::TestPlans
	mount V1::TestUnits
	mount V1::TestCases
	mount V1::RunRecords
	mount V1::Results
	mount V1::Dashboard

    add_swagger_documentation(
        api_version: "v1",
        hide_documentation_path: true,
        mount_path: "/api/v1/swagger_doc",
        hide_format: true
      )
  end
end