/* 
 * The MIT License
 *
 * Copyright 2017 apex-yu.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package org.recluster.common.inject;

import org.recluster.common.inject.internal.Errors;
import org.recluster.common.inject.internal.ErrorsException;
import org.recluster.common.inject.internal.FailableCache;
import org.recluster.common.inject.spi.InjectionPoint;

/**
 * Constructor injectors by type.
 *
 * @author jessewilson@google.com (Jesse Wilson)
 */
class ConstructorInjectorStore {
    private final InjectorImpl injector;

    private final FailableCache<TypeLiteral<?>, ConstructorInjector<?>> cache
            = new FailableCache<TypeLiteral<?>, ConstructorInjector<?>>() {
        @Override
        @SuppressWarnings("unchecked")
        protected ConstructorInjector<?> create(TypeLiteral<?> type, Errors errors)
                throws ErrorsException {
            return createConstructor(type, errors);
        }
    };

    ConstructorInjectorStore(InjectorImpl injector) {
        this.injector = injector;
    }

    /**
     * Returns a new complete constructor injector with injection listeners registered.
     */
    @SuppressWarnings("unchecked") // the ConstructorInjector type always agrees with the passed type
    public <T> ConstructorInjector<T> get(TypeLiteral<T> key, Errors errors) throws ErrorsException {
        return (ConstructorInjector<T>) cache.get(key, errors);
    }

    private <T> ConstructorInjector<T> createConstructor(TypeLiteral<T> type, Errors errors)
            throws ErrorsException {
        int numErrorsBefore = errors.size();

        InjectionPoint injectionPoint;
        try {
            injectionPoint = InjectionPoint.forConstructorOf(type);
        } catch (ConfigurationException e) {
            errors.merge(e.getErrorMessages());
            throw errors.toException();
        }

        SingleParameterInjector<?>[] constructorParameterInjectors
                = injector.getParametersInjectors(injectionPoint.getDependencies(), errors);
        MembersInjectorImpl<T> membersInjector = injector.membersInjectorStore.get(type, errors);

        ConstructionProxyFactory<T> factory = new DefaultConstructionProxyFactory<>(injectionPoint);

        errors.throwIfNewErrors(numErrorsBefore);

        return new ConstructorInjector<>(membersInjector.getInjectionPoints(), factory.create(),
                constructorParameterInjectors, membersInjector);
    }
}
