class ResultPolicy < ApplicationPolicy

end
