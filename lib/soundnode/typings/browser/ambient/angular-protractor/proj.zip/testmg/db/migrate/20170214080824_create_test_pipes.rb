class CreateTestPipes < ActiveRecord::Migration[5.0]
  def change
    create_table :test_pipes do |t|
      t.string :name
	  t.belongs_to :test_scene
    end
  end
end
