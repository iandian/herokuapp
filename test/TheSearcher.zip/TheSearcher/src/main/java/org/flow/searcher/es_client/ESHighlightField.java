package org.flow.searcher.es_client;

import java.util.Objects;

/**
 * A field highlighted with its highlighted fragments.
 */
public class ESHighlightField {

    private String name;

    private String[] fragments;

    ESHighlightField() {
    }

    public ESHighlightField(String name, String[] fragments) {
        this.name = Objects.requireNonNull(name, "missing highlight field name");
        this.fragments = fragments;
    }

    /**
     * The name of the field highlighted.
     */
    public String getName() {
        return name;
    }

    /**
     * The highlighted fragments. {@code null} if failed to highlight (for example, the field is not stored).
     */
    public String[] getFragments() {
        return fragments;
    }
}
