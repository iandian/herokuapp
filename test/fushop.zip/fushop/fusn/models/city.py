# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from django.contrib.auth.models import User
import logging
from .province import Province


logger = logging.getLogger(__name__)


class City(models.Model):
    code = models.CharField(max_length=255, primary_key=True, db_index=True)
    name = models.CharField(max_length=255, db_index=True)
    provice = models.ForeignKey(
        Province, related_name='city', on_delete=models.CASCADE, db_column="provinceCode")

    class Meta:
        verbose_name = "City"
        verbose_name_plural = "City"

    def __unicode__(self):
        return '%s %s' % (self.name, self.code)