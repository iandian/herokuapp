# encoding: utf-8
require "rails_helper"

describe "Test Pipe APIs"  do
  before(:each) {
  }

  describe "GET #show" do

    context "when success" do
      before(:each) do
        @test_pipe = create :test_pipe
      end

      it "render test_pipe json" do
        get "/api/test_pipes/#{@test_pipe.id}", params: {}, headers: request_headers

        json_data = json_response[:data][:test_pipe]

        expect(json_data[:id]).to eql @test_pipe.id
        expect(json_data[:name]).to eql @test_pipe.name
      end
    end

    context "when error" do
      after do
        expect(json_response[:meta][:code]).not_to eql RESPONSE_CODE[:success]
      end

      it "returns the error when test pipe id is not found" do
        @test_pipe = create :test_pipe


        get "/api/test_pipes/1111", params: {}, headers: request_headers

        json_data = json_response[:data]

        expect(json_data.blank?).to eql true
        expect(json_response[:meta][:code]).to eql RESPONSE_CODE[:not_found]
        expect(json_response[:meta][:message]).to eql I18n.t("errors.testpipe.not_found")
      end
    end
  end
end

