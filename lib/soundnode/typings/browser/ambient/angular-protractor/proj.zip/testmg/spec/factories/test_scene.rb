FactoryGirl.define do

  factory :test_scene do
    build
    sequence(:name){|n|"test_scene_#{n}"}
    sequence(:filename){|n|"test_scene_#{n}.rb"}
  end
end