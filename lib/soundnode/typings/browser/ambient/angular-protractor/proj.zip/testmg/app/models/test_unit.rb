class TestUnit < ApplicationRecord

	belongs_to :test_pipe
	
	has_many :test_unit_test_cases
	
	has_many :test_cases, through: :test_unit_test_cases
	
	has_many :results, :dependent => :destroy, inverse_of: :test_unit
	
	belongs_to :test_plan

end