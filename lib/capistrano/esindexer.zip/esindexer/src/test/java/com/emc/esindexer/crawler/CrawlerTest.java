///*
// * To change this license header, choose License Headers in Project Properties.
// * To change this template file, choose Tools | Templates
// * and open the template in the editor.
// */
//package com.emc.esindexer.crawler;
//
//import static com.emc.esindexer.crawler.common.utils.CommonUtil.copyDefaultResources;
//import static com.emc.esindexer.crawler.common.utils.CommonUtil.copyResourceFile;
//import com.emc.esindexer.testbase.AbstractTestCase;
//import com.emc.esindexer.crawler.beans.IndexJobFileHandler;
//import com.emc.esindexer.crawler.common.settings.SettingsFileHandler;
//
//import org.junit.BeforeClass;
//import org.junit.Test;
//
//import java.io.IOException;
//import java.net.URISyntaxException;
//import java.nio.file.Files;
//import java.nio.file.Path;
//
//import static org.hamcrest.MatcherAssert.assertThat;
//import static org.hamcrest.Matchers.is;
//
///**
// *
// * @author yua13
// */
//public class CrawlerTest extends AbstractTestCase{
//    
//    private static final String CLASSPATH_RESOURCES_ROOT = "/legacy/2_0/";
//    private static final String[] LEGACY_RESOURCES = {
//            "david.json", "david_status.json"
//    };
//
//    private static Path metadataDir;
//
//    @BeforeClass
//    public static void createCrawlerJobDir() throws IOException, URISyntaxException {
//        // We also need to create default mapping files
//        metadataDir = rootTmpDir.resolve(".fscrawler");
//        if (Files.notExists(metadataDir)) {
//            Files.createDirectory(metadataDir);
//        }
//        copyDefaultResources(metadataDir);
//
//        for (String filename : LEGACY_RESOURCES) {
//            Path target = metadataDir.resolve(filename);
//            copyResourceFile(CLASSPATH_RESOURCES_ROOT + filename, target);
//        }
//    }
//
//    @Test
//    public void testRestartCommand() throws Exception {
//        String jobName = "fscrawler_restart_command";
//
//        // We generate a fake status first in metadata dir
//        SettingsFileHandler settingsFileHandler = new SettingsFileHandler(metadataDir);
//        IndexJobFileHandler fsJobFileHandler = new IndexJobFileHandler(metadataDir);
//
//        Path jobDir = metadataDir.resolve(jobName);
//        Files.createDirectories(jobDir);
//
//
//        settingsFileHandler.write(Settings.builder(jobName).build());
//        fsJobFileHandler.write(jobName, IndexJob.builder().build());
//
//        assertThat(Files.exists(jobDir.resolve(IndexJobFileHandler.FILENAME)), is(true));
//
//        String[] args = { "--config_dir", metadataDir.toString(), "--loop", "0", "--restart", jobName };
//
//        Crawler.main(args);
//
//        assertThat(Files.exists(jobDir.resolve(IndexJobFileHandler.FILENAME)), is(false));
//    }
//
//    @Test
//    public void testFrom2_0Version() {
//        // We should have now our files in david dir
//        Path david = metadataDir.resolve("david");
//        assertThat(Files.isDirectory(david), is(true));
//        Path jobSettings = david.resolve(SettingsFileHandler.FILENAME);
//        assertThat(Files.exists(jobSettings), is(true));
//        Path jobStatus = david.resolve(IndexJobFileHandler.FILENAME);
//        assertThat(Files.exists(jobStatus), is(true));
//    }
//    
//}
