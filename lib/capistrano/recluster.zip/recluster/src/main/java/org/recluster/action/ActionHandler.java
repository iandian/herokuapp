/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.recluster.action;


import org.recluster.action.support.TransportAction;

import org.recluster.common.Strings;

import java.util.Objects;

/**
 *
 * @author yua13
 */
final class ActionHandler<Request extends ActionRequest, Response extends ActionResponse> {

    private final GenericAction<Request, Response> action;
    private final Class<? extends TransportAction<Request, Response>> transportAction;
    private final Class<?>[] supportTransportActions;

    /**
     * Create a record of an action, the {@linkplain TransportAction} that
     * handles it, and any supporting {@linkplain TransportActions} that are
     * needed by that {@linkplain TransportAction}.
     */
    public ActionHandler(GenericAction<Request, Response> action, Class<? extends TransportAction<Request, Response>> transportAction,
            Class<?>... supportTransportActions) {
        this.action = action;
        this.transportAction = transportAction;
        this.supportTransportActions = supportTransportActions;
    }

    public GenericAction<Request, Response> getAction() {
        return action;
    }

    public Class<? extends TransportAction<Request, Response>> getTransportAction() {
        return transportAction;
    }

    public Class<?>[] getSupportTransportActions() {
        return supportTransportActions;
    }

    @Override
    public String toString() {
        StringBuilder b = new StringBuilder().append(action.name()).append(" is handled by ").append(transportAction.getName());
        if (supportTransportActions.length > 0) {
            b.append('[').append(Strings.arrayToCommaDelimitedString(supportTransportActions)).append(']');
        }
        return b.toString();
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null || obj.getClass() != ActionHandler.class) {
            return false;
        }
        ActionHandler<?, ?> other = (ActionHandler<?, ?>) obj;
        return Objects.equals(action, other.action)
                && Objects.equals(transportAction, other.transportAction)
                && Objects.deepEquals(supportTransportActions, other.supportTransportActions);
    }

    @Override
    public int hashCode() {
        return Objects.hash(action, transportAction, supportTransportActions);
    }
}
