package org.flow.searcher.es_client;

import java.util.HashMap;
import java.util.Map;

public class ESSearchHit {
    private String index;
    private String id;
    private Long version;
    private Map<String, Object> source;
    private String sourceAsString;
    private Map<String, ESDocumentField> fields;
    private Map<String, ESHighlightField> highlightFields = new HashMap<>();

    public Map<String, ESDocumentField> getFields() {
        return fields;
    }

    public void setFields(Map<String, ESDocumentField> fields) {
        this.fields = fields;
    }

    public Map<String, Object> getSourceAsMap() {
        return source;
    }

    public void setSourceAsMap(Map<String, Object> source) {
        this.source = source;
    }

    public void setSourceAsString(String sourceAsString) {
        this.sourceAsString = sourceAsString;
    }

    public String getSourceAsString() {
        return sourceAsString;
    }

    public Map<String, ESHighlightField> getHighlightFields() {
        return highlightFields;
    }

    public void addHighlightField(String name, ESHighlightField highlightField) {
        highlightFields.put(name, highlightField);
    }

    public String getIndex() {
        return index;
    }

    public void setIndex(String index) {
        this.index = index;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Long getVersion() {
        return version;
    }

    public void setVersion(Long version) {
        this.version = version;
    }
}
