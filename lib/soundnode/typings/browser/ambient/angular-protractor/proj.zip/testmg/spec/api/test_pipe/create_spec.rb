# encoding: utf-8
require "rails_helper"

describe "Test Pipe APIs"  do
  before(:each) {
    @test_pipe_attributes = FactoryGirl.attributes_for :test_pipe
  }

  describe "POST #create" do

    context "when is successfully created" do
      after do
        expect(json_response[:meta][:code]).to eql RESPONSE_CODE[:success]
      end

      it "render created test pipe" do
        post "/api/test_pipes", params: @test_pipe_attributes.to_json, headers: request_headers

        json_data = json_response[:data][:test_pipe]

        expect(json_data[:name]).to eql @test_pipe_attributes[:name]
      end
    end

    context "when has error" do
      it "render unprocessable_entity error when name value is missing" do
        @test_pipe_attributes[:name] = ""
        post "/api/test_pipes", params: @test_pipe_attributes.to_json, headers: request_headers

        json_data = json_response[:data]

        expect(json_data.blank?).to eql true

        expect(json_response[:meta][:code]).to eql RESPONSE_CODE[:unprocessable_entity]
        expect(json_response[:meta][:message].downcase).to include "name"
      end
    end
  end
end