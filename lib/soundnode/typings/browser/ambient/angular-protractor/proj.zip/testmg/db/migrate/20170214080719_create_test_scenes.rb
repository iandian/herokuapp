class CreateTestScenes < ActiveRecord::Migration[5.0]
  def change
    create_table :test_scenes do |t|
      t.string :name
      t.string :filename
	  t.belongs_to :build
    end
  end
end
