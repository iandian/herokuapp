# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from django.contrib.auth.models import User
import logging


logger = logging.getLogger(__name__)

#TODO
class Admin(models.Model):
    username = models.CharField(max_length=10)
    password = models.CharField(max_length=255)
    password_salt = models.CharField(max_length=255)
    last_login_ip = models.CharField(max_length=60)
    last_login_time = models.IntegerField()
    add_time = models.IntegerField()
    update_time = models.IntegerField()
    avatar = models.CharField(max_length=255)
    admin_role_id = models.IntegerField()

    class Meta:
        verbose_name = "Admin"
        verbose_name_plural = "Admin"

    def __unicode__(self):
        return '%s %s' % (self.name, self.address)