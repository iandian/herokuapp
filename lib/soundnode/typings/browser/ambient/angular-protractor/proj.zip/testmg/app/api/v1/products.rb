module V1
  class Products < Grape::API
    include V1Base
	include ProductBase

    VALID_PARAMS = %w(name)

    helpers do
      def product_params
        params.select{|key,value| VALID_PARAMS.include?(key.to_s)}
      end
    end

    resource :products do

      desc 'Create new product', http_codes: [
        { code: 200, message: 'success' },
        { code: RESPONSE_CODE[:unprocessable_entity], message: 'Detail error messages' }
      ]
      params do
        requires :name, type: String, desc: 'Product name'
      end
      post :rabl => "product/show.rabl" do
        create_product(product_params)
      end


      desc 'Get product', headers: HEADERS_DOCS, http_codes: [
        { code: 200, message: 'success' },
        { code: RESPONSE_CODE[:not_found], message: I18n.t('errors.not_found') }
      ]
      params do
        requires :id, type: String, desc: 'User id'
      end
      get ':id', :rabl => "product/show.rabl" do
	    logger.info "start to get product with id #{params[:id]}"
        get_product(params[:id])
      end

	  
      desc 'Get products', headers: HEADERS_DOCS, http_codes: [
        { code: 200, message: 'success' },
        { code: RESPONSE_CODE[:forbidden], message: I18n.t('errors.forbidden') }
      ]
      params do
        optional :page, type: Integer, desc: 'page'
        optional :per_page, type: Integer, desc: 'per_page'
	  end
      get :rabl => "product/all.rabl" do
        get_all_product
      end
	  
    end
  end
end