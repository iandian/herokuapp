package org.flow.searcher.common;



import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;

import java.io.IOException;

/**
 * Jackson Serializer for Percentage object
 */
public class PercentageSerializer extends StdSerializer<Percentage> {
    public PercentageSerializer() {
        super(Percentage.class);
    }

    @Override
    public void serialize(Percentage value, JsonGenerator gen, SerializerProvider provider) throws IOException {
        gen.writeString(value.format());
    }
}

