package com.emc.esindexer;

import com.beust.jcommander.JCommander;
import com.beust.jcommander.Parameter;
import com.emc.esindexer.crawler.Crawler;
import com.emc.esindexer.crawler.CrawlerShutdownHook;
import com.emc.esindexer.crawler.beans.IndexJobFileHandler;
import com.emc.esindexer.crawler.common.MetaFileHandler;
import com.emc.esindexer.crawler.common.settings.*;
import com.emc.esindexer.crawler.common.utils.BootstrapChecks;
import com.emc.esindexer.crawler.common.utils.CommonUtil;
import com.emc.esindexer.logging.LogConfigurator;
import com.emc.esindexer.logging.Loggers;

import org.apache.logging.log4j.Logger;

import org.elasticsearch.Version;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Scanner;

import static com.emc.esindexer.crawler.common.utils.CommonUtil.copyDefaultResources;
import static com.emc.esindexer.crawler.common.utils.CommonUtil.moveLegacyResource;
import org.apache.commons.io.FileUtils;

public class Test {

    @Deprecated
    public static final String INDEX_SETTINGS_FILE = "_settings";

    private static final long CLOSE_POLLING_WAIT_MS = 100;

    private static Crawler crawler = null;

    @SuppressWarnings("CanBeFinal")
    public static class CrawlerCommand {
        @Parameter(description = "job_name")
        List<String> jobName;

        @Parameter(names = "--config_dir", description = "Config directory. Default to ~/.fscrawler")
        private String configDir = null;

        @Parameter(names = "--username", description = "Elasticsearch username when running with security.")
        private String username = null;

        @Parameter(names = "--loop", description = "Number of scan loop before exiting.")
        private Integer loop = -1;

        @Parameter(names = "--restart", description = "Restart fscrawler job like if it never ran before. " +
                "This does not clean elasticsearch indices.")
        private boolean restart = false;

        @Parameter(names = "--rest", description = "Start REST Layer")
        private boolean rest = false;

        @Parameter(names = "--upgrade", description = "Upgrade elasticsearch indices from one old version to the last version.")
        private boolean upgrade = false;

        @Parameter(names = "--help", description = "display current help", help = true)
        boolean help;
    }


    @SuppressWarnings("deprecation")
    public static void main(String[] args) throws Exception {
        // create a scanner so we can read the command-line input
        args = new String[]{"yes", "--debug"};
        Scanner scanner = new Scanner(System.in);

        CrawlerCommand commands = new CrawlerCommand();
        JCommander jCommander = new JCommander(commands, args);

        if (commands.help) {
            jCommander.usage();
            return;
        }

        Path configDir;

        if (commands.configDir == null) {
            configDir = MetaFileHandler.DEFAULT_ROOT;
        } else {
            configDir = Paths.get(commands.configDir);
        }

        initLog(configDir);

        BootstrapChecks.check();

        final Logger logger = Loggers.getLogger(Test.class);

        // We copy default mapping and settings to the default settings dir .fscrawler/_default/
        copyDefaultResources(configDir);

        // We move the legacy stuff which might come from version 2.0
        moveLegacyResources(configDir);

        Settings settings = null;
        SettingsFileHandler settingsFileHandler = new SettingsFileHandler(configDir);

        String jobName;

        if (commands.jobName == null) {
            // The user did not enter a job name.
            // We can list available jobs for him
            logger.info("No job specified. Here is the list of existing jobs:");

            List<String> files = CommonUtil.listExistingJobs(configDir);

            if (files.size() > 0) {
                for (int i = 0; i < files.size(); i++) {
                    logger.info("[{}] - {}", i+1, files.get(i));
                }
                int chosenFile = 0;
                while (chosenFile <= 0 || chosenFile > files.size()) {
                    logger.info("Choose your job [1-{}]...", files.size());
                    chosenFile = scanner.nextInt();
                }
                jobName = files.get(chosenFile - 1);
            } else {
                logger.info("No job exists in [{}].", configDir);
                logger.info("To create your first job, run 'fscrawler job_name' with 'job_name' you want");
                jobName = null;
                return;
            }

        } else {
            jobName = commands.jobName.get(0);
        }

        // If we ask to reinit, we need to clean the status for the job
        if (commands.restart) {
            logger.debug("Cleaning existing status for job [{}]...", jobName);
            new IndexJobFileHandler(configDir).clean(jobName);
        }

        try {
            logger.debug("Starting job [{}]...", jobName);
            settings = settingsFileHandler.read(jobName);

            // Check default settings
            if (settings.getEsSettings() == null) {
                settings.setEsSettings(EsSettings.DEFAULT);
            }
            if (settings.getElasticsearch() == null) {
                settings.setElasticsearch(Elasticsearch.DEFAULT());
            }

            String username = commands.username;
            if (settings.getElasticsearch().getUsername() != null) {
                username = settings.getElasticsearch().getUsername();
            }

            if (username != null && settings.getElasticsearch().getPassword() == null) {
                logger.info("Password for " +  username + ":");
                String password = scanner.next();
                settings.getElasticsearch().setUsername(username);
                settings.getElasticsearch().setPassword(password);
            }

        } catch (NoSuchFileException e) {
            logger.warn("job [{}] does not exist", jobName);

            String yesno = null;
            while (!"y".equalsIgnoreCase(yesno) && !"n".equalsIgnoreCase(yesno)) {
                logger.info("Do you want to create it (Y/N)?");
                yesno = scanner.next();
            }

            if ("y".equalsIgnoreCase(yesno)) {
                settings = Settings.builder(commands.jobName.get(0))
                        .setEsSettings(EsSettings.DEFAULT)
                        .setElasticsearch(Elasticsearch.DEFAULT())
                        .build();
                settingsFileHandler.write(settings);

                Path config = configDir.resolve(jobName).resolve(IndexJobFileHandler.FILENAME);
                logger.info("Settings have been created in [{}]. Please review and edit before relaunch", config);
            }

            return;
        }

        logger.trace("settings used for this crawler: [{}]", SettingsParser.toJson(settings));
        crawler = new Crawler(configDir, settings, commands.loop, commands.rest);
        Runtime.getRuntime().addShutdownHook(new CrawlerShutdownHook(crawler));

        try {
            // Let see if we want to upgrade an existing cluster to latest version
            if (commands.upgrade) {
                logger.info("Upgrading job [{}]", jobName);
                boolean success = crawler.upgrade();
                if (success) {
                    // We can rewrite the fscrawler setting file (we now have a elasticsearch.index_folder property)
                    logger.info("Updating fscrawler setting file");
                    settingsFileHandler.write(settings);
                }
            } else {
                Path jobMappingDir = configDir.resolve(settings.getName()).resolve("_mappings");
                crawler.getEsClientManager().start();
                Version elasticsearchVersion = crawler.getEsClientManager().client().info().getVersion();
                try {
                    // If we are able to read an old configuration file, we should tell the user to check the documentation
                    CommonUtil.readJsonFile(jobMappingDir, configDir, Byte.toString(elasticsearchVersion.major), INDEX_SETTINGS_FILE);
                    logger.warn("We found old configuration index settings in [{}] or [{}]. You should look at the documentation" +
                            " about upgrades: https://github.com/dadoonet/fscrawler#upgrade-to-23", configDir, jobMappingDir);
                } catch (IllegalArgumentException ignored) { }

                crawler.start();
                // We just have to wait until the process is stopped
                while (!crawler.getParser().isClosed()) {
                    sleep();
                }
            }
        } catch (Exception e) {
            logger.fatal("Fatal error received while running the crawler: [{}]", e.getMessage());
            logger.debug("error caught", e);
        } finally {
            if (crawler != null) {
                crawler.close();
            }
        }
    }

    public static void moveLegacyResources(Path root) {
        try (DirectoryStream<Path> directoryStream = Files.newDirectoryStream(root)) {
            for (Path path : directoryStream) {
                String fileName = path.getFileName().toString();
                if (fileName.endsWith(IndexJobFileHandler.LEGACY_EXTENSION)) {
                    // We have a Legacy Job Settings file {job_name.json} which needs to move to job_name/_settings.json
                    String jobName = fileName.substring(0, fileName.length() - IndexJobFileHandler.LEGACY_EXTENSION.length());
                    Path jobDir = root.resolve(jobName);
                    Files.createDirectories(jobDir);
                    Path destination = jobDir.resolve(IndexJobFileHandler.FILENAME);
                    moveLegacyResource(path, destination);
                } else if (fileName.endsWith(IndexJobFileHandler.LEGACY_EXTENSION)) {
                    // We have a Legacy Job Settings file {job_name.json} which needs to move to job_name/_settings.json
                    String jobName = fileName.substring(0, fileName.length() - IndexJobFileHandler.LEGACY_EXTENSION.length());
                    Path jobDir = root.resolve(jobName);
                    Files.createDirectories(jobDir);
                    Path destination = jobDir.resolve(IndexJobFileHandler.FILENAME);
                    moveLegacyResource(path, destination);
                }
            }
        } catch (IOException e) {
            final Logger logger = Loggers.getLogger(Test.class);
            logger.warn("Got error while moving legacy content", e);
        }
    }

    private static void initLog(Path configPath) throws IOException{
        try {
            copyLogPorperties(configPath);
            Path logDir = configPath.resolve("log");

            // If the dir does not exist, we need to create it
            if (Files.notExists(logDir)) {
                Files.createDirectory(logDir);
            }
            LogConfigurator.configure(configPath, logDir);
            final Logger logger = Loggers.getLogger(Test.class);
            logger.info("tid mo xo le");
            logger.info("de coe dd");
        } catch (IOException e) {
            throw e;
        }
    }

    /**
     * Copy log properties file which are available as project resources under
     * com.emc.esindexer._default.log package to a given configuration path
     * @param configPath The config path which is by default .esindexer
     * @throws IOException If copying does not work
     */
    public static void copyLogPorperties(Path configPath) throws IOException {
//        Path targetResourceDir = configPath.resolve("log");

        String filename = "log4j2.properties";
        Path target = configPath.resolve(filename);
        if (!Files.exists(target)) {
            InputStream resource = Test.class.getResourceAsStream(CommonUtil.CLASSPATH_RESOURCES_ROOT + filename);
            FileUtils.copyInputStreamToFile(resource, target.toFile());
        }
    }

    private static void sleep() {
        try {
            Thread.sleep(CLOSE_POLLING_WAIT_MS);
        }
        catch(InterruptedException ignored) {
            Thread.currentThread().interrupt();
        }
    }
}
