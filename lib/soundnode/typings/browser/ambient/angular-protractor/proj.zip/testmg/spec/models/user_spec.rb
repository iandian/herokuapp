# encoding: utf-8
require "rails_helper"

describe "test user model"  do

  describe "#create" do
    it "ldap query" do
	  //add email on openldap first
	  email = Devise::LDAP::Adapter.get_ldap_param('test',"mail").first   
	  puts email
          # uid = Devise::LDAP::Adapter.get_ldap_param('administrator',"sAMAccountName").first
          # p uid

          # resource = Devise::LDAP::Adapter.ldap_connect('administrator').search_for_login
          p resource

    end
  end
  
end
	  
	  