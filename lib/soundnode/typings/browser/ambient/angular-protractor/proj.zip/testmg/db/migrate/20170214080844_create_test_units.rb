class CreateTestUnits < ActiveRecord::Migration[5.0]
  def change
    create_table :test_units do |t|
      t.string :name
	  t.belongs_to :test_pipe
	  t.belongs_to :test_plan
    end
  end
end
