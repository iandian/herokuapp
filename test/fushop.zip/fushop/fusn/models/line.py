# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from .user import User
from .goods import Goods
import logging


logger = logging.getLogger(__name__)

#TODO
class Cart(models.Model):
    user_id = models.IntegerField()
    session_id = models.CharField(max_length=32)
    goods_id = models.IntegerField()
    goods_sn = models.CharField(max_length=60)
    product_id = models.IntegerField()
    goods_name = models.CharField(max_length=120)
    market_price = models.DecimalField(max_digits=10, decimal_places=2)
    retail_price = models.DecimalField(max_digits=10, decimal_places=2)
    number = models.SmallIntegerField()
    goods_specifition_name_value = models.TextField()
    goods_specifition_ids = models.CharField(max_length=60)
    checked = models.IntegerField()
    list_pic_url = models.CharField(max_length=255)



    name = models.CharField(max_length=50, blank=True, default='')
    #TODO

    class Meta:
        verbose_name = "Cart"
        verbose_name_plural = "Cart"

    def __unicode__(self):
        return '%s %s' % (self.name, self.address)