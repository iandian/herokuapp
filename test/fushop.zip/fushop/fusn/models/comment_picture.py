# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from django.contrib.auth.models import User
import logging
from .comment import Comment


logger = logging.getLogger(__name__)


class CommentPicture(models.Model):
    comment = models.ForeignKey(
        Comment, related_name='comment_picture', on_delete=models.CASCADE)
    pic_url = models.URLField(blank=True)
    sort_order = models.IntegerField()

    class Meta:
        verbose_name = "CommentPicture"
        verbose_name_plural = "CommentPicture"

    def __unicode__(self):
        return '%s %s' % (self.comment, self.pic_url)