FactoryGirl.define do

  factory :test_pipe do
    test_scene
    sequence(:name){|n|"test_pipe_#{n}"}
  end
end