# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from django.contrib.auth.models import User
import logging


logger = logging.getLogger(__name__)


class Coupon(models.Model):
    name = models.CharField(max_length=60)
    type_money = models.DecimalField(max_digits=10, decimal_places=2)
    send_type = models.IntegerField()
    min_amount = models.DecimalField(max_digits=10, decimal_places=2)
    max_amount = models.DecimalField(max_digits=10, decimal_places=2)
    send_start_date = models.DateTimeField(blank=True, null=True)
    send_end_date = models.DateTimeField(blank=True, null=True)
    use_start_date = models.DateTimeField(blank=True, null=True)
    use_end_date = models.DateTimeField(blank=True, null=True)
    min_goods_amount = models.DecimalField(max_digits=10, decimal_places=2)

    class Meta:
        verbose_name = "Coupon"
        verbose_name_plural = "Coupon"

    def __unicode__(self):
        return '%s %s' % (self.name, self.type_money)