# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from django.contrib.auth.models import User
import logging


logger = logging.getLogger(__name__)

#TODO
class GoodsSpecification(models.Model):
    goods_id = models.IntegerField()
    specification_id = models.IntegerField()
    value = models.CharField(max_length=50)
    pic_url = models.CharField(max_length=255)

    class Meta:
        verbose_name = "GoodsSpecification"
        verbose_name_plural = "GoodsSpecification"

    def __unicode__(self):
        return '%s %s' % (self.name, self.address)