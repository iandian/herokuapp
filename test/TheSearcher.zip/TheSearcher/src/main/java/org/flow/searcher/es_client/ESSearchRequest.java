package org.flow.searcher.es_client;


import java.util.ArrayList;
import java.util.List;

public class ESSearchRequest {

    private String index;
    private String sort;
    private Integer size;
    private ESQuery ESQuery;
    private List<String> fields = new ArrayList<>();
    private List<String> highlighters = new ArrayList<>();
    private List<ESTermsAggregation> aggregations = new ArrayList<>();

    public String getIndex() {
        return index;
    }

    public ESSearchRequest withIndex(String index) {
        this.index = index;
        return this;
    }

    public Integer getSize() {
        return size;
    }

    public ESSearchRequest withSize(Integer size) {
        this.size = size;
        return this;
    }

    public ESQuery getESQuery() {
        return ESQuery;
    }

    public ESSearchRequest withESQuery(ESQuery query) {
        this.ESQuery = query;
        return this;
    }

    public List<String> getFields() {
        return fields;
    }

    public ESSearchRequest addField(String field) {
        this.fields.add(field);
        return this;
    }

    public String getSort() {
        return sort;
    }

    public ESSearchRequest withSort(String sort) {
        this.sort = sort;
        return this;
    }

    public List<String> getHighlighters() {
        return highlighters;
    }

    public ESSearchRequest addHighlighter(String field) {
        highlighters.add(field);
        return this;
    }

    public List<ESTermsAggregation> getAggregations() {
        return aggregations;
    }

    public ESSearchRequest withAggregation(ESTermsAggregation aggregation) {
        this.aggregations.add(aggregation);
        return this;
    }
}
