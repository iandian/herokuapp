module RunRecordBase
  extend ActiveSupport::Concern

  included do

    helpers do
      def get_run_record(id)
        @run_record = RunRecord.find(id)

        unless @run_record
          raise ApiException.new(
            http_status: RESPONSE_CODE[:not_found], 
            code: RESPONSE_CODE[:not_found], 
            message: I18n.t('errors.run_record.not_found')
          )
        end
      end
	  
      def create_run_record(params)
        @run_record = RunRecord.new(params)
		authorize @run_record, :create?
        unless @run_record.save
          raise ApiException.new(
            http_status: RESPONSE_CODE[:not_found], 
            code: RESPONSE_CODE[:not_found], 
            message: I18n.t('errors.run_record.not_found')
          )
        end
      end

    end
  end
end