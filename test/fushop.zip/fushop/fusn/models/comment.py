# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from .user import User
import logging


logger = logging.getLogger(__name__)


class Comment(models.Model):
    type_id = models.IntegerField()    #TODO
    value_id = models.IntegerField()    #TODO
    content = models.CharField(max_length=6550)
    add_time = models.DateTimeField(blank=True, null=True)
    status = models.IntegerField()
    user = models.ForeignKey(
        User, related_name='comment', on_delete=models.CASCADE)
    new_content = models.CharField(max_length=6550)


    class Meta:
        verbose_name = "Comment"
        verbose_name_plural = "Comment"

    def __unicode__(self):
        return '%s' % (self.content)