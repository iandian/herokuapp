import {Component} from '@angular/core';

import 'style-loader!./basicTables.scss';

@Component({
  selector: 'basic-tables',
  templateUrl: './basicTables.html'
})
export class BasicTables {

  constructor() {
  }
}
