from fusn.tests.factories.catalogue import *
from fusn.tests.factories.partner import *