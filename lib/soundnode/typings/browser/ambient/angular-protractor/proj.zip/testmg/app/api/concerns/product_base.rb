module ProductBase
  extend ActiveSupport::Concern

  included do

    helpers do
      def get_product(id)
        @product = Product.find(id)

        unless @product
          raise ApiException.new(
            http_status: RESPONSE_CODE[:not_found], 
            code: RESPONSE_CODE[:not_found], 
            message: I18n.t('errors.product.not_found')
          )
        end
      end
	  
      def create_product(params)
        @product = Product.new(params)

        unless @product.save
          raise ApiException.new(
            http_status: RESPONSE_CODE[:not_found], 
            code: RESPONSE_CODE[:not_found], 
            message: I18n.t('errors.product.not_found')
          )
        end
      end

    end
  end
end