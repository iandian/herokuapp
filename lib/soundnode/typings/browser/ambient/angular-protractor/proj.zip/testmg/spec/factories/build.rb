FactoryGirl.define do

  factory :build do
    product
    sequence(:version){|n|"v1.0.0.#{n}"}
    trait :with_run_records do
	  after :create do |build| 
		create_list :run_record, 10, build: build   # has_many
	  end
    end

  end
end