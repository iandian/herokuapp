package org.flow.searcher.es_client;

import java.util.ArrayList;
import java.util.List;

public class ESTermsAggregation {
    private final String name;
    private final String field;
    private List<ESTermsBucket> buckets = new ArrayList<>();

    public ESTermsAggregation(String name, String field) {
        this.name = name;
        this.field = field;
    }

    public String getField() {
        return field;
    }

    public String getName() {
        return name;
    }

    public List<ESTermsBucket> getBuckets() {
        return buckets;
    }

    public void addBucket(ESTermsBucket bucket) {
        this.buckets.add(bucket);
    }

    public static class ESTermsBucket {
        private final String key;
        private final long docCount;

        public ESTermsBucket(String key, long docCount) {
            this.key = key;
            this.docCount = docCount;
        }

        public String getKey() {
            return key;
        }

        public long getDocCount() {
            return docCount;
        }
    }
}
