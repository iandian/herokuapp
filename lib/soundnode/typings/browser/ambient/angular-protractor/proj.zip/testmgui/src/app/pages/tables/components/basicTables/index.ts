export * from './basicTables.component';
