class RunRecordPolicy < ApplicationPolicy

end
