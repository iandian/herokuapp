# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rails db:seed command (or created alongside the database with db:setup).
#
# Examples:
#
#   movies = Movie.create([{ name: 'Star Wars' }, { name: 'Lord of the Rings' }])
#   Character.create(name: 'Luke', movie: movies.first)

## Create test user
# (1..20).to_a.each do |n|
  # User.create(email: "user-test-#{n}@gmail.com", password: "123456789", name: "user-test-#{n}")
# end

Product.delete_all
Build.delete_all
TestScene.delete_all
TestPipe.delete_all
TestUnit.delete_all
TestUnitTestCase.delete_all
TestCase.delete_all
TestPlan.delete_all
RunRecord.delete_all
Result.delete_all
Report.delete_all


product1 = Product.create!(name: "product1")

build1 = product1.builds.create!(version: "1.0.0.1888")

scene1 = build1.test_scenes.create!(name: "source")
scene2 = build1.test_scenes.create!(name: "job")

record1 = build1.run_records.create!(name: "product1_v1.0.0.1888_record1")

pipe1 = scene1.test_pipes.create!(name: "source_add")
pipe2 = scene1.test_pipes.create!(name: "source_remove")
pipe11 = scene2.test_pipes.create!(name: "job_edit")
pipe22 = scene2.test_pipes.create!(name: "job_delete")

unit1 = pipe1.test_units.create!(name: "source_add_001")
unit11 = pipe1.test_units.create!(name: "source_add_002")
unit2 = pipe2.test_units.create!(name: "source_remove_001")
unit22 = pipe2.test_units.create!(name: "source_remove_002")
unit3 = pipe11.test_units.create!(name: "job_edit_001")
unit33 = pipe11.test_units.create!(name: "job_edit_002")
unit4 = pipe22.test_units.create!(name: "job_delete_001")
unit44 = pipe22.test_units.create!(name: "job_delete_002")

testcase1 = TestCase.create!(testid: "11111", title: "this is test source scence one", description: "first then do secend")
testcase2 = TestCase.create!(testid: "22222", title: "this is test source scence two", description: "2first then do 2secend")
testcase3 = TestCase.create!(testid: "33333", title: "this is test source scence three", description: "3first then do 3secend")
testcase4 = TestCase.create!(testid: "44444", title: "this is test source scence four", description: "4first then do 4secend")
testcase5 = TestCase.create!(testid: "55555", title: "this is test job scence one", description: "aread then do secend")
testcase6 = TestCase.create!(testid: "66666", title: "this is test job scence two", description: "bdwe then do secend")
testcase7 = TestCase.create!(testid: "77777", title: "this is test job scence three", description: "cgrf then do secend")
testcase8 = TestCase.create!(testid: "88888", title: "this is test job scence four", description: "dcrrh then do secend")

unit1.test_cases << testcase1 << testcase2
unit1.save!
unit11.test_cases << testcase1 << testcase3
unit11.save!
unit2.test_cases << testcase2 << testcase3
unit2.save!
unit22.test_cases << testcase3 << testcase4
unit22.save!
unit3.test_cases << testcase5 << testcase6
unit3.save!
unit33.test_cases << testcase5 << testcase7
unit33.save!
unit4.test_cases << testcase6 << testcase7
unit4.save!
unit44.test_cases << testcase7 << testcase8
unit44.save!

result1 = Result.create!(value: true)
result1.test_unit = unit1
result1.run_record = record1
result1.save!
result2 = Result.create!(value: true)
result2.test_unit = unit2
result2.run_record = record1
result2.save!
result3 = Result.create!(value: false)
result3.test_unit = unit3
result3.run_record = record1
result3.save!
result4 = Result.create!(value: true)
result4.test_unit = unit4
result4.run_record = record1
result4.save!

report1 = Report.create!(name: "Report1")
report1.run_record = record1
report1.save!