
package com.emc.esindexer.crawler.common;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * Utility class to sign *things*
 *
 * @author David Pilato (aka dadoonet)
 */
public class SignTool {

    public static String sign(String toSign) throws NoSuchAlgorithmException {

        MessageDigest md = MessageDigest.getInstance("MD5");
        md.update(toSign.getBytes());

        StringBuilder key = new StringBuilder();
        byte b[] = md.digest();
        for (byte aB : b) {
            long t = aB < 0 ? 256 + aB : aB;
            key.append(Long.toHexString(t));
        }

        return key.toString();
    }

}
