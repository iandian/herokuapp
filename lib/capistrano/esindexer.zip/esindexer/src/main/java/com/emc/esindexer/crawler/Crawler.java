
package com.emc.esindexer.crawler;

import com.emc.esindexer.crawler.client.ElasticsearchClientManager;

import com.emc.esindexer.crawler.common.TimeValue;
import com.emc.esindexer.crawler.common.settings.CrawlerValidator;
import com.emc.esindexer.crawler.common.settings.Settings;
import com.emc.esindexer.crawler.common.settings.Server;
import com.emc.esindexer.crawler.common.utils.CommonUtil;
import com.emc.esindexer.crawler.core.Parser;
import com.emc.esindexer.crawler.core.ParserLocal;
import com.emc.esindexer.crawler.core.ParserSsh;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * @author dadoonet (David Pilato)
 */
public class Crawler {

    @Deprecated
    public static final String INDEX_TYPE_FOLDER = "folder";
    @Deprecated
    public static final String INDEX_TYPE_DOC = "doc";

    private static final Logger logger = LogManager.getLogger(Crawler.class);

    public static final int LOOP_INFINITE = -1;
    public static final long MAX_SLEEP_RETRY_TIME = TimeValue.timeValueSeconds(30).millis();

    private final Settings settings;
    private final boolean rest;
    private final Path config;
    private final Integer loop;

    private Thread fsCrawlerThread;

    private final ElasticsearchClientManager esClientManager;
    private Parser parser;

    public Crawler(Path config, Settings settings) {
        this(config, settings, LOOP_INFINITE, false);
    }

    public Crawler(Path config, Settings settings, Integer loop, boolean rest) {
        CommonUtil.createDirIfMissing(config);

        this.config = config;
        this.settings = settings;
        this.loop = loop;
        this.rest = rest;
        this.esClientManager = new ElasticsearchClientManager(config, settings);

        // We don't go further as we have critical errors
        // It's just a double check as settings must be validated before creating the instance
        if (CrawlerValidator.validateSettings(logger, settings, rest)) {
            throw new RuntimeException("Settings are incorrect and should have been verified with CrawlerValidator.validateSettings before.");
        }

        // Generate the directory where we write status and other files
        Path jobSettingsFolder = config.resolve(settings.getName());
        try {
            Files.createDirectories(jobSettingsFolder);
        } catch (IOException e) {
            throw new RuntimeException("Can not create the job config directory", e);
        }
    }

    public ElasticsearchClientManager getEsClientManager() {
        return esClientManager;
    }

    /**
     * Upgrade FSCrawler indices
     * @return true if done successfully
     * @throws Exception In case of error
     */
    @SuppressWarnings("deprecation")
    public boolean upgrade() throws Exception {
        // We need to start a client so we can send requests to elasticsearch
        esClientManager.start();

        // The upgrade script is for now a bit dumb. It assumes that you had an old version of FSCrawler (< 2.3) and it will
        // simply move data from index/folder to index_folder
        String index = settings.getElasticsearch().getIndex();

        // Check that the old index actually exists
        if (esClientManager.client().isExistingIndex(index)) {
            // We check that the new indices don't exist yet or are empty
            String indexFolder = settings.getElasticsearch().getIndexFolder();
            boolean indexExists = esClientManager.client().isExistingIndex(indexFolder);
            long numberOfDocs = 0;
            if (indexExists) {
                SearchResponse responseFolder = esClientManager.client().search(new SearchRequest(indexFolder));
                numberOfDocs = responseFolder.getHits().getTotalHits();
            }
            if (numberOfDocs > 0) {
                logger.warn("[{}] already exists and is not empty. No upgrade needed.", indexFolder);
            } else {
                logger.debug("[{}] can be upgraded.", index);

                // Create the new indices with the right mappings (well, we don't read existing user configuration)
                if (!indexExists) {
                    esClientManager.createIndices();
                    logger.info("[{}] has been created.", indexFolder);
                }

                // Run reindex task for folders
                logger.info("Starting reindex folders...");
                int folders = esClientManager.client().reindex(index, INDEX_TYPE_FOLDER, indexFolder);
                logger.info("Done reindexing [{}] folders...", folders);

                // Run delete by query task for folders
                logger.info("Starting removing folders from [{}]...", index);
                esClientManager.client().deleteByQuery(index, INDEX_TYPE_FOLDER);
                logger.info("Done removing folders from [{}]", index);

                logger.info("You can now upgrade your elasticsearch cluster to >=6.0.0!");
                return true;
            }
        } else {
            logger.info("[{}] does not exist. No upgrade needed.", index);
        }

        return false;
    }

    public void start() throws Exception {
        logger.info("Starting Crawler");
        if (loop < 0) {
            logger.info("Crawler started in watch mode. It will run unless you stop it with CTRL+C.");
        }

        if (loop == 0 && !rest) {
            logger.warn("Number of runs is set to 0 and rest layer has not been started. Exiting");
            return;
        }

        esClientManager.start();
        esClientManager.createIndices();

        // Start the crawler thread - but not if only in rest mode
        if (loop != 0) {
            // What is the protocol used?
            if (settings.getServer() == null || Server.PROTOCOL.LOCAL.equals(settings.getServer().getProtocol())) {
                // Local FS
                parser = new ParserLocal(settings, config, esClientManager, loop);
            } else if (Server.PROTOCOL.SSH.equals(settings.getServer().getProtocol())) {
                // Remote SSH FS
                parser = new ParserSsh(settings, config, esClientManager, loop);
            } else {
                // Non supported protocol
                throw new RuntimeException(settings.getServer().getProtocol() + " is not supported yet. Please use " +
                        Server.PROTOCOL.LOCAL + " or " + Server.PROTOCOL.SSH);
            }

            fsCrawlerThread = new Thread(parser, "crawler");
            fsCrawlerThread.start();
        }
    }

    public void close() throws InterruptedException {
        logger.debug("Closing crawler [{}]", settings.getName());

        if (parser != null) {
            parser.setClosed(true);

            synchronized(parser.getSemaphore()) {
                parser.getSemaphore().notifyAll();
            }
        }

        if (this.fsCrawlerThread != null) {
            while (fsCrawlerThread.isAlive()) {
                // We check that the crawler has been closed effectively
                logger.debug("Crawler thread is still running");
                Thread.sleep(500);
            }
            logger.debug("Crawler thread is now stopped");
        }

        esClientManager.close();
        logger.debug("ES Client Manager stopped");

        logger.info("Crawler [{}] stopped", settings.getName());
    }

    public Parser getParser() {
        return parser;
    }
}
