class ApplicationApi < Grape::API
  GrapeDeviseTokenAuth.setup!
  mount V1::Base
end