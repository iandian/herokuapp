# encoding: utf-8
require "rails_helper"

describe ProductPolicy do
  subject { described_class }

  let (:other_user) { create :user }
  let (:admin_user) { create :user, :admin }
  
  # let (:other_user) { FactoryGirl.build_stubbed :user }
  # let (:admin_role) { FactoryGirl.build_stubbed :role, :name => "admin" }
  # let (:admin_user) { FactoryGirl.build_stubbed :user }
  # admin_user.stub(:roles).and_return([@admin_role])


  permissions :update?, :edit?, :new?, :create? do
    it "denies access if user not admin" do
      expect(subject).not_to permit(other_user, Product.new(name: "product_policy"))
    end

    it "grants access if user is an admin" do
      expect(subject).to permit(admin_user, Product.new(name: "product_policy2"))
    end

  end

end
