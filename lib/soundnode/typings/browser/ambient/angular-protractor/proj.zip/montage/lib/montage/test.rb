class Polygon

   @test = {}
   def self.aaa
     @test['a'] = 1
     @test['b'] = 2
   end

   def self.bbb
                if instance_variable_get("@channel").nil?
                        instance_variable_set("@channel",{"channel"=> "aaa","queue"=>"bbb"})
                end
   end


end

# require_relative './test.rb'
# Polygon.bbb
# Polygon.instance_variable_get("@channel")