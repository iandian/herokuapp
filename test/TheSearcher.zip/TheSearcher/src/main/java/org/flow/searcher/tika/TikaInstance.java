package org.flow.searcher.tika;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.tika.config.ServiceLoader;
import org.apache.tika.exception.TikaException;
import org.apache.tika.language.detect.LanguageDetector;
import org.apache.tika.metadata.Metadata;
import org.apache.tika.mime.MediaTypeRegistry;
import org.apache.tika.parser.AutoDetectParser;
import org.apache.tika.parser.DefaultParser;
import org.apache.tika.parser.ParseContext;
import org.apache.tika.parser.Parser;
import org.apache.tika.parser.external.ExternalParser;
import org.apache.tika.parser.ocr.TesseractOCRConfig;
import org.apache.tika.parser.ocr.TesseractOCRParser;
import org.apache.tika.parser.pdf.PDFParser;
import org.apache.tika.sax.BodyContentHandler;
import org.apache.tika.sax.WriteOutContentHandler;
import org.flow.searcher.settings.IndexSetting;
import org.flow.searcher.settings.TheSearcherSettings;
import org.xml.sax.SAXException;

import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;

import static org.apache.tika.langdetect.OptimaizeLangDetector.getDefaultLanguageDetector;

/**
 *
 */
public class TikaInstance {

    private static final Logger logger = LogManager.getLogger(TikaInstance.class);

    private static Parser parser;
    private static ParseContext context;
    private static LanguageDetector detector;

    /* For tests only */
    public static void reloadTika() {
        parser = null;
        context = null;
    }

    /**
     * This initialize if needed a parser and a parse context for tika
     * @param indexSetting indexSetting settings
     */
    private static void initTika(IndexSetting indexSetting) {
        initParser(indexSetting);
        initContext(indexSetting);
    }

    private static void initParser(IndexSetting indexSetting) {
        if (parser == null) {
            PDFParser pdfParser = new PDFParser();
            DefaultParser defaultParser;

            if (!indexSetting.getOcr().isEnabled()) {
                logger.debug("OCR is disabled. Even though it's detected, it must be disabled explicitly");
                defaultParser = new DefaultParser(
                        MediaTypeRegistry.getDefaultRegistry(),
                        new ServiceLoader(),
                        Collections.singletonList(TesseractOCRParser.class));
            } else {
                logger.debug("OCR is activated.");
                if (ExternalParser.check("tesseract")) {
                    logger.debug("OCR strategy for PDF documents is [{}] and tesseract was found.", indexSetting.getOcr().getPdfStrategy());
                    pdfParser.setOcrStrategy(indexSetting.getOcr().getPdfStrategy());
                } else {
                    logger.debug("But Tesseract is not installed so we won't run OCR.");
                    pdfParser.setOcrStrategy("no_ocr");
                }
                defaultParser = new DefaultParser(
                        MediaTypeRegistry.getDefaultRegistry(),
                        new ServiceLoader(),
                        Collections.singletonList(PDFParser.class));
            }

            parser = new AutoDetectParser(defaultParser, pdfParser);
        }

    }

    private static void initContext(IndexSetting indexSetting) {
        if (context == null) {
            context = new ParseContext();
            context.set(Parser.class, parser);
            if (indexSetting.getOcr().isEnabled()) {
                logger.debug("OCR is activated so we need to configure Tesseract in case we have specific settings.");
                TesseractOCRConfig config = new TesseractOCRConfig();
                if (indexSetting.getOcr().getPath() != null) {
                    logger.debug("Tesseract Path set to [{}].", indexSetting.getOcr().getPath());
                    config.setTesseractPath(indexSetting.getOcr().getPath());
                }
                if (indexSetting.getOcr().getDataPath() != null) {
                    logger.debug("Tesseract Data Path set to [{}].", indexSetting.getOcr().getDataPath());
                    config.setTessdataPath(indexSetting.getOcr().getDataPath());
                }
                logger.debug("Tesseract Language set to [{}].", indexSetting.getOcr().getLanguage());
                config.setLanguage(indexSetting.getOcr().getLanguage());
                if (indexSetting.getOcr().getOutputType() != null) {
                    logger.debug("Tesseract Output Type set to [{}].", indexSetting.getOcr().getOutputType());
                    config.setOutputType(indexSetting.getOcr().getOutputType());
                }
                context.set(TesseractOCRConfig.class, config);
            }
        }
    }

    static String extractText(TheSearcherSettings theSearcherSettings, int indexedChars, InputStream stream, Metadata metadata) throws IOException,
            TikaException {
        initTika(theSearcherSettings.getIndexSetting());
        WriteOutContentHandler handler = new WriteOutContentHandler(indexedChars);
        try {
            parser.parse(stream, new BodyContentHandler(handler), metadata, context);
        } catch (SAXException e) {
            if (!handler.isWriteLimitReached(e)) {
                // This should never happen with BodyContentHandler...
                throw new TikaException("Unexpected SAX processing failure", e);
            }
        } finally {
            stream.close();
        }
        return handler.toString();
    }

    static LanguageDetector langDetector() {
        if (detector == null) {
            try {
                detector = getDefaultLanguageDetector();
                detector.loadModels();
            } catch (IOException e) {
                logger.warn("Can not load lang detector models", e);
            }
        }
        return detector;
    }
}

