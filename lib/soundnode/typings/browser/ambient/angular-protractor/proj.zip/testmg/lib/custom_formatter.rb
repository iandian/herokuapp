require 'logger'
require 'socket'

class CustomFormatter < Logger::Formatter
  def call(severity, time, program_name, message)
	file = "file"
	line = "1"
	func = "func"
	hostname = Socket.gethostname
	
	format_time = time.strftime("%Y/%m/%d %H:%M:%S")

	begin
	  file, line, func  = caller[6].split(":") # __FILE__ __LINE__ # from the current f
	  file = File.basename(file)
	  # "func" sometimes not accurate, e.g. we get this for block "in `block in <class:LdapQuery>'"
	  #_nil, func = func.split("`")
	  #func.gsub!(/[<>']/, "")
	  func = "func"
	rescue
	end
	
	level = severity
	case severity
	  when "DEBUG"
		level = "VERBOSE"
	  when "WARN"
		level = "WARNING"
	end

	"1|P#{Process.pid}|T#{Thread.current.object_id}|#{format_time}|#{func}|#{level}|#{message}|#{file}(#{line})|#{hostname}\r\n"
  end
end