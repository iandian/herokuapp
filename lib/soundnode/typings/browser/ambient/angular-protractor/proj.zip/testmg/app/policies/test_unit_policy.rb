class TestUnitPolicy < ApplicationPolicy

end
