# encoding: utf-8
require "rails_helper"

describe "Test Plan APIs"  do
  before(:each) {
	@user = create(:user)
	@user.add_role :admin
  }

  describe "GET #show" do

    context "when success" do
      before(:each) do
        @test_plan = create :test_plan
      end

      it "render test_plan json" do
        auth_get @user, "/api/test_plans/#{@test_plan.id}", params: {}, headers: request_headers

        json_data = json_response[:data][:test_plan]

        expect(json_data[:id]).to eql @test_plan.id
        expect(json_data[:name]).to eql @test_plan.name
      end
    end

    context "when error" do
      after do
        expect(json_response[:meta][:code]).not_to eql RESPONSE_CODE[:success]
      end

      it "returns the error when test plan id is not found" do
        @test_plan = create :test_plan


        auth_get @user, "/api/test_plans/1111", params: {}, headers: request_headers

        json_data = json_response[:data]

        expect(json_data.blank?).to eql true
        expect(json_response[:meta][:code]).to eql RESPONSE_CODE[:not_found]
        expect(json_response[:meta][:message]).to eql I18n.t("errors.testplan.not_found")
      end
    end
  end
end

