class BuildPolicy < ApplicationPolicy

end
