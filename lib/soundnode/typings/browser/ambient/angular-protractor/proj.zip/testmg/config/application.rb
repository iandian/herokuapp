require_relative 'boot'

require 'rails/all'
require 'rack'
require 'rack/cors'


# Require the gems listed in Gemfile, including any gems
# you've limited to :test, :development, or :production.
Bundler.require(*Rails.groups)

module Rails5GrapeApiExample
  class Application < Rails::Application
    # Settings in config/environments/* take precedence over those specified here.
    # Application configuration should go into files in config/initializers
    # -- all .rb files in that directory are automatically loaded.

    config.paths.add File.join('app', 'api'), glob: File.join('**', '*.rb')
    config.autoload_paths += Dir[Rails.root.join('app', 'api', '*')]

    config.middleware.use Rack::Cors do
      allow do
        origins "*"
        resource "*", headers: :any, methods: [:get, 
            :post, :put, :delete, :options]
      end
    end
	
	config.middleware.use(Rack::Config) do |env|
		env['api.tilt.root'] = Rails.root.join "app", "views", "api"
	end

    # so can use render_success(Rabl::Renderer.json(build, 'build/show')) now	
    Rabl.configure do |config|
      config.view_paths = [Rails.root.join("app", "views", "api")]
    end


    # don't generate RSpec tests for views and helpers
    config.generators do |g|
      g.test_framework :rspec, fixture: true
      g.fixture_replacement :factory_girl, dir: 'spec/factories'
      g.view_specs false
      g.helper_specs false
      g.stylesheets = false
      g.javascripts = false
      g.helper = false
    end
	
	

    config.autoload_paths += Dir["#{config.root}/lib"]
	
	require 'custom_formatter'
	config.log_formatter = CustomFormatter.new
	config.log_level = :info
	
  end
end
