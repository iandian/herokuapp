from django.test import TestCase
from fusn.tests import factories

class MyTestCase(TestCase):
    def test_untils(self):
        product1 = factories.ProductFactory()
        print(product1)