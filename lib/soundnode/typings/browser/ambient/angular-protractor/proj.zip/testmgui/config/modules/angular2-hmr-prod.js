exports.HmrState = function() {
};
