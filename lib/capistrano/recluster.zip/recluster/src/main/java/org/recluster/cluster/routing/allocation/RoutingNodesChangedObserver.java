/* 
 * The MIT License
 *
 * Copyright 2017 apex-yu.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package org.recluster.cluster.routing.allocation;

import org.recluster.cluster.routing.RoutingChangesObserver;
import org.recluster.cluster.routing.RoutingNodes;
import org.recluster.cluster.routing.ShardRouting;
import org.recluster.cluster.routing.UnassignedInfo;

/**
 * Records if changes were made to {@link RoutingNodes} during an allocation round.
 */
public class RoutingNodesChangedObserver implements RoutingChangesObserver {
    private boolean changed;

    /**
     * Returns whether changes were made
     */
    public boolean isChanged() {
        return changed;
    }

    @Override
    public void shardInitialized(ShardRouting unassignedShard, ShardRouting initializedShard) {
        assert unassignedShard.unassigned() : "expected unassigned shard " + unassignedShard;
        assert initializedShard.initializing() : "expected initializing shard " + initializedShard;
        setChanged();
    }

    @Override
    public void shardStarted(ShardRouting initializingShard, ShardRouting startedShard) {
        assert initializingShard.initializing() : "expected initializing shard " + initializingShard;
        assert startedShard.started() : "expected started shard " + startedShard;
        setChanged();
    }

    @Override
    public void relocationStarted(ShardRouting startedShard, ShardRouting targetRelocatingShard) {
        assert startedShard.started() : "expected started shard " + startedShard;
        assert targetRelocatingShard.isRelocationTarget() : "expected relocation target shard " + targetRelocatingShard;
        setChanged();
    }

    @Override
    public void unassignedInfoUpdated(ShardRouting unassignedShard, UnassignedInfo newUnassignedInfo) {
        assert unassignedShard.unassigned() : "expected unassigned shard " + unassignedShard;
        setChanged();
    }

    @Override
    public void shardFailed(ShardRouting failedShard, UnassignedInfo unassignedInfo) {
        assert failedShard.assignedToNode() : "expected assigned shard " + failedShard;
        setChanged();
    }

    @Override
    public void relocationCompleted(ShardRouting removedRelocationSource) {
        assert removedRelocationSource.relocating() : "expected relocating shard " + removedRelocationSource;
        setChanged();
    }

    @Override
    public void relocationSourceRemoved(ShardRouting removedReplicaRelocationSource) {
        assert removedReplicaRelocationSource.primary() == false && removedReplicaRelocationSource.isRelocationTarget() :
            "expected replica relocation target shard " + removedReplicaRelocationSource;
        setChanged();
    }

    @Override
    public void startedPrimaryReinitialized(ShardRouting startedPrimaryShard, ShardRouting initializedShard) {
        assert startedPrimaryShard.primary() && startedPrimaryShard.started() : "expected started primary shard " + startedPrimaryShard;
        assert initializedShard.primary() && initializedShard.initializing(): "expected initializing primary shard " + initializedShard;
        setChanged();
    }

    @Override
    public void replicaPromoted(ShardRouting replicaShard) {
        assert replicaShard.started() && replicaShard.primary() == false : "expected started replica shard " + replicaShard;
        setChanged();
    }

    @Override
    public void initializedReplicaReinitialized(ShardRouting oldReplica, ShardRouting reinitializedReplica) {
        assert oldReplica.initializing() && oldReplica.primary() == false :
            "expected initializing replica shard " + oldReplica;
        assert reinitializedReplica.initializing() && reinitializedReplica.primary() == false :
            "expected reinitialized replica shard " + reinitializedReplica;
        assert oldReplica.allocationId().getId().equals(reinitializedReplica.allocationId().getId()) == false :
            "expected allocation id to change for reinitialized replica shard (old: " + oldReplica + " new: " + reinitializedReplica + ")";
        setChanged();
    }

    /**
     * Marks the allocation as changed.
     */
    private void setChanged() {
        changed = true;
    }
}
