# encoding: utf-8
require "rails_helper"

describe "Test Case APIs"  do
  before(:each) {
  }

  describe "GET #show" do

    context "when success" do
      before(:each) do
        @test_case = create :test_case
      end

      it "render test_case json" do
        get "/api/test_cases/#{@test_case.id}", params: {}, headers: request_headers

        json_data = json_response[:data][:test_case]

        expect(json_data[:id]).to eql @test_case.id
        expect(json_data[:testid]).to eql @test_case.testid
        expect(json_data[:title]).to eql @test_case.title
        expect(json_data[:description]).to eql @test_case.description
      end
    end

    context "when error" do
      after do
        expect(json_response[:meta][:code]).not_to eql RESPONSE_CODE[:success]
      end

      it "returns the error when test case id is not found" do
        @test_case = create :test_case


        get "/api/test_cases/1111", params: {}, headers: request_headers

        json_data = json_response[:data]

        expect(json_data.blank?).to eql true
        expect(json_response[:meta][:code]).to eql RESPONSE_CODE[:not_found]
        expect(json_response[:meta][:message]).to eql I18n.t("errors.testcase.not_found")
      end
    end
  end
end

