package org.flow.searcher.crawler;


import org.flow.searcher.settings.TheSearcherSettings;

import java.io.InputStream;
import java.util.Collection;

public abstract class FileAbstractor<T> {
    protected final TheSearcherSettings theSearcherSettings;

    public abstract FileAbstractModel toFileAbstractModel(String path, T file);

    public abstract InputStream getInputStream(FileAbstractModel file) throws Exception;

    public abstract Collection<FileAbstractModel> getFiles(String dir) throws Exception;

    public abstract boolean exists(String dir);

    public abstract void open() throws Exception;

    public abstract void close() throws Exception;

    protected FileAbstractor(TheSearcherSettings theSearcherSettings) {
        this.theSearcherSettings = theSearcherSettings;
    }
}
