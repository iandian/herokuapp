/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.emc.esindexer.crawler.client;

import com.emc.esindexer.crawler.common.utils.JsonUtil;

import org.junit.Test;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Map;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.hasEntry;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.nullValue;

/**
 *
 * @author yua13
 */
public class SearchResponseTest {

    @Test
    public void testSerializeDeserialize() {
        String json = "{\"took\":4,\"timed_out\":false,\"_shards\":{\"total\":5,\"successful\":5,\"failed\":0},\"hits\":{\"total\":1," +
                "\"max_score\":1.0,\"hits\":[{\"_index\":\"index\",\"_type\":\"type\",\"_id\":\"id\",\"_score\":1.0,\"_source\":{" +
                "\"foo\":\"bar\"}}]}}";

        InputStream stream = new ByteArrayInputStream(json.getBytes(StandardCharsets.UTF_8));
        SearchResponse response = JsonUtil.deserialize(stream, SearchResponse.class);

        assertThat(response.getHits().getTotal(), is(1L));
        assertThat(response.getHits().getHits(), hasSize(1));
        assertThat(response.getHits().getHits().get(0).getSource(), hasEntry("foo", "bar"));
        assertThat(response.getHits().getHits().get(0).getFields(), nullValue());

        stream = new ByteArrayInputStream(json.getBytes(StandardCharsets.UTF_8));
        Map<String, Object> map = JsonUtil.asMap(stream);

    }
    
}
