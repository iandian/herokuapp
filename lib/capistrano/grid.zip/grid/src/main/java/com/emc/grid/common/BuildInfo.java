package com.emc.grid.common;

import com.emc.grid.GridLancher;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;
import java.util.jar.Attributes;
import java.util.jar.JarFile;
import java.util.jar.Manifest;
import java.util.zip.ZipEntry;

/**
 * Reads information about how the current application was built from the
 * Build-Info section of the manifest in the jar file, which contains this
 * class.
 */
public class BuildInfo {

    private static final Properties BUILD_PROPERTIES = loadBuildProperties();

    private static Properties loadBuildProperties() {
        Properties properties = new Properties();

        Manifest manifest = null;
        JarFile jar = null;
        try {
            URL url = BuildInfo.class.getProtectionDomain().getCodeSource().getLocation();
            File file = new File(url.toURI());
//            file = new File("C:\\Git\\netbean\\grid\\build\\classes\\java\\main\\selenium-server-standalone-3.8.1.jar");
            jar = new JarFile(file);
            ZipEntry entry = jar.getEntry("META-INF/build-stamp.properties");
            if (entry != null) {
                try (InputStream stream = jar.getInputStream(entry)) {
                    properties.load(stream);
                }
            }

            manifest = jar.getManifest();
        } catch (IllegalArgumentException
                | IOException
                | NullPointerException
                | URISyntaxException ignored) {
        } finally {
            if (jar != null) {
                try {
                    jar.close();
                } catch (IOException e) {
                    // ignore
                }
            }
        }

        if (manifest == null) {
            return properties;
        }

        try {
            Attributes attributes = manifest.getAttributes("Build-Info");
            Set<Entry<Object, Object>> entries = attributes.entrySet();
            for (Entry<Object, Object> e : entries) {
                properties.put(String.valueOf(e.getKey()), String.valueOf(e.getValue()));
            }
        } catch (NullPointerException e) {
            // Fall through
        }

        return properties;
    }

    /**
     * @return The embedded release label or "unknown".
     */
    public String getReleaseLabel() {
        return BUILD_PROPERTIES.getProperty("Grid-Version", "unknown").trim();
    }

    /**
     * @return The embedded build revision or "unknown".
     */
    public String getBuildRevision() {
        return BUILD_PROPERTIES.getProperty("Build-Revision", "unknown");
    }

    /**
     * @return The embedded build time or "unknown".
     */
    public String getBuildTime() {
        return BUILD_PROPERTIES.getProperty("Build-Time", "unknown");
    }

    @Override
    public String toString() {
        return String.format("Build info: version: '%s', revision: '%s', time: '%s'",
                getReleaseLabel(), getBuildRevision(), getBuildTime());
    }

//    /**
//     * @param args the command line arguments
//     */
//    public static void main(String[] args) throws Exception {
//        BuildInfo buildInfo = new BuildInfo();
//        String label = buildInfo.getReleaseLabel();
//        String version = buildInfo.getBuildRevision();
//        
//    }
}
