require 'json'
require 'yaml'
require 'pathname'


class Importer::YmlImporter
  
  
  def initialize
    @project_dir = "/srv/automation_base/firefox/"
  end
  
  
  def import
    product = Product.where(name: "search").first_or_create!
    version = get_version
	unless product.builds.find_by_version(version)
	  build = product.builds.create!(version: version)
	  find_all_test_yml.each do |file_full_path|
	    pn = Pathname.new(file_full_path)
		puts "create test_scene"
		@test_scene = build.test_scenes.create!(name: (pn.basename.sub_ext '').to_s)
		puts "test_scene created \n #{@test_scene}"
	    dateset = load_yaml(file_full_path)
		analize_yaml_and_save(dateset)
	  end
	end
  end
  
  def get_version
    "2.0.0.7"
  end
  
  def load_yaml(file_full_path)
    contents = ''
    yaml_file = []
    get_yaml_file(file_full_path).each do |file|
		yaml_file.push(File.new(file, 'r:bom|utf-8')) if File.exists?(file)
	end
	yaml_file.each do |file|
		contents += file.read
		contents += "\n"
	end
	dataset = YAML.load(contents)
  end
  
  def analize_yaml_and_save(yaml_data)
    yaml_data.each do |key,value|
	  if value.is_a?(Array)
	    value.each do |data_row|
		  if data_row.include?('metadata') || data_row.include?('parameter_list') || data_row.include?('validation_list')
		    create_tests_pipe_unit_case key, data_row
		  end
		end
	  end
	end
  end
  
  def create_tests_pipe_unit_case base_name, test_data
    puts "create test_pipe"
    pipe = @test_scene.test_pipes.where(name: base_name).first_or_create!
	puts "test_pipe created \n #{pipe}"
    name = 'test_'
	ids_string = ""
	if test_data['metadata']
	    metadata_data = test_data['metadata']
		level = metadata_data['level'].downcase if metadata_data['level']
		name += "#{level}_" if level
		name += "#{base_name.downcase}_"
		if metadata_data['id']
		  ids_string = metadata_data['id'].to_s
		  name += "webid_#{ids_string.gsub(' ', '_')}_" 

		end
		name += "#{metadata_data['author'].upcase.gsub(/\s+/, '_')}" if metadata_data['author']
	else
		name += "#{base_name}"
	end
	puts "create test_unit"
	unit = pipe.test_units.create!(name: name)
	puts "test_unit created \n #{unit}"
    ids_string.split(" ").map(&:strip).each do |v|
	  unit.test_cases << TestCase.where(testid: v).first_or_create!
    end
  end
  
  def get_yaml_file(file_full_path)
    common_environment_file = "/srv/automation_base/firefox/automation/common/config/environments.yml"
	user_file = "/srv/automation_base/firefox/automation/common/config/users.yml"
	automation_type_based_environment_file = File.join(File.dirname(file_full_path), '..', '..', 'common', 'config', 'environments.yml')
	return common_environment_file, automation_type_based_environment_file, user_file, file_full_path
  end
  

  def find_all_test_yml
    Dir.glob(File.join(@project_dir, "**", "test_*.yml")).map(&File.method(:realpath))
  end
  
end