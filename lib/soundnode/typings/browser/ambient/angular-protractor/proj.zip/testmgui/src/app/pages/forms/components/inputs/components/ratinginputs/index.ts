export * from './ratinginputs.component';
