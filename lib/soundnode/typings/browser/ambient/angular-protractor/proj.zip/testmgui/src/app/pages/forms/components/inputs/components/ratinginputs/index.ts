export * from './ratinginputs.component';
