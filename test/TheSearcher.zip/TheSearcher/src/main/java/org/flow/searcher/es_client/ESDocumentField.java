package org.flow.searcher.es_client;


import java.util.Iterator;
import java.util.List;
import java.util.Objects;

/**
 * A single field name and values part of {@link ESSearchHit}.
 *
 * @see ESSearchHit
 */
public class ESDocumentField implements Iterable<Object> {

    private String name;
    private List<Object> values;

    private ESDocumentField() {
    }

    public ESDocumentField(String name, List<Object> values) {
        this.name = Objects.requireNonNull(name, "name must not be null");
        this.values = Objects.requireNonNull(values, "values must not be null");
    }

    /**
     * The name of the field.
     */
    public String getName() {
        return name;
    }

    /**
     * The first value of the hit.
     */
    public <V> V getValue() {
        if (values == null || values.isEmpty()) {
            return null;
        }
        return (V)values.get(0);
    }

    /**
     * The field values.
     */
    public List<Object> getValues() {
        return values;
    }

    @Override
    public Iterator<Object> iterator() {
        return values.iterator();
    }
}
