
package com.emc.esindexer.crawler.beans;

import com.fasterxml.jackson.core.JsonProcessingException;

import java.io.IOException;

import static com.emc.esindexer.crawler.common.MetaParser.prettyMapper;


public class IndexJobParser {

    public static String toJson(IndexJob job) throws JsonProcessingException {
        return prettyMapper.writeValueAsString(job);
    }

    public static IndexJob fromJson(String json) throws IOException {
        return prettyMapper.readValue(json, IndexJob.class);
    }
}
