class TestPipePolicy < ApplicationPolicy

end
