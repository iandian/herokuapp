module V1
  class TestScenes < Grape::API
    include V1Base
	include BuildBase

    VALID_PARAMS = %w(name filename build_id)

    helpers do
      def test_scene_params
        params.select{|key,value| VALID_PARAMS.include?(key.to_s)}
      end
	  
	  
    end
	
    resource :test_scenes do

      desc 'Create new test scene', http_codes: [
        { code: 200, message: 'success' },
        { code: RESPONSE_CODE[:unprocessable_entity], message: 'Detail error messages' }
      ]
      params do
        requires :name, type: String, desc: 'Test scene name'
        requires :filename, type: String, desc: 'Test scene belongs to which file'
      end
      post :rabl => "test_scene/show.rabl" do
        create_test_scene(test_scene_params)
      end


      desc 'Get test scene', headers: HEADERS_DOCS, http_codes: [
        { code: 200, message: 'success' },
        { code: RESPONSE_CODE[:not_found], message: I18n.t('errors.not_found') }
      ]
      params do
        requires :id, type: String, desc: 'Test scene id'
      end
      get ':id', :rabl => "test_scene/show.rabl" do
	    logger.info "start to get test scene with id #{params[:id]}"
        get_test_scene(params[:id])
      end

	  
    end
	
  end
end