class ProductPolicy < ApplicationPolicy

end
