# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from django.contrib.auth.models import User
import logging


logger = logging.getLogger(__name__)

class OrderExpress(models.Model):
    order_id = models.IntegerField()
    shipper_id = models.IntegerField()
    shipper_name = models.CharField(max_length=120)
    shipper_code = models.CharField(max_length=60)
    logistic_code = models.CharField(max_length=20)
    traces = models.CharField(max_length=2000)
    is_finish = models.IntegerField()
    request_count = models.IntegerField(blank=True, null=True)
    request_time = models.IntegerField(blank=True, null=True)
    add_time = models.IntegerField()
    update_time = models.IntegerField()

    class Meta:
        verbose_name = "Address"
        verbose_name_plural = "Address"

    def __unicode__(self):
        return '%s %s' % (self.name, self.address)