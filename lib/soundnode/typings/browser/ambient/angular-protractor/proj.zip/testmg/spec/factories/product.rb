FactoryGirl.define do

  factory :product do
    sequence(:name){|n|"product#{n}"}
    trait :with_builds_run_records do
	  after :create do |product| 
		create_list :build, 10, :with_run_records, product: product   # has_many
	  end
    end
  end
end